package com.campuscue.repository;

import com.campuscue.model.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FacultyRepository extends JpaRepository<Faculty, String> {

    Optional<Faculty> findByEmailIgnoreCase(String email);
}