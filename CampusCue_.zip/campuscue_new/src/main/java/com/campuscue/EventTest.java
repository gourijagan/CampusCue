package com.campuscue;

import com.campuscue.dao.EventDAO;
import com.campuscue.model.Event;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class EventTest {

    public static void main(String[] args) {

        EventDAO eventDAO = new EventDAO();

        // ---------------------------------
        // Create a GENERAL campus event
        // ---------------------------------

        Event techFest = new Event();

        techFest.setTitle("Campus Tech Fest 2026");
        techFest.setDescription(
                "A campus-wide technology festival with workshops, "
                        + "competitions and demonstrations."
        );
        techFest.setEventType("GENERAL");
        techFest.setDepartmentId(null);
        techFest.setVenue("Main Auditorium");

        techFest.setEventDate(
                LocalDate.of(2026, 10, 15)
        );

        techFest.setStartTime(
                LocalTime.of(10, 0)
        );

        techFest.setEndTime(
                LocalTime.of(16, 0)
        );

        techFest.setRegistrationDeadline(
                LocalDateTime.of(
                        2026, 10, 13, 23, 59
                )
        );

        techFest.setTotalSeats(200);
        techFest.setAvailableSeats(200);

        techFest.setEligibility(
                "Open to all students"
        );

        techFest.setStatus("ACTIVE");

        techFest.setCreatedByFacultyId(
                "FAC-CS-001"
        );

        boolean inserted = eventDAO.insert(techFest);

        System.out.println(
                "Event inserted: " + inserted
        );

        // ---------------------------------
        // Retrieve active events
        // ---------------------------------

        System.out.println();
        System.out.println("ACTIVE EVENTS");
        System.out.println("--------------------------------------");

        List<Event> events =
                eventDAO.findActiveEvents();

        for (Event event : events) {

            System.out.println(
                    "Event ID: " + event.getEventId()
            );

            System.out.println(
                    "Title: " + event.getTitle()
            );

            System.out.println(
                    "Date: " + event.getEventDate()
            );

            System.out.println(
                    "Venue: " + event.getVenue()
            );

            System.out.println(
                    "Seats: "
                            + event.getAvailableSeats()
                            + "/"
                            + event.getTotalSeats()
            );

            System.out.println(
                    "Deadline: "
                            + event.getRegistrationDeadline()
            );

            System.out.println("--------------------------------------");
        }
    }
}