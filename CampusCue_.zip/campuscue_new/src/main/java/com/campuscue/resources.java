package com.campuscue;

public class resources {
    
}
