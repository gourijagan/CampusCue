package com.campuscue.model;

public class EventParticipant {

    private int participantId;
    private int eventId;
    private int registrationId;
    private int studentId;

    public EventParticipant() {
    }

    public int getParticipantId() {
        return participantId;
    }

    public void setParticipantId(int participantId) {
        this.participantId = participantId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return "EventParticipant{" +
                "participantId=" + participantId +
                ", eventId=" + eventId +
                ", registrationId=" + registrationId +
                ", studentId=" + studentId +
                '}';
    }
}