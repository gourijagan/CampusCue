package com.campuscue.model;

import java.time.LocalDateTime;

public class EventRegistration {

    private int registrationId;
    private int eventId;
    private int studentId;
    private int numberOfSeats;
    private String registrationStatus;
    private LocalDateTime registeredAt;

    public EventRegistration() {
    }

    public int getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(int registrationId) {
        this.registrationId = registrationId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public String getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(String registrationStatus) {
        this.registrationStatus = registrationStatus;
    }

    public LocalDateTime getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(LocalDateTime registeredAt) {
        this.registeredAt = registeredAt;
    }

    @Override
    public String toString() {
        return "EventRegistration{" +
                "registrationId=" + registrationId +
                ", eventId=" + eventId +
                ", studentId=" + studentId +
                ", numberOfSeats=" + numberOfSeats +
                ", registrationStatus='" +
                registrationStatus + '\'' +
                ", registeredAt=" + registeredAt +
                '}';
    }
}