package com.campuscue.model;

import java.time.LocalDateTime;

public class StudentRegistrationRequest {

    private int requestId;
    private String regNo;
    private String name;
    private int batchStartYear;
    private int batchEndYear;
    private int departmentId;
    private String email;
    private String passwordHash;
    private String status;
    private LocalDateTime requestedAt;
    private LocalDateTime reviewedAt;
    private String reviewedByFacultyId;

    public StudentRegistrationRequest() {
    }

    public StudentRegistrationRequest(
            int requestId,
            String regNo,
            String name,
            int batchStartYear,
            int batchEndYear,
            int departmentId,
            String email,
            String passwordHash,
            String status,
            LocalDateTime requestedAt,
            LocalDateTime reviewedAt,
            String reviewedByFacultyId) {

        this.requestId = requestId;
        this.regNo = regNo;
        this.name = name;
        this.batchStartYear = batchStartYear;
        this.batchEndYear = batchEndYear;
        this.departmentId = departmentId;
        this.email = email;
        this.passwordHash = passwordHash;
        this.status = status;
        this.requestedAt = requestedAt;
        this.reviewedAt = reviewedAt;
        this.reviewedByFacultyId = reviewedByFacultyId;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBatchStartYear() {
        return batchStartYear;
    }

    public void setBatchStartYear(int batchStartYear) {
        this.batchStartYear = batchStartYear;
    }

    public int getBatchEndYear() {
        return batchEndYear;
    }

    public void setBatchEndYear(int batchEndYear) {
        this.batchEndYear = batchEndYear;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getRequestedAt() {
        return requestedAt;
    }

    public void setRequestedAt(LocalDateTime requestedAt) {
        this.requestedAt = requestedAt;
    }

    public LocalDateTime getReviewedAt() {
        return reviewedAt;
    }

    public void setReviewedAt(LocalDateTime reviewedAt) {
        this.reviewedAt = reviewedAt;
    }

    public String getReviewedByFacultyId() {
        return reviewedByFacultyId;
    }

    public void setReviewedByFacultyId(String reviewedByFacultyId) {
        this.reviewedByFacultyId = reviewedByFacultyId;
    }

    @Override
    public String toString() {
        return "StudentRegistrationRequest{" +
                "requestId=" + requestId +
                ", regNo='" + regNo + '\'' +
                ", name='" + name + '\'' +
                ", batchStartYear=" + batchStartYear +
                ", batchEndYear=" + batchEndYear +
                ", departmentId=" + departmentId +
                ", email='" + email + '\'' +
                ", status='" + status + '\'' +
                ", requestedAt=" + requestedAt +
                ", reviewedAt=" + reviewedAt +
                ", reviewedByFacultyId='" + reviewedByFacultyId + '\'' +
                '}';
    }
}