package com.campuscue;

import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.service.LoginService;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    private final LoginService loginService = new LoginService();

    @Override
    public void start(Stage stage) {

        Label title = new Label("CAMPUSCUE");
        title.setStyle(
                "-fx-font-size: 32px;" +
                "-fx-font-weight: bold;"
        );

        Label subtitle = new Label("Never miss a campus event");
        subtitle.setStyle(
                "-fx-font-size: 15px;"
        );

        Label welcome = new Label("Welcome Back");
        welcome.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;"
        );

        Label emailLabel = new Label("Email");

        TextField emailField = new TextField();
        emailField.setPromptText("Enter your college email");
        emailField.setPrefHeight(40);

        Label passwordLabel = new Label("Password");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setPrefHeight(40);

        Button loginButton = new Button("LOGIN");
        loginButton.setPrefWidth(180);
        loginButton.setPrefHeight(40);

        Label messageLabel = new Label();
        messageLabel.setStyle(
                "-fx-text-fill: #c62828;" +
                "-fx-font-size: 13px;"
        );

        loginButton.setOnAction(event -> {

            String email = emailField.getText().trim();
            String password = passwordField.getText();

            if (email.isBlank() || password.isBlank()) {
                messageLabel.setText(
                        "Please enter your email and password."
                );
                return;
            }

            try {

                /*
                 * First try student login.
                 */
                try {

                    Student student =
                            loginService.loginStudent(
                                    email,
                                    password
                            );

                    messageLabel.setStyle(
                            "-fx-text-fill: green;" +
                            "-fx-font-size: 13px;"
                    );

                   System.out.println(
        "Student logged in: "
                + student.getEmail()
);

StudentDashboard dashboard =
        new StudentDashboard(student);

dashboard.show(stage);

return;
                } catch (SecurityException studentLoginFailed) {

                    /*
                     * If it isn't a student account,
                     * try faculty login.
                     */
                }

                /*
                 * Faculty login.
                 */
                Faculty faculty =
                        loginService.loginFaculty(
                                email,
                                password
                        );

                messageLabel.setStyle(
                        "-fx-text-fill: green;" +
                        "-fx-font-size: 13px;"
                );

                messageLabel.setText(
                        "Welcome, " + faculty.getName() + "!"
                );

                System.out.println(
                        "Faculty logged in: "
                                + faculty.getEmail()
                );

                System.out.println(
                        "Admin Level: "
                                + faculty.getAdminLevel()
                );

            } catch (Exception e) {

                messageLabel.setStyle(
                        "-fx-text-fill: #c62828;" +
                        "-fx-font-size: 13px;"
                );

                messageLabel.setText(
                        "Invalid email or password."
                );
            }
        });

        Label registerLabel =
                new Label("New student? Register here");

        registerLabel.setStyle(
                "-fx-font-size: 13px;"
        );

        VBox root = new VBox(12);

        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40));

        root.getChildren().addAll(
                title,
                subtitle,
                welcome,
                emailLabel,
                emailField,
                passwordLabel,
                passwordField,
                loginButton,
                messageLabel,
                registerLabel
        );

        root.setStyle(
                "-fx-background-color: #f5f7fa;"
        );

        Scene scene = new Scene(root, 600, 650);

        stage.setTitle("CampusCue - Login");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}