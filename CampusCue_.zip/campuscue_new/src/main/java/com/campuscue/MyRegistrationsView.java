package com.campuscue;

import com.campuscue.dao.EventDAO;
import com.campuscue.dao.EventRegistrationDAO;
import com.campuscue.model.Event;
import com.campuscue.model.EventRegistration;
import com.campuscue.model.Student;
import com.campuscue.service.EventCancellationService;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;

public class MyRegistrationsView {

    private final Student student;

    private final EventRegistrationDAO
            registrationDAO;

    private final EventDAO eventDAO;

    private final EventCancellationService
            cancellationService;

    public MyRegistrationsView(Student student) {

        this.student = student;

        this.registrationDAO =
                new EventRegistrationDAO();

        this.eventDAO =
                new EventDAO();

        this.cancellationService =
                new EventCancellationService();
    }

    public void show(
            Stage stage,
            StudentDashboard dashboard) {

        Label title =
                new Label("My Registrations");

        title.setStyle(
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;"
        );

        Label studentLabel =
                new Label(
                        student.getName()
                                + " - "
                                + student.getEmail()
                );

        /*
         * Container holding all registration cards.
         */
        VBox registrationContainer =
                new VBox(15);

        registrationContainer.setPadding(
                new Insets(20)
        );

        List<EventRegistration> registrations =
                registrationDAO.findByStudentId(
                        student.getStudentId()
                );

        if (registrations.isEmpty()) {

            Label emptyLabel =
                    new Label(
                            "You have no registrations."
                    );

            registrationContainer
                    .getChildren()
                    .add(emptyLabel);

        } else {

            for (EventRegistration registration :
                    registrations) {

                VBox card =
                        createRegistrationCard(
                                registration,
                                stage,
                                dashboard
                        );

                registrationContainer
                        .getChildren()
                        .add(card);
            }
        }

        /*
         * THIS fixes the scrolling problem.
         *
         * All registration cards are placed
         * inside a ScrollPane.
         */
        ScrollPane scrollPane =
                new ScrollPane(
                        registrationContainer
                );

        scrollPane.setFitToWidth(true);

        scrollPane.setPannable(true);

        scrollPane.setVbarPolicy(
                ScrollPane.ScrollBarPolicy.AS_NEEDED
        );

        scrollPane.setHbarPolicy(
                ScrollPane.ScrollBarPolicy.NEVER
        );

        /*
         * Allow the scrolling area to use
         * most of the window.
         */
        scrollPane.setPrefViewportHeight(
                500
        );

        Button backButton =
                new Button("BACK");

        backButton.setPrefWidth(150);
        backButton.setPrefHeight(35);

        backButton.setOnAction(event ->
                dashboard.show(stage)
        );

        VBox root =
                new VBox(15);

        root.setPadding(
                new Insets(25)
        );

        root.setAlignment(
                Pos.TOP_CENTER
        );

        root.getChildren().addAll(
                title,
                studentLabel,
                scrollPane,
                backButton
        );

        Scene scene =
                new Scene(
                        root,
                        850,
                        700
                );

        stage.setTitle(
                "CampusCue - My Registrations"
        );

        stage.setScene(scene);
        stage.show();
    }

    private VBox createRegistrationCard(
            EventRegistration registration,
            Stage stage,
            StudentDashboard dashboard) {

        Event event =
                eventDAO.findById(
                        registration.getEventId()
                );

        String eventTitle;

        if (event != null) {
            eventTitle =
                    event.getTitle();
        } else {
            eventTitle =
                    "Unknown Event";
        }

        Label eventNameLabel =
                new Label(eventTitle);

        eventNameLabel.setStyle(
                "-fx-font-size: 19px;" +
                "-fx-font-weight: bold;"
        );

        Label registrationIdLabel =
                new Label(
                        "Registration ID: "
                                + registration
                                .getRegistrationId()
                );

        Label seatsLabel =
                new Label(
                        "Seats reserved: "
                                + registration
                                .getNumberOfSeats()
                );

        Label statusLabel =
                new Label(
                        "Status: "
                                + registration
                                .getRegistrationStatus()
                );

        statusLabel.setStyle(
                "-fx-font-weight: bold;"
        );

        Label registeredAtLabel =
                new Label(
                        "Registered at: "
                                + registration
                                .getRegisteredAt()
                );

        Button cancelButton =
                new Button(
                        "CANCEL REGISTRATION"
                );

        cancelButton.setPrefWidth(200);

        /*
         * Cancel button should only work
         * for confirmed registrations.
         */
        boolean confirmed =
                "CONFIRMED".equals(
                        registration
                                .getRegistrationStatus()
                );

        cancelButton.setDisable(
                !confirmed
        );

        cancelButton.setOnAction(eventAction -> {

            Alert confirmation =
                    new Alert(
                            Alert.AlertType.CONFIRMATION
                    );

            confirmation.setTitle(
                    "Cancel Registration"
            );

            confirmation.setHeaderText(
                    "Cancel registration for "
                            + eventTitle
                            + "?"
            );

            confirmation.setContentText(
                    "This will cancel all "
                            + registration
                            .getNumberOfSeats()
                            + " reserved seats."
            );

            Optional<ButtonType> result =
                    confirmation.showAndWait();

            if (result.isEmpty() ||
                    result.get()
                            != ButtonType.OK) {

                return;
            }

            try {

                cancellationService
                        .cancelRegistration(
                                registration
                                        .getRegistrationId(),

                                student
                                        .getStudentId()
                        );

                Alert success =
                        new Alert(
                                Alert.AlertType.INFORMATION
                        );

                success.setTitle(
                        "CampusCue"
                );

                success.setHeaderText(
                        "Registration Cancelled"
                );

                success.setContentText(
                        "Your registration was "
                                + "cancelled successfully."
                );

                success.showAndWait();

                /*
                 * Refresh My Registrations.
                 */
                show(
                        stage,
                        dashboard
                );

            } catch (Exception e) {

                Alert error =
                        new Alert(
                                Alert.AlertType.ERROR
                        );

                error.setTitle(
                        "CampusCue"
                );

                error.setHeaderText(
                        "Cancellation Failed"
                );

                String message =
                        e.getMessage();

                if (message == null ||
                        message.isBlank()) {

                    message =
                            "Could not cancel registration.";
                }

                error.setContentText(
                        message
                );

                error.showAndWait();
            }
        });

        VBox card =
                new VBox(8);

        card.setPadding(
                new Insets(15)
        );

        card.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #d0d7de;" +
                "-fx-border-radius: 8;" +
                "-fx-background-radius: 8;"
        );

        card.getChildren().addAll(
                eventNameLabel,
                registrationIdLabel,
                seatsLabel,
                statusLabel,
                registeredAtLabel,
                cancelButton
        );

        return card;
    }
}