package com.campuscue;

import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.service.LoginService;

public class LoginTest {

    public static void main(String[] args) {

        LoginService loginService = new LoginService();

        System.out.println("======================================");
        System.out.println("        CAMPUSCUE LOGIN TEST");
        System.out.println("======================================");

        // -------------------------------
        // STUDENT LOGIN
        // -------------------------------

        try {

            Student student = loginService.loginStudent(
                    "teststudent2.cs25@jecc.ac.in",
                    "TestPassword123"
            );

            System.out.println();
            System.out.println("STUDENT LOGIN SUCCESSFUL!");
            System.out.println("Name: " + student.getName());
            System.out.println("Reg No: " + student.getRegNo());
            System.out.println("Email: " + student.getEmail());
            System.out.println("Account Status: "
                    + student.getAccountStatus());

        } catch (Exception e) {

            System.out.println();
            System.out.println("STUDENT LOGIN FAILED!");
            System.out.println(e.getMessage());
        }

        // -------------------------------
        // FACULTY LOGIN
        // -------------------------------

        try {

            Faculty faculty = loginService.loginFaculty(
                    "hodcs@jecc.ac.in",
                    "AdminPassword123"
            );

            System.out.println();
            System.out.println("FACULTY LOGIN SUCCESSFUL!");
            System.out.println("Name: " + faculty.getName());
            System.out.println("Faculty ID: "
                    + faculty.getFacultyId());
            System.out.println("Designation: "
                    + faculty.getDesignation());
            System.out.println("Admin Level: "
                    + faculty.getAdminLevel());
            System.out.println("Account Status: "
                    + faculty.getAccountStatus());

        } catch (Exception e) {

            System.out.println();
            System.out.println("FACULTY LOGIN FAILED!");
            System.out.println(e.getMessage());
        }

        System.out.println();
        System.out.println("======================================");
        System.out.println("             TEST COMPLETE");
        System.out.println("======================================");
    }
}