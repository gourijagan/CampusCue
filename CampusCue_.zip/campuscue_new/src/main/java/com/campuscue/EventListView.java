package com.campuscue;

import com.campuscue.dao.EventDAO;
import com.campuscue.model.Event;
import com.campuscue.model.Student;
import com.campuscue.service.EventRegistrationService;
import com.campuscue.util.EventPriorityComparator;
import com.campuscue.util.EventPriorityUtil;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EventListView {

    private final EventDAO eventDAO;
    private final EventRegistrationService registrationService;
    private final Student student;

    public EventListView(Student student) {

        this.student = student;
        this.eventDAO = new EventDAO();
        this.registrationService =
                new EventRegistrationService();
    }

    public void show(
            Stage stage,
            StudentDashboard dashboard) {

        Label title =
                new Label("Upcoming Campus Events");

        title.setStyle(
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;"
        );

        VBox eventContainer =
                new VBox(15);

        eventContainer.setPadding(
                new Insets(20)
        );

        List<Event> events =
                eventDAO.findActiveEvents();

        events.sort(
                new EventPriorityComparator()
        );

        if (events.isEmpty()) {

            Label emptyMessage =
                    new Label(
                            "No upcoming events available."
                    );

            eventContainer.getChildren()
                    .add(emptyMessage);

        } else {

            for (Event event : events) {

                VBox eventCard =
                        createEventCard(event);

                eventContainer.getChildren()
                        .add(eventCard);
            }
        }

        ScrollPane scrollPane =
                new ScrollPane(eventContainer);

        scrollPane.setFitToWidth(true);

        scrollPane.setPrefHeight(520);

        Button backButton =
                new Button("BACK");

        backButton.setPrefWidth(150);
        backButton.setPrefHeight(35);

        backButton.setOnAction(event ->
                dashboard.show(stage)
        );

        VBox root =
                new VBox(15);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.TOP_CENTER
        );

        root.getChildren().addAll(
                title,
                scrollPane,
                backButton
        );

        Scene scene =
                new Scene(
                        root,
                        850,
                        700
                );

        stage.setTitle(
                "CampusCue - Events"
        );

        stage.setScene(scene);
        stage.show();
    }

    private VBox createEventCard(
            Event event) {

        Label eventTitle =
                new Label(
                        event.getTitle()
                );

        eventTitle.setStyle(
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;"
        );

        Label description =
                new Label(
                        event.getDescription() == null
                                ? ""
                                : event.getDescription()
                );

        description.setWrapText(true);

        Label date =
                new Label(
                        "Date: "
                                + event.getEventDate()
                                + " | "
                                + event.getStartTime()
                                + " - "
                                + event.getEndTime()
                );

        Label venue =
                new Label(
                        "Venue: "
                                + event.getVenue()
                );

        Label seats =
                new Label(
                        "Seats available: "
                                + event.getAvailableSeats()
                                + " / "
                                + event.getTotalSeats()
                );

        String priority =
                EventPriorityUtil
                        .getPriorityLabel(event);

        Label priorityLabel =
                new Label(priority);

        priorityLabel.setStyle(
                "-fx-font-weight: bold;" +
                "-fx-font-size: 14px;"
        );

        Label deadline =
                new Label(
                        "Registration deadline: "
                                + event
                                .getRegistrationDeadline()
                );

        String eligibilityText =
                event.getEligibility();

        if (eligibilityText == null ||
                eligibilityText.isBlank()) {

            eligibilityText =
                    "No special restrictions";
        }

        Label eligibility =
                new Label(
                        "Eligibility: "
                                + eligibilityText
                );

        eligibility.setWrapText(true);

        Button registerButton =
                new Button("REGISTER");

        registerButton.setPrefWidth(150);
        registerButton.setPrefHeight(35);

        registerButton.setDisable(
                event.getAvailableSeats() <= 0 ||
                "Registration Closed".equals(priority)
        );

        registerButton.setOnAction(
                actionEvent ->
                        handleRegistration(event)
        );

        VBox card =
                new VBox(8);

        card.setPadding(
                new Insets(15)
        );

        card.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #d0d7de;" +
                "-fx-border-radius: 8;" +
                "-fx-background-radius: 8;"
        );

        card.getChildren().addAll(
                eventTitle,
                priorityLabel,
                description,
                date,
                venue,
                seats,
                deadline,
                eligibility,
                registerButton
        );

        return card;
    }

    private void handleRegistration(
            Event event) {

        /*
         * STEP 1
         *
         * Ask how many seats the student
         * wants to reserve.
         */

        Dialog<Integer> seatDialog =
                new Dialog<>();

        seatDialog.setTitle(
                "CampusCue Registration"
        );

        seatDialog.setHeaderText(
                "Register for "
                        + event.getTitle()
        );

        TextField seatField =
                new TextField("1");

        seatField.setPromptText(
                "Enter 1 to 8"
        );

        Label availableSeatsLabel =
                new Label(
                        "Available seats: "
                                + event.getAvailableSeats()
                );

        VBox seatContent =
                new VBox(10);

        seatContent.setPadding(
                new Insets(20)
        );

        seatContent.getChildren().addAll(

                new Label(
                        "How many seats do you want?"
                ),

                seatField,

                availableSeatsLabel,

                new Label(
                        "Maximum 8 seats per registration."
                )
        );

        seatDialog.getDialogPane()
                .setContent(seatContent);

        seatDialog.getDialogPane()
                .getButtonTypes()
                .addAll(
                        ButtonType.OK,
                        ButtonType.CANCEL
                );

        seatDialog.setResultConverter(
                button -> {

                    if (button ==
                            ButtonType.OK) {

                        try {

                            return Integer.parseInt(
                                    seatField
                                            .getText()
                                            .trim()
                            );

                        } catch (
                                NumberFormatException e) {

                            return -1;
                        }
                    }

                    return null;
                }
        );

        Optional<Integer> seatResult =
                seatDialog.showAndWait();

        if (seatResult.isEmpty()) {
            return;
        }

        int numberOfSeats =
                seatResult.get();

        /*
         * STEP 2
         *
         * Validate seat count.
         */

        if (numberOfSeats < 1 ||
                numberOfSeats > 8) {

            showError(
                    "Please enter a number " +
                    "between 1 and 8."
            );

            return;
        }

        if (numberOfSeats >
                event.getAvailableSeats()) {

            showError(
                    "Only "
                            + event.getAvailableSeats()
                            + " seats are currently available."
            );

            return;
        }

        /*
         * STEP 3
         *
         * The logged-in student automatically
         * occupies one of the requested seats.
         *
         * Therefore:
         *
         * 1 seat  -> 0 additional emails
         * 2 seats -> 1 additional email
         * 4 seats -> 3 additional emails
         * 8 seats -> 7 additional emails
         */

        List<String> additionalEmails =
                new ArrayList<>();

        if (numberOfSeats > 1) {

            additionalEmails =
                    collectParticipantEmails(
                            numberOfSeats - 1
                    );

            /*
             * null means the user cancelled
             * the participant dialog.
             */

            if (additionalEmails == null) {
                return;
            }
        }

        /*
         * STEP 4
         *
         * Show confirmation before writing
         * anything to the database.
         */

        boolean confirmed =
                showConfirmation(
                        event,
                        numberOfSeats,
                        additionalEmails
                );

        if (!confirmed) {
            return;
        }

        /*
         * STEP 5
         *
         * Register.
         *
         * The service will:
         *
         * - verify all students
         * - create registration
         * - insert ALL participants
         * - include logged-in student
         * - reduce available seats
         * - commit everything together
         */

        try {

            registrationService
                    .registerStudent(
                            event.getEventId(),
                            student.getStudentId(),
                            numberOfSeats,
                            additionalEmails
                    );

            showSuccess(
                    "Registration successful!\n\n"
                            + "Event: "
                            + event.getTitle()
                            + "\n"
                            + "Seats reserved: "
                            + numberOfSeats
            );

        } catch (Exception e) {

            String message =
                    e.getMessage();

            if (message == null ||
                    message.isBlank()) {

                message =
                        "Registration failed.";
            }

            showError(message);
        }
    }

    private List<String>
    collectParticipantEmails(
            int additionalStudentCount) {

        Dialog<List<String>> dialog =
                new Dialog<>();

        dialog.setTitle(
                "Participant Details"
        );

        dialog.setHeaderText(
                "Enter the college email of "
                        + additionalStudentCount
                        + " additional student"
                        + (additionalStudentCount > 1
                        ? "s"
                        : "")
        );

        VBox content =
                new VBox(15);

        content.setPadding(
                new Insets(20)
        );

        /*
         * Show the student whose account
         * is currently being used.
         */

        Label yourDetails =
                new Label(
                        "Your seat:\n"
                                + student.getName()
                                + "\n"
                                + student.getEmail()
                );

        yourDetails.setStyle(
                "-fx-font-weight: bold;"
        );

        content.getChildren()
                .add(yourDetails);

        Label information =
                new Label(
                        "Enter only verified CampusCue " +
                        "student email addresses below."
                );

        information.setWrapText(true);

        content.getChildren()
                .add(information);

        List<TextField> emailFields =
                new ArrayList<>();

        for (int i = 0;
             i < additionalStudentCount;
             i++) {

            int participantNumber =
                    i + 2;

            Label participantLabel =
                    new Label(
                            "Participant "
                                    + participantNumber
                    );

            participantLabel.setStyle(
                    "-fx-font-weight: bold;"
            );

            TextField emailField =
                    new TextField();

            emailField.setPromptText(
                    "student.cs25@jecc.ac.in"
            );

            emailField.setPrefWidth(300);

            emailFields.add(
                    emailField
            );

            GridPane participantGrid =
                    new GridPane();

            participantGrid.setHgap(10);
            participantGrid.setVgap(8);

            participantGrid.add(
                    new Label(
                            "College Email:"
                    ),
                    0,
                    0
            );

            participantGrid.add(
                    emailField,
                    1,
                    0
            );

            VBox participantBox =
                    new VBox(
                            5,
                            participantLabel,
                            participantGrid
                    );

            content.getChildren()
                    .add(participantBox);
        }

        ScrollPane scrollPane =
                new ScrollPane(content);

        scrollPane.setFitToWidth(true);

        scrollPane.setPrefViewportWidth(
                500
        );

        scrollPane.setPrefViewportHeight(
                Math.min(
                        500,
                        180
                                + additionalStudentCount
                                * 80
                )
        );

        dialog.getDialogPane()
                .setContent(scrollPane);

        dialog.getDialogPane()
                .getButtonTypes()
                .addAll(
                        ButtonType.OK,
                        ButtonType.CANCEL
                );

        dialog.setResultConverter(
                button -> {

                    if (button !=
                            ButtonType.OK) {

                        return null;
                    }

                    List<String> emails =
                            new ArrayList<>();

                    for (TextField field :
                            emailFields) {

                        String email =
                                field.getText()
                                        .trim();

                        if (email.isBlank()) {

                            showError(
                                    "Please enter the college " +
                                    "email of every participant."
                            );

                            return null;
                        }

                        emails.add(email);
                    }

                    return emails;
                }
        );

        Optional<List<String>> result =
                dialog.showAndWait();

        return result.orElse(null);
    }

    private boolean showConfirmation(
            Event event,
            int numberOfSeats,
            List<String> additionalEmails) {

        Alert alert =
                new Alert(
                        Alert.AlertType.CONFIRMATION
                );

        alert.setTitle(
                "Confirm Registration"
        );

        alert.setHeaderText(
                event.getTitle()
        );

        StringBuilder message =
                new StringBuilder();

        message.append(
                "Participants:\n\n"
        );

        /*
         * Logged-in student appears exactly
         * like every other participant here.
         */

        message.append(
                student.getName()
        );

        message.append(
                " - "
        );

        message.append(
                student.getEmail()
        );

        message.append("\n");

        for (String email :
                additionalEmails) {

            message.append(email);
            message.append("\n");
        }

        message.append(
                "\nTotal seats: "
        );

        message.append(
                numberOfSeats
        );

        message.append(
                "\n\nContinue with registration?"
        );

        alert.setContentText(
                message.toString()
        );

        Optional<ButtonType> result =
                alert.showAndWait();

        return result.isPresent()
                && result.get()
                == ButtonType.OK;
    }

    private void showSuccess(
            String message) {

        Alert alert =
                new Alert(
                        Alert.AlertType.INFORMATION
                );

        alert.setTitle(
                "CampusCue"
        );

        alert.setHeaderText(
                "Registration Successful"
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }

    private void showError(
            String message) {

        Alert alert =
                new Alert(
                        Alert.AlertType.ERROR
                );

        alert.setTitle(
                "CampusCue"
        );

        alert.setHeaderText(
                "Registration Error"
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}