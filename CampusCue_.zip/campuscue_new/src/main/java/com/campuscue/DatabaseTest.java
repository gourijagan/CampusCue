package com.campuscue;

import com.campuscue.database.DatabaseConnection;

import java.sql.Connection;

public class DatabaseTest {

    public static void main(String[] args) {

        try {
            Connection connection = DatabaseConnection.getConnection();

            System.out.println("======================================");
            System.out.println("DATABASE CONNECTION SUCCESSFUL!");
            System.out.println("Connected to CampusCue database.");
            System.out.println("======================================");

            connection.close();

        } catch (Exception e) {
            System.out.println("DATABASE CONNECTION FAILED!");
            e.printStackTrace();
        }
    }
}