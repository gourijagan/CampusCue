package com.campuscue.service;

import com.campuscue.dao.StudentDAO;
import com.campuscue.dao.StudentRegistrationRequestDAO;
import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.model.StudentRegistrationRequest;

public class StudentApprovalService {

    private final StudentRegistrationRequestDAO requestDAO;
    private final StudentDAO studentDAO;

    public StudentApprovalService() {
        this.requestDAO = new StudentRegistrationRequestDAO();
        this.studentDAO = new StudentDAO();
    }

    public boolean approveRequest(
            int requestId,
            Faculty approvingFaculty) {

        validateApprovingFaculty(approvingFaculty);

        StudentRegistrationRequest request =
                requestDAO.findById(requestId);

        if (request == null) {
            throw new IllegalArgumentException(
                    "Registration request not found.");
        }

        if (!"PENDING".equals(request.getStatus())) {
            throw new IllegalStateException(
                    "This request has already been reviewed.");
        }

        Student existingStudent =
                studentDAO.findByEmail(request.getEmail());

        if (existingStudent != null) {
            throw new IllegalStateException(
                    "A student with this email already exists.");
        }

        Student student = new Student();

        student.setRegNo(request.getRegNo());
        student.setName(request.getName());
        student.setBatchStartYear(request.getBatchStartYear());
        student.setBatchEndYear(request.getBatchEndYear());
        student.setDepartmentId(request.getDepartmentId());
        student.setEmail(request.getEmail());
        student.setPasswordHash(request.getPasswordHash());
        student.setAccountStatus("ACTIVE");

        boolean studentCreated =
                studentDAO.insert(student);

        if (!studentCreated) {
            return false;
        }

        return requestDAO.updateStatus(
                requestId,
                "APPROVED",
                approvingFaculty.getFacultyId());
    }

    public boolean rejectRequest(
            int requestId,
            Faculty rejectingFaculty) {

        validateApprovingFaculty(rejectingFaculty);

        StudentRegistrationRequest request =
                requestDAO.findById(requestId);

        if (request == null) {
            throw new IllegalArgumentException(
                    "Registration request not found.");
        }

        if (!"PENDING".equals(request.getStatus())) {
            throw new IllegalStateException(
                    "This request has already been reviewed.");
        }

        return requestDAO.updateStatus(
                requestId,
                "REJECTED",
                rejectingFaculty.getFacultyId());
    }

    private void validateApprovingFaculty(Faculty faculty) {

        if (faculty == null) {
            throw new IllegalArgumentException(
                    "Faculty information is required.");
        }

        if (!"ACTIVE".equals(faculty.getAccountStatus())) {
            throw new IllegalStateException(
                    "Faculty account is not active.");
        }

        if (!"SUPER_ADMIN".equals(faculty.getAdminLevel())) {
            throw new SecurityException(
                    "Only super administrators can review registration requests.");
        }
    }
}