package com.campuscue.service;

import com.campuscue.database.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EventCancellationService {

    public void cancelRegistration(
            int registrationId,
            int studentId) {

        Connection connection = null;

        try {

            connection =
                    DatabaseConnection.getConnection();

            connection.setAutoCommit(false);

            /*
             * 1. Find the registration.
             */
            String registrationSql =
                    "SELECT event_id, student_id, " +
                    "number_of_seats, registration_status " +
                    "FROM event_registrations " +
                    "WHERE registration_id = ?";

            int eventId;
            int registeredByStudentId;
            int numberOfSeats;
            String status;

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 registrationSql)) {

                statement.setInt(
                        1,
                        registrationId
                );

                try (ResultSet resultSet =
                             statement.executeQuery()) {

                    if (!resultSet.next()) {

                        throw new IllegalArgumentException(
                                "Registration not found."
                        );
                    }

                    eventId =
                            resultSet.getInt(
                                    "event_id"
                            );

                    registeredByStudentId =
                            resultSet.getInt(
                                    "student_id"
                            );

                    numberOfSeats =
                            resultSet.getInt(
                                    "number_of_seats"
                            );

                    status =
                            resultSet.getString(
                                    "registration_status"
                            );
                }
            }

            /*
             * 2. Only the student account that
             * created this registration can
             * cancel the complete booking.
             */
            if (registeredByStudentId !=
                    studentId) {

                throw new SecurityException(
                        "You cannot cancel this registration."
                );
            }

            /*
             * 3. Prevent cancelling twice.
             */
            if (!"CONFIRMED".equals(status)) {

                throw new IllegalStateException(
                        "This registration is not active."
                );
            }

            /*
             * 4. Delete all participants belonging
             * to this registration.
             *
             * Example:
             *
             * registration 15 = 4 seats
             *
             * All four participant rows are removed.
             */
            String deleteParticipantsSql =
                    "DELETE FROM event_participants " +
                    "WHERE registration_id = ?";

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 deleteParticipantsSql)) {

                statement.setInt(
                        1,
                        registrationId
                );

                int deletedParticipants =
                        statement.executeUpdate();

                /*
                 * This protects us against inconsistent
                 * participant data.
                 */
                if (deletedParticipants !=
                        numberOfSeats) {

                    throw new IllegalStateException(
                            "Participant data is inconsistent. " +
                            "Cancellation stopped."
                    );
                }
            }

            /*
             * 5. Mark the booking as CANCELLED.
             *
             * We don't delete the registration because
             * keeping it gives us registration history.
             */
            String cancelSql =
                    "UPDATE event_registrations " +
                    "SET registration_status = 'CANCELLED' " +
                    "WHERE registration_id = ?";

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 cancelSql)) {

                statement.setInt(
                        1,
                        registrationId
                );

                int rows =
                        statement.executeUpdate();

                if (rows != 1) {

                    throw new IllegalStateException(
                            "Could not cancel registration."
                    );
                }
            }

            /*
             * 6. Return ALL reserved seats.
             *
             * A four-person booking therefore
             * returns four seats.
             */
            String returnSeatsSql =
                    "UPDATE events " +
                    "SET available_seats = " +
                    "CASE " +
                    "WHEN available_seats + ? > total_seats " +
                    "THEN total_seats " +
                    "ELSE available_seats + ? " +
                    "END " +
                    "WHERE event_id = ?";

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 returnSeatsSql)) {

                statement.setInt(
                        1,
                        numberOfSeats
                );

                statement.setInt(
                        2,
                        numberOfSeats
                );

                statement.setInt(
                        3,
                        eventId
                );

                int rows =
                        statement.executeUpdate();

                if (rows != 1) {

                    throw new IllegalStateException(
                            "Could not restore event seats."
                    );
                }
            }

            /*
             * 7. Everything succeeded.
             */
            connection.commit();

        } catch (Exception e) {

            if (connection != null) {

                try {
                    connection.rollback();
                } catch (SQLException ignored) {
                }
            }

            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            }

            throw new RuntimeException(
                    "Cancellation failed: "
                            + e.getMessage(),
                    e
            );

        } finally {

            if (connection != null) {

                try {
                    connection.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }
}