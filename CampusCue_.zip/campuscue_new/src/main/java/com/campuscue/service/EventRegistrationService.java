package com.campuscue.service;

import com.campuscue.dao.EventParticipantDAO;
import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.EventParticipant;
import com.campuscue.model.EventRegistration;
import com.campuscue.model.Student;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EventRegistrationService {

    private final EventParticipantDAO participantDAO;

    public EventRegistrationService() {
        this.participantDAO =
                new EventParticipantDAO();
    }

    public EventRegistration registerStudent(
            int eventId,
            int registeringStudentId,
            int numberOfSeats,
            List<String> additionalStudentEmails) {

        if (numberOfSeats < 1 ||
                numberOfSeats > 8) {

            throw new IllegalArgumentException(
                    "You can register between 1 and 8 seats."
            );
        }

        if (additionalStudentEmails == null) {
            throw new IllegalArgumentException(
                    "Participant information is required."
            );
        }

        if (additionalStudentEmails.size()
                != numberOfSeats - 1) {

            throw new IllegalArgumentException(
                    "Participant count does not match " +
                    "the number of seats."
            );
        }

        Connection connection = null;

        try {

            connection =
                    DatabaseConnection.getConnection();

            connection.setAutoCommit(false);

            /*
             * ------------------------------------------------
             * 1. LOAD THE EVENT
             * ------------------------------------------------
             */

            String eventSql =
                    "SELECT event_id, status, " +
                    "registration_deadline, " +
                    "available_seats " +
                    "FROM events " +
                    "WHERE event_id = ?";

            String eventStatus;
            LocalDateTime deadline;
            int availableSeats;

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 eventSql)) {

                statement.setInt(
                        1,
                        eventId
                );

                try (ResultSet resultSet =
                             statement.executeQuery()) {

                    if (!resultSet.next()) {

                        throw new IllegalArgumentException(
                                "Event not found."
                        );
                    }

                    eventStatus =
                            resultSet.getString(
                                    "status"
                            );

                    deadline =
                            resultSet
                                    .getTimestamp(
                                            "registration_deadline"
                                    )
                                    .toLocalDateTime();

                    availableSeats =
                            resultSet.getInt(
                                    "available_seats"
                            );
                }
            }

            /*
             * ------------------------------------------------
             * 2. VALIDATE EVENT
             * ------------------------------------------------
             */

            if (!"ACTIVE".equals(eventStatus)) {

                throw new IllegalStateException(
                        "This event is not active."
                );
            }

            if (LocalDateTime.now()
                    .isAfter(deadline)) {

                throw new IllegalStateException(
                        "Registration deadline has passed."
                );
            }

            if (availableSeats < numberOfSeats) {

                throw new IllegalStateException(
                        "Not enough seats are available."
                );
            }

            /*
             * ------------------------------------------------
             * 3. LOAD THE STUDENT MAKING THE REGISTRATION
             * ------------------------------------------------
             */

            Student registeringStudent =
                    findStudentById(
                            registeringStudentId,
                            connection
                    );

            if (registeringStudent == null) {

                throw new IllegalArgumentException(
                        "Registering student was not found."
                );
            }

            if (!"ACTIVE".equals(
                    registeringStudent
                            .getAccountStatus())) {

                throw new IllegalStateException(
                        "Your student account is not active."
                );
            }

            /*
             * ------------------------------------------------
             * 4. BUILD COMPLETE PARTICIPANT LIST
             *
             * This list contains:
             *
             * - the logged-in student
             * - every additional verified student
             *
             * No MAIN / MEMBER classification.
             * ------------------------------------------------
             */

            Set<Integer> participantStudentIds =
                    new HashSet<>();

            participantStudentIds.add(
                    registeringStudentId
            );

            for (String email :
                    additionalStudentEmails) {

                if (email == null ||
                        email.isBlank()) {

                    throw new IllegalArgumentException(
                            "Every participant email is required."
                    );
                }

                String cleanedEmail =
                        email.trim();

                Student student =
                        findStudentByEmail(
                                cleanedEmail,
                                connection
                        );

                if (student == null) {

                    throw new IllegalArgumentException(
                            cleanedEmail
                                    + " is not a verified CampusCue student."
                    );
                }

                if (!"ACTIVE".equals(
                        student.getAccountStatus())) {

                    throw new IllegalStateException(
                            cleanedEmail
                                    + " does not have an active account."
                    );
                }

                boolean added =
                        participantStudentIds.add(
                                student.getStudentId()
                        );

                if (!added) {

                    throw new IllegalArgumentException(
                            "The same student cannot be added twice."
                    );
                }
            }

            if (participantStudentIds.size()
                    != numberOfSeats) {

                throw new IllegalStateException(
                        "Participant count does not match " +
                        "the requested seats."
                );
            }

            /*
             * ------------------------------------------------
             * 5. CHECK WHETHER ANY PARTICIPANT IS
             *    ALREADY REGISTERED FOR THIS EVENT
             * ------------------------------------------------
             */

            String participantCheckSql =
                    "SELECT COUNT(*) " +
                    "FROM event_participants " +
                    "WHERE event_id = ? " +
                    "AND student_id = ?";

            for (Integer studentId :
                    participantStudentIds) {

                try (PreparedStatement statement =
                             connection.prepareStatement(
                                     participantCheckSql)) {

                    statement.setInt(
                            1,
                            eventId
                    );

                    statement.setInt(
                            2,
                            studentId
                    );

                    try (ResultSet resultSet =
                                 statement.executeQuery()) {

                        resultSet.next();

                        if (resultSet.getInt(1) > 0) {

                            Student existingStudent =
                                    findStudentById(
                                            studentId,
                                            connection
                                    );

                            throw new IllegalStateException(
                                    existingStudent.getName()
                                            + " is already registered "
                                            + "for this event."
                            );
                        }
                    }
                }
            }

            /*
             * ------------------------------------------------
             * 6. CREATE ONE REGISTRATION RECORD
             * ------------------------------------------------
             */

            String registrationSql =
                    "INSERT INTO event_registrations " +
                    "(event_id, student_id, " +
                    "number_of_seats, registration_status) " +
                    "VALUES (?, ?, ?, 'CONFIRMED')";

            int registrationId;

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 registrationSql,
                                 Statement.RETURN_GENERATED_KEYS)) {

                statement.setInt(
                        1,
                        eventId
                );

                statement.setInt(
                        2,
                        registeringStudentId
                );

                statement.setInt(
                        3,
                        numberOfSeats
                );

                statement.executeUpdate();

                try (ResultSet keys =
                             statement.getGeneratedKeys()) {

                    if (!keys.next()) {

                        throw new SQLException(
                                "Registration ID was not generated."
                        );
                    }

                    registrationId =
                            keys.getInt(1);
                }
            }

            /*
             * ------------------------------------------------
             * 7. INSERT EVERY STUDENT INTO
             *    event_participants
             *
             * INCLUDING THE STUDENT WHO MADE
             * THE REGISTRATION.
             * ------------------------------------------------
             */

            for (Integer studentId :
                    participantStudentIds) {

                EventParticipant participant =
                        new EventParticipant();

                participant.setEventId(
                        eventId
                );

                participant.setRegistrationId(
                        registrationId
                );

                participant.setStudentId(
                        studentId
                );

                participantDAO.insert(
                        participant,
                        connection
                );
            }

            /*
             * ------------------------------------------------
             * 8. REDUCE AVAILABLE SEATS
             * ------------------------------------------------
             */

            String seatUpdateSql =
                    "UPDATE events " +
                    "SET available_seats = " +
                    "available_seats - ? " +
                    "WHERE event_id = ? " +
                    "AND available_seats >= ?";

            try (PreparedStatement statement =
                         connection.prepareStatement(
                                 seatUpdateSql)) {

                statement.setInt(
                        1,
                        numberOfSeats
                );

                statement.setInt(
                        2,
                        eventId
                );

                statement.setInt(
                        3,
                        numberOfSeats
                );

                int rows =
                        statement.executeUpdate();

                if (rows != 1) {

                    throw new IllegalStateException(
                            "Seats are no longer available."
                    );
                }
            }

            /*
             * ------------------------------------------------
             * 9. COMMIT EVERYTHING
             * ------------------------------------------------
             */

            connection.commit();

            EventRegistration registration =
                    new EventRegistration();

            registration.setRegistrationId(
                    registrationId
            );

            registration.setEventId(
                    eventId
            );

            registration.setStudentId(
                    registeringStudentId
            );

            registration.setNumberOfSeats(
                    numberOfSeats
            );

            registration.setRegistrationStatus(
                    "CONFIRMED"
            );

            registration.setRegisteredAt(
                    LocalDateTime.now()
            );

            return registration;

        } catch (Exception e) {

            if (connection != null) {

                try {
                    connection.rollback();
                } catch (SQLException ignored) {
                }
            }

            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            }

            throw new RuntimeException(
                    "Registration failed: "
                            + e.getMessage(),
                    e
            );

        } finally {

            if (connection != null) {

                try {
                    connection.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    /*
     * Find verified student using student ID.
     */
    private Student findStudentById(
            int studentId,
            Connection connection)
            throws SQLException {

        String sql =
                "SELECT student_id, reg_no, name, " +
                "batch_start_year, batch_end_year, " +
                "department_id, email, password_hash, " +
                "account_status " +
                "FROM students " +
                "WHERE student_id = ?";

        try (PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    studentId
            );

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                if (!resultSet.next()) {
                    return null;
                }

                return mapStudent(
                        resultSet
                );
            }
        }
    }

    /*
     * Find verified student using email.
     */
    private Student findStudentByEmail(
            String email,
            Connection connection)
            throws SQLException {

        String sql =
                "SELECT student_id, reg_no, name, " +
                "batch_start_year, batch_end_year, " +
                "department_id, email, password_hash, " +
                "account_status " +
                "FROM students " +
                "WHERE LOWER(email) = LOWER(?)";

        try (PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    email
            );

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                if (!resultSet.next()) {
                    return null;
                }

                return mapStudent(
                        resultSet
                );
            }
        }
    }

    private Student mapStudent(
            ResultSet resultSet)
            throws SQLException {

        Student student =
                new Student();

        student.setStudentId(
                resultSet.getInt(
                        "student_id"
                )
        );

        student.setRegNo(
                resultSet.getString(
                        "reg_no"
                )
        );

        student.setName(
                resultSet.getString(
                        "name"
                )
        );

        student.setBatchStartYear(
                resultSet.getInt(
                        "batch_start_year"
                )
        );

        student.setBatchEndYear(
                resultSet.getInt(
                        "batch_end_year"
                )
        );

        student.setDepartmentId(
                resultSet.getInt(
                        "department_id"
                )
        );

        student.setEmail(
                resultSet.getString(
                        "email"
                )
        );

        student.setPasswordHash(
                resultSet.getString(
                        "password_hash"
                )
        );

        student.setAccountStatus(
                resultSet.getString(
                        "account_status"
                )
        );

        return student;
    }
}