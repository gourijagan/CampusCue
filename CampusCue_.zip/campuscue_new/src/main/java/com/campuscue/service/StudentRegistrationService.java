package com.campuscue.service;

import com.campuscue.dao.StudentRegistrationRequestDAO;
import com.campuscue.model.StudentRegistrationRequest;
import com.campuscue.util.PasswordUtil;

public class StudentRegistrationService {

    private final StudentRegistrationRequestDAO requestDAO;

    public StudentRegistrationService() {
        this.requestDAO = new StudentRegistrationRequestDAO();
    }

    public boolean submitRegistrationRequest(
            String regNo,
            String name,
            int batchStartYear,
            int batchEndYear,
            int departmentId,
            String email,
            String password) {

        validateInput(
                regNo,
                name,
                batchStartYear,
                batchEndYear,
                departmentId,
                email,
                password);

        String passwordHash =
                PasswordUtil.hashPassword(password);

        StudentRegistrationRequest request =
                new StudentRegistrationRequest();

        request.setRegNo(regNo);
        request.setName(name);
        request.setBatchStartYear(batchStartYear);
        request.setBatchEndYear(batchEndYear);
        request.setDepartmentId(departmentId);
        request.setEmail(email);
        request.setPasswordHash(passwordHash);
        request.setStatus("PENDING");

        return requestDAO.insert(request);
    }

    private void validateInput(
            String regNo,
            String name,
            int batchStartYear,
            int batchEndYear,
            int departmentId,
            String email,
            String password) {

        if (regNo == null || regNo.isBlank()) {
            throw new IllegalArgumentException(
                    "Registration number is required.");
        }

        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException(
                    "Name is required.");
        }

        if (batchStartYear <= 0 ||
                batchEndYear <= batchStartYear) {
            throw new IllegalArgumentException(
                    "Invalid batch years.");
        }

        if (departmentId <= 0) {
            throw new IllegalArgumentException(
                    "Invalid department.");
        }

        if (email == null ||
                !email.toLowerCase().endsWith("@jecc.ac.in")) {
            throw new IllegalArgumentException(
                    "Use an approved college email.");
        }

        if (password == null || password.length() < 8) {
            throw new IllegalArgumentException(
                    "Password must contain at least 8 characters.");
        }
    }
}