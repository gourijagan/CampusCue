package com.campuscue;

import com.campuscue.util.PasswordUtil;

public class PasswordHashTest {

    public static void main(String[] args) {

        String password = "AdminPassword123";

        String hash = PasswordUtil.hashPassword(password);

        System.out.println("Password: " + password);
        System.out.println("SHA-256 Hash:");
        System.out.println(hash);
    }
}