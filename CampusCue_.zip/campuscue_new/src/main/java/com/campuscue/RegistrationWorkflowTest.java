package com.campuscue;

import com.campuscue.dao.StudentRegistrationRequestDAO;
import com.campuscue.dao.StudentDAO;
import com.campuscue.dao.FacultyDAO;
import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.model.StudentRegistrationRequest;
import com.campuscue.service.StudentApprovalService;
import com.campuscue.service.StudentRegistrationService;

public class RegistrationWorkflowTest {

    public static void main(String[] args) {

        String testEmail = "teststudent2.cs25@jecc.ac.in";
String testRegNo = "TEST-CS-25002";

        try {
            // 1. Submit registration request
            StudentRegistrationService registrationService =
                    new StudentRegistrationService();

            boolean requestSubmitted =
                    registrationService.submitRegistrationRequest(
                            testRegNo,
                            "Test Student",
                            2025,
                            2029,
                            1,
                            testEmail,
                            "TestPassword123"
                    );

            System.out.println(
                    "Registration request submitted: "
                            + requestSubmitted);

            // 2. Find the newly created request
            StudentRegistrationRequestDAO requestDAO =
                    new StudentRegistrationRequestDAO();

            StudentRegistrationRequest request = null;

            for (StudentRegistrationRequest item :
                    requestDAO.findPendingRequests()) {

                if (testEmail.equals(item.getEmail())) {
                    request = item;
                    break;
                }
            }

            if (request == null) {
                throw new RuntimeException(
                        "Test registration request was not found.");
            }

            System.out.println(
                    "Request ID: " + request.getRequestId());

            // 3. Find the test super-admin
            FacultyDAO facultyDAO = new FacultyDAO();

            Faculty admin =
                    facultyDAO.findByFacultyId("FAC-CS-001");

            if (admin == null) {
                throw new RuntimeException(
                        "Test admin was not found.");
            }

            System.out.println(
                    "Approving faculty: " + admin.getName());

            // 4. Approve the request
            StudentApprovalService approvalService =
                    new StudentApprovalService();

            boolean approved =
                    approvalService.approveRequest(
                            request.getRequestId(),
                            admin
                    );

            System.out.println(
                    "Request approved: " + approved);

            // 5. Verify student was created
            StudentDAO studentDAO = new StudentDAO();

            Student student =
                    studentDAO.findByEmail(testEmail);

            if (student == null) {
                throw new RuntimeException(
                        "Student was not created.");
            }

            System.out.println();
            System.out.println("======================================");
            System.out.println("REGISTRATION WORKFLOW SUCCESSFUL!");
            System.out.println("======================================");
            System.out.println("Student ID: "
                    + student.getStudentId());
            System.out.println("Registration No: "
                    + student.getRegNo());
            System.out.println("Name: "
                    + student.getName());
            System.out.println("Email: "
                    + student.getEmail());
            System.out.println("Status: "
                    + student.getAccountStatus());
            System.out.println("======================================");

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "REGISTRATION WORKFLOW FAILED!");

            e.printStackTrace();
        }
    }
}