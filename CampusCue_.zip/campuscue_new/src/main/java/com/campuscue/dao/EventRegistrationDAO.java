package com.campuscue.dao;

import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.EventRegistration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class EventRegistrationDAO {

    public int insert(EventRegistration registration) {

        String sql =
                "INSERT INTO event_registrations " +
                "(event_id, student_id, number_of_seats, " +
                "registration_status) " +
                "VALUES (?, ?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(
                                sql,
                                java.sql.Statement.RETURN_GENERATED_KEYS
                        )
        ) {

            statement.setInt(
                    1,
                    registration.getEventId()
            );

            statement.setInt(
                    2,
                    registration.getStudentId()
            );

            statement.setInt(
                    3,
                    registration.getNumberOfSeats()
            );

            statement.setString(
                    4,
                    registration.getRegistrationStatus()
            );

            statement.executeUpdate();

            try (ResultSet keys =
                         statement.getGeneratedKeys()) {

                if (keys.next()) {

                    int registrationId =
                            keys.getInt(1);

                    registration.setRegistrationId(
                            registrationId
                    );

                    return registrationId;
                }

            }

        } catch (SQLException e) {

            throw new RuntimeException(
                    "Failed to create event registration.",
                    e
            );
        }

        return -1;
    }

    public EventRegistration findById(
            int registrationId) {

        String sql =
                "SELECT registration_id, event_id, " +
                "student_id, number_of_seats, " +
                "registration_status, registered_at " +
                "FROM event_registrations " +
                "WHERE registration_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, registrationId);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapRegistration(resultSet);
                }
            }

        } catch (SQLException e) {

            throw new RuntimeException(
                    "Failed to find registration.",
                    e
            );
        }

        return null;
    }

    public List<EventRegistration>
    findByStudentId(int studentId) {

        String sql =
                "SELECT registration_id, event_id, " +
                "student_id, number_of_seats, " +
                "registration_status, registered_at " +
                "FROM event_registrations " +
                "WHERE student_id = ? " +
                "ORDER BY registered_at DESC";

        List<EventRegistration> registrations =
                new ArrayList<>();

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, studentId);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                while (resultSet.next()) {

                    registrations.add(
                            mapRegistration(resultSet)
                    );
                }
            }

        } catch (SQLException e) {

            throw new RuntimeException(
                    "Failed to find student registrations.",
                    e
            );
        }

        return registrations;
    }

    public List<EventRegistration>
    findByEventId(int eventId) {

        String sql =
                "SELECT registration_id, event_id, " +
                "student_id, number_of_seats, " +
                "registration_status, registered_at " +
                "FROM event_registrations " +
                "WHERE event_id = ? " +
                "ORDER BY registered_at";

        List<EventRegistration> registrations =
                new ArrayList<>();

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, eventId);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                while (resultSet.next()) {

                    registrations.add(
                            mapRegistration(resultSet)
                    );
                }
            }

        } catch (SQLException e) {

            throw new RuntimeException(
                    "Failed to find event registrations.",
                    e
            );
        }

        return registrations;
    }

    private EventRegistration mapRegistration(
            ResultSet resultSet)
            throws SQLException {

        EventRegistration registration =
                new EventRegistration();

        registration.setRegistrationId(
                resultSet.getInt("registration_id")
        );

        registration.setEventId(
                resultSet.getInt("event_id")
        );

        registration.setStudentId(
                resultSet.getInt("student_id")
        );

        registration.setNumberOfSeats(
                resultSet.getInt("number_of_seats")
        );

        registration.setRegistrationStatus(
                resultSet.getString(
                        "registration_status"
                )
        );

        Timestamp timestamp =
                resultSet.getTimestamp("registered_at");

        if (timestamp != null) {
            registration.setRegisteredAt(
                    timestamp.toLocalDateTime()
            );
        }

        return registration;
    }
}