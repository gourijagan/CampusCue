package com.campuscue.dao;

import com.campuscue.model.EventParticipant;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EventParticipantDAO {

    public void insert(
            EventParticipant participant,
            Connection connection) throws SQLException {

        String sql =
                "INSERT INTO event_participants " +
                "(event_id, registration_id, student_id) " +
                "VALUES (?, ?, ?)";

        try (PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    participant.getEventId()
            );

            statement.setInt(
                    2,
                    participant.getRegistrationId()
            );

            statement.setInt(
                    3,
                    participant.getStudentId()
            );

            statement.executeUpdate();
        }
    }

    public List<EventParticipant>
    findByEventId(int eventId) {

        List<EventParticipant> participants =
                new ArrayList<>();

        String sql =
                "SELECT participant_id, event_id, " +
                "registration_id, student_id " +
                "FROM event_participants " +
                "WHERE event_id = ? " +
                "ORDER BY participant_id";

        try (
                Connection connection =
                        com.campuscue.database
                                .DatabaseConnection
                                .getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, eventId);

            try (ResultSet resultSet =
                         statement.executeQuery()) {

                while (resultSet.next()) {

                    EventParticipant participant =
                            new EventParticipant();

                    participant.setParticipantId(
                            resultSet.getInt(
                                    "participant_id"
                            )
                    );

                    participant.setEventId(
                            resultSet.getInt(
                                    "event_id"
                            )
                    );

                    participant.setRegistrationId(
                            resultSet.getInt(
                                    "registration_id"
                            )
                    );

                    participant.setStudentId(
                            resultSet.getInt(
                                    "student_id"
                            )
                    );

                    participants.add(
                            participant
                    );
                }
            }

        } catch (SQLException e) {

            throw new RuntimeException(
                    "Failed to load event participants.",
                    e
            );
        }

        return participants;
    }
}