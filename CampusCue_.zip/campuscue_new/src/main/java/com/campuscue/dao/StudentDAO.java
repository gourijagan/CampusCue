package com.campuscue.dao;

import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public Student findByEmail(String email) {

        String sql = """
                SELECT student_id,
                       reg_no,
                       name,
                       batch_start_year,
                       batch_end_year,
                       department_id,
                       email,
                       password_hash,
                       account_status
                FROM students
                WHERE email = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, email);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapStudent(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public Student findByRegNo(String regNo) {

        String sql = """
                SELECT student_id,
                       reg_no,
                       name,
                       batch_start_year,
                       batch_end_year,
                       department_id,
                       email,
                       password_hash,
                       account_status
                FROM students
                WHERE reg_no = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, regNo);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapStudent(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<Student> findAll() {

        List<Student> students = new ArrayList<>();

        String sql = """
                SELECT student_id,
                       reg_no,
                       name,
                       batch_start_year,
                       batch_end_year,
                       department_id,
                       email,
                       password_hash,
                       account_status
                FROM students
                ORDER BY name
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                students.add(mapStudent(resultSet));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return students;
    }

    public boolean insert(Student student) {

        String sql = """
                INSERT INTO students
                (
                    reg_no,
                    name,
                    batch_start_year,
                    batch_end_year,
                    department_id,
                    email,
                    password_hash,
                    account_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, student.getRegNo());
            statement.setString(2, student.getName());
            statement.setInt(3, student.getBatchStartYear());
            statement.setInt(4, student.getBatchEndYear());
            statement.setInt(5, student.getDepartmentId());
            statement.setString(6, student.getEmail());
            statement.setString(7, student.getPasswordHash());
            statement.setString(8, student.getAccountStatus());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private Student mapStudent(ResultSet resultSet) throws Exception {

        Student student = new Student();

        student.setStudentId(resultSet.getInt("student_id"));
        student.setRegNo(resultSet.getString("reg_no"));
        student.setName(resultSet.getString("name"));
        student.setBatchStartYear(resultSet.getInt("batch_start_year"));
        student.setBatchEndYear(resultSet.getInt("batch_end_year"));
        student.setDepartmentId(resultSet.getInt("department_id"));
        student.setEmail(resultSet.getString("email"));
        student.setPasswordHash(resultSet.getString("password_hash"));
        student.setAccountStatus(resultSet.getString("account_status"));

        return student;
    }
}