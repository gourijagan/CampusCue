package com.campuscue.dao;

import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.Event;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {

    public boolean insert(Event event) {

        String sql = """
                INSERT INTO events
                (
                    title,
                    description,
                    event_type,
                    department_id,
                    venue,
                    event_date,
                    start_time,
                    end_time,
                    registration_deadline,
                    total_seats,
                    available_seats,
                    eligibility,
                    status,
                    created_by_faculty_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, event.getTitle());
            statement.setString(2, event.getDescription());
            statement.setString(3, event.getEventType());

            if (event.getDepartmentId() == null) {
                statement.setNull(4, java.sql.Types.INTEGER);
            } else {
                statement.setInt(4, event.getDepartmentId());
            }

            statement.setString(5, event.getVenue());
            statement.setDate(
                    6,
                    java.sql.Date.valueOf(event.getEventDate())
            );
            statement.setTime(
                    7,
                    java.sql.Time.valueOf(event.getStartTime())
            );
            statement.setTime(
                    8,
                    java.sql.Time.valueOf(event.getEndTime())
            );
            statement.setTimestamp(
                    9,
                    java.sql.Timestamp.valueOf(
                            event.getRegistrationDeadline()
                    )
            );

            statement.setInt(10, event.getTotalSeats());
            statement.setInt(11, event.getAvailableSeats());
            statement.setString(12, event.getEligibility());
            statement.setString(13, event.getStatus());
            statement.setString(14, event.getCreatedByFacultyId());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Event> findActiveEvents() {

        List<Event> events = new ArrayList<>();

        String sql = """
                SELECT
                    event_id,
                    title,
                    description,
                    event_type,
                    department_id,
                    venue,
                    event_date,
                    start_time,
                    end_time,
                    registration_deadline,
                    total_seats,
                    available_seats,
                    eligibility,
                    status,
                    created_by_faculty_id,
                    created_at
                FROM events
                WHERE status = 'ACTIVE'
                ORDER BY event_date, start_time
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                events.add(mapEvent(resultSet));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return events;
    }

    public Event findById(int eventId) {

        String sql = """
                SELECT
                    event_id,
                    title,
                    description,
                    event_type,
                    department_id,
                    venue,
                    event_date,
                    start_time,
                    end_time,
                    registration_deadline,
                    total_seats,
                    available_seats,
                    eligibility,
                    status,
                    created_by_faculty_id,
                    created_at
                FROM events
                WHERE event_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, eventId);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapEvent(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private Event mapEvent(ResultSet resultSet) throws Exception {

        Event event = new Event();

        event.setEventId(
                resultSet.getInt("event_id")
        );

        event.setTitle(
                resultSet.getString("title")
        );

        event.setDescription(
                resultSet.getString("description")
        );

        event.setEventType(
                resultSet.getString("event_type")
        );

        int departmentId =
                resultSet.getInt("department_id");

        if (resultSet.wasNull()) {
            event.setDepartmentId(null);
        } else {
            event.setDepartmentId(departmentId);
        }

        event.setVenue(
                resultSet.getString("venue")
        );

        event.setEventDate(
                resultSet.getDate("event_date")
                        .toLocalDate()
        );

        event.setStartTime(
                resultSet.getTime("start_time")
                        .toLocalTime()
        );

        event.setEndTime(
                resultSet.getTime("end_time")
                        .toLocalTime()
        );

        event.setRegistrationDeadline(
                resultSet.getTimestamp("registration_deadline")
                        .toLocalDateTime()
        );

        event.setTotalSeats(
                resultSet.getInt("total_seats")
        );

        event.setAvailableSeats(
                resultSet.getInt("available_seats")
        );

        event.setEligibility(
                resultSet.getString("eligibility")
        );

        event.setStatus(
                resultSet.getString("status")
        );

        event.setCreatedByFacultyId(
                resultSet.getString("created_by_faculty_id")
        );

        if (resultSet.getTimestamp("created_at") != null) {
            event.setCreatedAt(
                    resultSet.getTimestamp("created_at")
                            .toLocalDateTime()
            );
        }

        return event;
    }
}