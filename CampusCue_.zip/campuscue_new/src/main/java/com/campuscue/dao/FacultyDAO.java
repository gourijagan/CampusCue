package com.campuscue.dao;

import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.Faculty;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FacultyDAO {

    public Faculty findByEmail(String email) {

        String sql = """
                SELECT faculty_id,
                       name,
                       email,
                       department_id,
                       designation,
                       admin_level,
                       password_hash,
                       account_status
                FROM faculty
                WHERE email = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, email);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapFaculty(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public Faculty findByFacultyId(String facultyId) {

        String sql = """
                SELECT faculty_id,
                       name,
                       email,
                       department_id,
                       designation,
                       admin_level,
                       password_hash,
                       account_status
                FROM faculty
                WHERE faculty_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, facultyId);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapFaculty(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<Faculty> findAll() {

        List<Faculty> facultyList = new ArrayList<>();

        String sql = """
                SELECT faculty_id,
                       name,
                       email,
                       department_id,
                       designation,
                       admin_level,
                       password_hash,
                       account_status
                FROM faculty
                ORDER BY name
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                facultyList.add(mapFaculty(resultSet));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return facultyList;
    }

    public boolean insert(Faculty faculty) {

        String sql = """
                INSERT INTO faculty
                (
                    faculty_id,
                    name,
                    email,
                    department_id,
                    designation,
                    admin_level,
                    password_hash,
                    account_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, faculty.getFacultyId());
            statement.setString(2, faculty.getName());
            statement.setString(3, faculty.getEmail());

            if (faculty.getDepartmentId() == null) {
                statement.setNull(4, java.sql.Types.INTEGER);
            } else {
                statement.setInt(4, faculty.getDepartmentId());
            }

            statement.setString(5, faculty.getDesignation());
            statement.setString(6, faculty.getAdminLevel());
            statement.setString(7, faculty.getPasswordHash());
            statement.setString(8, faculty.getAccountStatus());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private Faculty mapFaculty(ResultSet resultSet) throws Exception {

        Faculty faculty = new Faculty();

        faculty.setFacultyId(resultSet.getString("faculty_id"));
        faculty.setName(resultSet.getString("name"));
        faculty.setEmail(resultSet.getString("email"));

        int departmentId = resultSet.getInt("department_id");

        if (resultSet.wasNull()) {
            faculty.setDepartmentId(null);
        } else {
            faculty.setDepartmentId(departmentId);
        }

        faculty.setDesignation(resultSet.getString("designation"));
        faculty.setAdminLevel(resultSet.getString("admin_level"));
        faculty.setPasswordHash(resultSet.getString("password_hash"));
        faculty.setAccountStatus(resultSet.getString("account_status"));

        return faculty;
    }
}