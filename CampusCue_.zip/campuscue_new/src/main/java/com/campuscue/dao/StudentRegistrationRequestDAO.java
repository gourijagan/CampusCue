package com.campuscue.dao;

import com.campuscue.database.DatabaseConnection;
import com.campuscue.model.StudentRegistrationRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentRegistrationRequestDAO {

    public boolean insert(StudentRegistrationRequest request) {

        String sql = """
                INSERT INTO student_registration_requests
                (
                    reg_no,
                    name,
                    batch_start_year,
                    batch_end_year,
                    department_id,
                    email,
                    password_hash,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, request.getRegNo());
            statement.setString(2, request.getName());
            statement.setInt(3, request.getBatchStartYear());
            statement.setInt(4, request.getBatchEndYear());
            statement.setInt(5, request.getDepartmentId());
            statement.setString(6, request.getEmail());
            statement.setString(7, request.getPasswordHash());
            statement.setString(8, request.getStatus());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public StudentRegistrationRequest findById(int requestId) {

        String sql = """
                SELECT request_id,
                       reg_no,
                       name,
                       batch_start_year,
                       batch_end_year,
                       department_id,
                       email,
                       password_hash,
                       status,
                       requested_at,
                       reviewed_at,
                       reviewed_by_faculty_id
                FROM student_registration_requests
                WHERE request_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, requestId);

            try (ResultSet resultSet = statement.executeQuery()) {

                if (resultSet.next()) {
                    return mapRequest(resultSet);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<StudentRegistrationRequest> findPendingRequests() {

        List<StudentRegistrationRequest> requests = new ArrayList<>();

        String sql = """
                SELECT request_id,
                       reg_no,
                       name,
                       batch_start_year,
                       batch_end_year,
                       department_id,
                       email,
                       password_hash,
                       status,
                       requested_at,
                       reviewed_at,
                       reviewed_by_faculty_id
                FROM student_registration_requests
                WHERE status = 'PENDING'
                ORDER BY requested_at
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                requests.add(mapRequest(resultSet));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return requests;
    }

    public boolean updateStatus(
            int requestId,
            String status,
            String reviewedByFacultyId) {

        String sql = """
                UPDATE student_registration_requests
                SET status = ?,
                    reviewed_at = SYSDATETIME(),
                    reviewed_by_faculty_id = ?
                WHERE request_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, status);
            statement.setString(2, reviewedByFacultyId);
            statement.setInt(3, requestId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private StudentRegistrationRequest mapRequest(
            ResultSet resultSet) throws Exception {

        StudentRegistrationRequest request =
                new StudentRegistrationRequest();

        request.setRequestId(resultSet.getInt("request_id"));
        request.setRegNo(resultSet.getString("reg_no"));
        request.setName(resultSet.getString("name"));
        request.setBatchStartYear(
                resultSet.getInt("batch_start_year"));
        request.setBatchEndYear(
                resultSet.getInt("batch_end_year"));
        request.setDepartmentId(
                resultSet.getInt("department_id"));
        request.setEmail(resultSet.getString("email"));
        request.setPasswordHash(
                resultSet.getString("password_hash"));
        request.setStatus(resultSet.getString("status"));

        if (resultSet.getTimestamp("requested_at") != null) {
            request.setRequestedAt(
                    resultSet.getTimestamp("requested_at")
                            .toLocalDateTime());
        }

        if (resultSet.getTimestamp("reviewed_at") != null) {
            request.setReviewedAt(
                    resultSet.getTimestamp("reviewed_at")
                            .toLocalDateTime());
        }

        request.setReviewedByFacultyId(
                resultSet.getString("reviewed_by_faculty_id"));

        return request;
    }
}