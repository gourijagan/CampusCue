package com.campuscue.util;

import com.campuscue.model.Event;

import java.util.Comparator;

public class EventPriorityComparator
        implements Comparator<Event> {

    @Override
    public int compare(Event first, Event second) {

        int firstPriority =
                getPriorityValue(first);

        int secondPriority =
                getPriorityValue(second);

        // Higher priority appears first
        if (firstPriority != secondPriority) {
            return Integer.compare(
                    secondPriority,
                    firstPriority
            );
        }

        // If priority is equal,
        // earlier registration deadline comes first.
        return first.getRegistrationDeadline()
                .compareTo(
                        second.getRegistrationDeadline()
                );
    }

    private int getPriorityValue(Event event) {

        String label =
                EventPriorityUtil.getPriorityLabel(event);

        return switch (label) {

            case "Closing Soon" -> 4;

            case "Filling Fast" -> 3;

            case "Plenty Seats" -> 2;

            case "Full" -> 1;

            case "Registration Closed" -> 0;

            default -> 0;
        };
    }
}