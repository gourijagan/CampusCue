package com.campuscue.util;

import com.campuscue.model.Event;

import java.time.Duration;
import java.time.LocalDateTime;

public class EventPriorityUtil {

    private EventPriorityUtil() {
    }

    public static String getPriorityLabel(Event event) {

        LocalDateTime now = LocalDateTime.now();

        // Registration deadline has passed
        if (now.isAfter(event.getRegistrationDeadline())) {
            return "Registration Closed";
        }

        // No seats remaining
        if (event.getAvailableSeats() == 0) {
            return "Full";
        }

        // Deadline is within 24 hours
        Duration remainingTime = Duration.between(
                now,
                event.getRegistrationDeadline()
        );

        if (remainingTime.toHours() <= 24) {
            return "Closing Soon";
        }

        // 20% or less seats remaining
        double availablePercentage =
                (event.getAvailableSeats() * 100.0)
                        / event.getTotalSeats();

        if (availablePercentage <= 20) {
            return "Filling Fast";
        }

        return "Plenty Seats";
    }
}