package com.campuscue;

import com.campuscue.model.Student;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StudentDashboard {

    private final Student student;

    public StudentDashboard(Student student) {
        this.student = student;
    }

    public void show(Stage stage) {

        Label title = new Label("CAMPUSCUE");
        title.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;"
        );

        Label welcome = new Label(
                "Welcome, " + student.getName() + "!"
        );
        welcome.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;"
        );

        Label department = new Label(
                "Department ID: " + student.getDepartmentId()
        );

        Label batch = new Label(
                "Batch: "
                        + student.getBatchStartYear()
                        + " - "
                        + student.getBatchEndYear()
        );

        Label eventsTitle =
                new Label("Upcoming Campus Events");

        eventsTitle.setStyle(
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;"
        );

        Button viewEventsButton =
                new Button("VIEW EVENTS");

        viewEventsButton.setPrefWidth(180);
        viewEventsButton.setPrefHeight(40);
        viewEventsButton.setOnAction(event -> {

    EventListView eventListView =
            new EventListView(student);

    eventListView.show(
            stage,
            this
    );
});

        Button myRegistrationsButton =
                new Button("MY REGISTRATIONS");

        myRegistrationsButton.setPrefWidth(180);
myRegistrationsButton.setPrefHeight(40);

myRegistrationsButton.setOnAction(event -> {

    MyRegistrationsView registrationsView =
            new MyRegistrationsView(student);

    registrationsView.show(
            stage,
            this
    );
});

        Button logoutButton =
                new Button("LOGOUT");

        logoutButton.setPrefWidth(180);
        logoutButton.setPrefHeight(40);

        logoutButton.setOnAction(event -> {
            new Main().start(stage);
        });

        VBox root = new VBox(15);

        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40));

        root.getChildren().addAll(
                title,
                welcome,
                department,
                batch,
                eventsTitle,
                viewEventsButton,
                myRegistrationsButton,
                logoutButton
        );

        root.setStyle(
                "-fx-background-color: #f5f7fa;"
        );

        Scene scene = new Scene(root, 700, 600);

        stage.setTitle("CampusCue - Student Dashboard");
        stage.setScene(scene);
        stage.show();
    }
}