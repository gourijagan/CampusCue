# CampusCue UI refresh

## Design direction
A calm, polished campus productivity interface: ink/navy text, crisp white surfaces, a confident indigo action color, soft blue information panels, restrained green status cues, and a light slate canvas. DM Sans and Manrope create a readable, modern hierarchy.

## What changed
- Replaced starter-template global styles and forced dark-mode defaults with a consistent, light-first visual system.
- Normalized typography, spacing, page widths, surface borders, corner radii, shadows, form controls, focus states, buttons, and link treatment.
- Improved student/faculty dashboard and event-list layout, including card alignment, flexible card content, responsive grids, and hover feedback.
- Refined login, event details, registration forms, tables, status labels, and seating surface styling without changing their React logic.
- Added mobile/tablet breakpoints, keyboard focus visibility, reduced-motion support, and stronger text contrast.

## Functionality preservation
The UI refresh intentionally changes only `frontend/src/index.css` and adds a style override layer to `frontend/src/App.css`. React components, routes, requests, authentication, registration, seating, event management, and backend files were not edited.

## Notes
The font stylesheet uses Google Fonts when internet access is available; system fallbacks are included. Run `npm install` and `npm run build` inside `frontend` to validate in your environment. The backend's database and environment settings remain unchanged.
