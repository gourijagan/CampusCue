package com.campuscue.model;

import jakarta.persistence.*;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "student_id")
    private Integer studentId;

    @Column(name = "reg_no", nullable = false)
    private String regNo;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "batch_start_year", nullable = false)
    private Integer batchStartYear;

    @Column(name = "batch_end_year", nullable = false)
    private Integer batchEndYear;

    @Column(name = "department_id", nullable = false)
    private Integer departmentId;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "account_status", nullable = false)
    private String accountStatus;

    @Column(name = "tutor_faculty_id")
    private String tutorFacultyId;

    public Student() {
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBatchStartYear() {
        return batchStartYear;
    }

    public void setBatchStartYear(Integer batchStartYear) {
        this.batchStartYear = batchStartYear;
    }

    public Integer getBatchEndYear() {
        return batchEndYear;
    }

    public void setBatchEndYear(Integer batchEndYear) {
        this.batchEndYear = batchEndYear;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getTutorFacultyId() {
        return tutorFacultyId;
    }

    public void setTutorFacultyId(String tutorFacultyId) {
        this.tutorFacultyId = tutorFacultyId;
    }
}