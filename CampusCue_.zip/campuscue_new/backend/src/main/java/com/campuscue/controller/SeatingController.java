package com.campuscue.controller;

import com.campuscue.dto.SeatingConfigRequest;
import com.campuscue.service.SeatingService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class SeatingController {

    private final SeatingService seatingService;

    public SeatingController(SeatingService seatingService) {
        this.seatingService = seatingService;
    }

    @PutMapping("/{eventId}/seating/config")
    public ResponseEntity<?> configureSeating(
            @PathVariable Integer eventId,
            @RequestBody SeatingConfigRequest request,
            HttpSession session) {

        if (!isFaculty(session)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", "Faculty login required."
                    ));
        }

        try {
            String facultyId = getUserId(session);

            if (facultyId == null) {
                return ResponseEntity
                        .status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of(
                                "success", false,
                                "message", "Faculty session is invalid."
                        ));
            }

            Object config = seatingService.configureSeating(
                    eventId,
                    request,
                    facultyId
            );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Seating configuration saved.",
                            "config", config
                    )
            );

        } catch (IllegalArgumentException e) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (Exception e) {
            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to configure seating."
                    ));
        }
    }

    @GetMapping("/{eventId}/seating")
    public ResponseEntity<?> getSeating(
            @PathVariable Integer eventId) {

        try {
            return ResponseEntity.ok(
                    seatingService.getSeating(eventId)
            );

        } catch (Exception e) {
            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to load seating information."
                    ));
        }
    }

    @PostMapping("/{eventId}/seating/hold")
    public ResponseEntity<?> holdSeats(
            @PathVariable Integer eventId,
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        if (!isStudent(session)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", "Student login required."
                    ));
        }

        try {
            Integer studentId = getIntegerUserId(session);

            if (studentId == null) {
                return ResponseEntity
                        .status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of(
                                "success", false,
                                "message", "Student session is invalid."
                        ));
            }

            Object rawSeatIds = body.get("seatIds");

            if (!(rawSeatIds instanceof List<?>)) {
                return ResponseEntity
                        .badRequest()
                        .body(Map.of(
                                "success", false,
                                "message", "seatIds must be an array."
                        ));
            }

            List<Integer> seatIds = ((List<?>) rawSeatIds)
                    .stream()
                    .map(this::convertToInteger)
                    .toList();

            if (seatIds.isEmpty()) {
                return ResponseEntity
                        .badRequest()
                        .body(Map.of(
                                "success", false,
                                "message", "At least one seat must be selected."
                        ));
            }

            System.out.println("========================================");
            System.out.println("SEAT HOLD REQUEST");
            System.out.println("Event ID  : " + eventId);
            System.out.println("Student ID: " + studentId);
            System.out.println("Seat IDs  : " + seatIds);
            System.out.println("========================================");

            Map<String, Object> result = seatingService.holdSeats(
                    eventId,
                    studentId,
                    seatIds
            );

            System.out.println("SEAT HOLD SUCCESS");
            System.out.println(result);

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Seats temporarily held.",
                            "data", result
                    )
            );

        } catch (IllegalArgumentException e) {

            e.printStackTrace();

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Invalid seat hold request."
                    ));

        } catch (IllegalStateException e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Selected seats cannot be held."
                    ));

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to hold selected seats."
                    ));
        }
    }

    @DeleteMapping("/{eventId}/seating/holds/{holdToken}")
    public ResponseEntity<?> releaseHold(
            @PathVariable Integer eventId,
            @PathVariable String holdToken,
            HttpSession session) {

        if (!isStudent(session)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", "Student login required."
                    ));
        }

        try {
            Integer studentId = getIntegerUserId(session);

            if (studentId == null) {
                return ResponseEntity
                        .status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of(
                                "success", false,
                                "message", "Student session is invalid."
                        ));
            }

            seatingService.releaseHold(
                    eventId,
                    studentId,
                    holdToken
            );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Seat hold released."
                    )
            );

        } catch (IllegalArgumentException e) {

            e.printStackTrace();

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Invalid seat hold."
                    ));

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to release seat hold."
                    ));
        }
    }

    @DeleteMapping("/seating/registration/{registrationId}")
    public ResponseEntity<?> releaseRegistrationSeats(
            @PathVariable Integer registrationId,
            HttpSession session) {

        if (!isFaculty(session)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", "Faculty login required."
                    ));
        }

        try {
            seatingService.releaseRegistrationSeats(
                    registrationId
            );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Registration seats released."
                    )
            );

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to release registration seats."
                    ));
        }
    }

    @PostMapping("/seating/cleanup-holds")
    public ResponseEntity<?> cleanupExpiredHolds(
            HttpSession session) {

        if (!isFaculty(session)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", "Faculty login required."
                    ));
        }

        try {
            seatingService.cleanupExpiredHolds();

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Expired seat holds cleaned up."
                    )
            );

        } catch (Exception e) {

            e.printStackTrace();

            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage() != null
                                    ? e.getMessage()
                                    : "Unable to clean expired holds."
                    ));
        }
    }

    private boolean isFaculty(HttpSession session) {
        return "FACULTY".equals(
                session.getAttribute("userType")
        );
    }

    private boolean isStudent(HttpSession session) {
        return "STUDENT".equals(
                session.getAttribute("userType")
        );
    }

    private String getUserId(HttpSession session) {
        Object value = session.getAttribute("userId");

        if (value == null) {
            return null;
        }

        return String.valueOf(value);
    }

    private Integer getIntegerUserId(HttpSession session) {
        Object value = session.getAttribute("userId");

        return convertToInteger(value);
    }

    private Integer convertToInteger(Object value) {

        if (value == null) {
            return null;
        }

        if (value instanceof Number number) {
            return number.intValue();
        }

        return Integer.valueOf(
                String.valueOf(value)
        );
    }
}