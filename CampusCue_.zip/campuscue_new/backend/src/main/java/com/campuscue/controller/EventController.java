package com.campuscue.controller;

import com.campuscue.dto.EventCreateRequest;
import com.campuscue.dto.EventUpdateRequest;
import com.campuscue.model.Event;
import com.campuscue.service.EventService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping
    public List<Event> getActiveEvents() {
        return eventService.getActiveEvents();
    }

    @GetMapping("/{eventId}")
    public ResponseEntity<?> getEvent(
            @PathVariable Integer eventId) {

        try {

            Event event =
                    eventService.getActiveEventById(eventId);

            return ResponseEntity.ok(event);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));
        }
    }

    @PostMapping
    public ResponseEntity<?> createEvent(
            @RequestBody EventCreateRequest request,
            HttpSession session) {

        Object userType = session.getAttribute("userType");
        Object userId = session.getAttribute("userId");
        Object adminLevel = session.getAttribute("adminLevel");

        if (userType == null || userId == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", "You must be logged in."
                    ));
        }

        if (!"FACULTY".equals(userType)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Only faculty can create events."
                    ));
        }

        /*
         * Both NORMAL FACULTY and SUPER ADMIN
         * are allowed to create events.
         */
        if (adminLevel == null ||
                (!"NORMAL".equals(adminLevel)
                        && !"SUPER_ADMIN".equals(adminLevel))) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "You do not have permission to create events."
                    ));
        }

        try {

            String facultyId = (String) userId;

            Event event =
                    eventService.createEvent(
                            request,
                            facultyId
                    );

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(Map.of(
                            "success", true,
                            "message", "Event created successfully.",
                            "eventId", event.getEventId(),
                            "title", event.getTitle(),
                            "availableSeats",
                            event.getAvailableSeats()
                    ));

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));
        }
    }

    /*
     * Update an existing event.
     *
     * Allowed:
     * - Faculty
     * - Super Admin
     * - Assigned Student Coordinator
     */
    @PutMapping("/{eventId}")
    public ResponseEntity<?> updateEvent(
            @PathVariable Integer eventId,
            @RequestBody EventUpdateRequest request,
            HttpSession session) {

        String userType =
                (String) session.getAttribute("userType");

        String userId =
                (String) session.getAttribute("userId");

        if (userType == null || userId == null) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", "You must be logged in."
                    ));
        }

        try {

            Event updatedEvent =
                    eventService.updateEvent(
                            eventId,
                            request,
                            userType,
                            userId
                    );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message", "Event updated successfully.",
                            "event", updatedEvent
                    )
            );

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));
        }
    }

    @GetMapping("/faculty/my-events")
    public ResponseEntity<?> getMyEvents(
            HttpSession session) {

        String userType =
                (String) session.getAttribute("userType");

        String facultyId =
                (String) session.getAttribute("userId");

        if (!"FACULTY".equals(userType)
                || facultyId == null) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "message",
                            "Faculty login required."
                    ));
        }

        return ResponseEntity.ok(
                eventService.getEventsCreatedByFaculty(
                        facultyId
                )
        );
    }
}