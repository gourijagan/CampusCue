package com.campuscue.repository;

import com.campuscue.model.EventCoordinator;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EventCoordinatorRepository
        extends JpaRepository<EventCoordinator, Integer> {

    List<EventCoordinator> findByEventIdAndStatus(
            Integer eventId,
            String status
    );

    Optional<EventCoordinator> findByEventIdAndStudentId(
            Integer eventId,
            Integer studentId
    );

    boolean existsByEventIdAndStudentIdAndStatus(
            Integer eventId,
            Integer studentId,
            String status
    );

    List<EventCoordinator> findByStudentIdAndStatus(
            Integer studentId,
            String status
    );
}