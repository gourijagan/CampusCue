package com.campuscue.dto;

public class AssignCoordinatorRequest {

    private Integer studentId;

    public AssignCoordinatorRequest() {
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }
}