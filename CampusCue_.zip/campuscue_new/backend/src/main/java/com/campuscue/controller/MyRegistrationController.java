package com.campuscue.controller;

import com.campuscue.dto.MyRegistrationResponse;
import com.campuscue.service.EventRegistrationService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/my-registrations")
public class MyRegistrationController {

    private final EventRegistrationService registrationService;

    public MyRegistrationController(
            EventRegistrationService registrationService) {

        this.registrationService = registrationService;
    }

    @GetMapping
    public ResponseEntity<?> getMyRegistrations(
            HttpSession session) {

        Object userType = session.getAttribute("userType");
        Object userId = session.getAttribute("userId");

        if (userType == null || userId == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", "You must be logged in."
                    ));
        }

        if (!"STUDENT".equals(userType)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Only students can view registrations."
                    ));
        }

        try {
            Integer studentId =
                    Integer.valueOf((String) userId);

            List<MyRegistrationResponse> registrations =
                    registrationService
                            .getStudentRegistrationSummaries(
                                    studentId
                            );

            return ResponseEntity.ok(registrations);

        } catch (NumberFormatException e) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Invalid student session."
                    ));
        }
    }
@DeleteMapping("/{registrationId}")
public ResponseEntity<?> cancelRegistration(
        @PathVariable Integer registrationId,
        HttpSession session) {

    Object userType = session.getAttribute("userType");
    Object userId = session.getAttribute("userId");

    if (userType == null || userId == null) {
        return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of(
                        "success", false,
                        "message", "You must be logged in."
                ));
    }

    if (!"STUDENT".equals(userType)) {
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(Map.of(
                        "success", false,
                        "message",
                        "Only students can cancel registrations."
                ));
    }

    try {
        Integer studentId =
                Integer.valueOf((String) userId);

        registrationService.cancelRegistration(
                registrationId,
                studentId
        );

        return ResponseEntity.ok(
                Map.of(
                        "success", true,
                        "message",
                        "Registration cancelled successfully."
                )
        );

    } catch (NumberFormatException e) {

        return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(Map.of(
                        "success", false,
                        "message",
                        "Invalid student session."
                ));

    } catch (IllegalArgumentException e) {

        return ResponseEntity
                .badRequest()
                .body(Map.of(
                        "success", false,
                        "message", e.getMessage()
                ));

    } catch (IllegalStateException e) {

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(Map.of(
                        "success", false,
                        "message", e.getMessage()
                ));
    }
}

}