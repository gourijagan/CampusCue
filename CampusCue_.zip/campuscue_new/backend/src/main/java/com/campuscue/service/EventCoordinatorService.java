package com.campuscue.service;

import com.campuscue.dto.AssignCoordinatorRequest;
import com.campuscue.model.Event;
import com.campuscue.model.EventCoordinator;
import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.repository.EventCoordinatorRepository;
import com.campuscue.repository.EventRepository;
import com.campuscue.repository.FacultyRepository;
import com.campuscue.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EventCoordinatorService {

    private final EventCoordinatorRepository coordinatorRepository;
    private final EventRepository eventRepository;
    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;

    public EventCoordinatorService(
            EventCoordinatorRepository coordinatorRepository,
            EventRepository eventRepository,
            StudentRepository studentRepository,
            FacultyRepository facultyRepository
    ) {
        this.coordinatorRepository = coordinatorRepository;
        this.eventRepository = eventRepository;
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
    }

    @Transactional
    public EventCoordinator assignCoordinator(
            Integer eventId,
            AssignCoordinatorRequest request,
            String facultyId
    ) {

        if (request == null || request.getStudentId() == null) {
            throw new IllegalArgumentException(
                    "Student ID is required."
            );
        }

        if (facultyId == null || facultyId.isBlank()) {
            throw new SecurityException(
                    "Faculty login required."
            );
        }

        Faculty faculty = facultyRepository.findById(facultyId)
                .orElseThrow(() ->
                        new SecurityException(
                                "Faculty account not found."
                        )
                );

        if (!"ACTIVE".equalsIgnoreCase(
                faculty.getAccountStatus()
        )) {
            throw new SecurityException(
                    "Faculty account is not active."
            );
        }

        String adminLevel = faculty.getAdminLevel();

        if (!"NORMAL".equalsIgnoreCase(adminLevel)
                && !"SUPER_ADMIN".equalsIgnoreCase(adminLevel)) {
            throw new SecurityException(
                    "You do not have permission to assign coordinators."
            );
        }

        Event event = eventRepository
                .findByEventIdAndStatus(eventId, "ACTIVE")
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Active event not found."
                        )
                );

        Student student = studentRepository
                .findById(request.getStudentId())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Student not found."
                        )
                );

        if (!"ACTIVE".equalsIgnoreCase(
                student.getAccountStatus()
        )) {
            throw new IllegalArgumentException(
                    "Student account is not active."
            );
        }

        boolean alreadyCoordinator =
                coordinatorRepository
                        .existsByEventIdAndStudentIdAndStatus(
                                event.getEventId(),
                                student.getStudentId(),
                                "ACTIVE"
                        );

        if (alreadyCoordinator) {
            throw new IllegalArgumentException(
                    "This student is already a coordinator for this event."
            );
        }

        EventCoordinator coordinator =
                new EventCoordinator();

        coordinator.setEventId(event.getEventId());
        coordinator.setStudentId(student.getStudentId());
        coordinator.setAssignedByFacultyId(facultyId);
        coordinator.setAssignedAt(LocalDateTime.now());
        coordinator.setStatus("ACTIVE");

        return coordinatorRepository.save(coordinator);
    }

    public List<EventCoordinator> getActiveCoordinators(
            Integer eventId
    ) {
        return coordinatorRepository
                .findByEventIdAndStatus(
                        eventId,
                        "ACTIVE"
                );
    }
    public List<Event> getCoordinatorEvents(Integer studentId) {

    List<EventCoordinator> coordinatorRecords =
            coordinatorRepository.findByStudentIdAndStatus(
                    studentId,
                    "ACTIVE"
            );

    return coordinatorRecords.stream()
            .map(coordinator ->
                    eventRepository
                            .findById(coordinator.getEventId())
                            .orElse(null)
            )
            .filter(event -> event != null)
            .toList();
}
}