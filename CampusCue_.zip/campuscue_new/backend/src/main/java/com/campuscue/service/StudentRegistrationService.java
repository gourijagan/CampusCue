package com.campuscue.service;

import com.campuscue.dto.StudentRegistrationSubmitRequest;
import com.campuscue.model.Department;
import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.model.StudentRegistrationRequest;
import com.campuscue.repository.DepartmentRepository;
import com.campuscue.repository.FacultyRepository;
import com.campuscue.repository.StudentRegistrationRequestRepository;
import com.campuscue.repository.StudentRepository;
import com.campuscue.util.PasswordUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StudentRegistrationService {

    private final StudentRepository studentRepository;
    private final StudentRegistrationRequestRepository requestRepository;
    private final DepartmentRepository departmentRepository;
    private final FacultyRepository facultyRepository;

    public StudentRegistrationService(
            StudentRepository studentRepository,
            StudentRegistrationRequestRepository requestRepository,
            DepartmentRepository departmentRepository,
            FacultyRepository facultyRepository) {

        this.studentRepository = studentRepository;
        this.requestRepository = requestRepository;
        this.departmentRepository = departmentRepository;
        this.facultyRepository = facultyRepository;
    }

    // =========================================================
    // STUDENT REGISTRATION
    // =========================================================

    @Transactional
    public StudentRegistrationRequest submitRequest(
            StudentRegistrationSubmitRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Registration details are required."
            );
        }

        if (isBlank(request.getRegNo())) {
            throw new IllegalArgumentException(
                    "Registration number is required."
            );
        }

        if (isBlank(request.getName())) {
            throw new IllegalArgumentException(
                    "Name is required."
            );
        }

        if (request.getBatchStartYear() == null
                || request.getBatchEndYear() == null) {

            throw new IllegalArgumentException(
                    "Batch years are required."
            );
        }

        if (request.getBatchEndYear()
                <= request.getBatchStartYear()) {

            throw new IllegalArgumentException(
                    "Batch end year must be after batch start year."
            );
        }

        if (request.getDepartmentId() == null) {
            throw new IllegalArgumentException(
                    "Department is required."
            );
        }

        if (isBlank(request.getTutorFacultyId())) {
            throw new IllegalArgumentException(
                    "Tutor faculty is required."
            );
        }

        if (isBlank(request.getEmail())) {
            throw new IllegalArgumentException(
                    "College email is required."
            );
        }

        if (isBlank(request.getPassword())) {
            throw new IllegalArgumentException(
                    "Password is required."
            );
        }

        String regNo = request.getRegNo().trim();
        String name = request.getName().trim();
        String email = request.getEmail().trim();
        String tutorFacultyId =
                request.getTutorFacultyId().trim();

        Department department =
                departmentRepository.findById(
                        request.getDepartmentId()
                ).orElseThrow(() ->
                        new IllegalArgumentException(
                                "Selected department does not exist."
                        )
                );

        Faculty tutor =
                facultyRepository.findById(tutorFacultyId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Selected tutor does not exist."
                                )
                        );

        if (!"ACTIVE".equalsIgnoreCase(
                tutor.getAccountStatus())) {

            throw new IllegalArgumentException(
                    "Selected tutor is not active."
            );
        }

        if (tutor.getDepartmentId() == null
                || !tutor.getDepartmentId()
                        .equals(department.getDepartmentId())) {

            throw new IllegalArgumentException(
                    "Selected tutor does not belong to the selected department."
            );
        }

        if (studentRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException(
                    "A student account already exists with this email."
            );
        }

        if (studentRepository.existsByRegNoIgnoreCase(regNo)) {
            throw new IllegalArgumentException(
                    "A student account already exists with this registration number."
            );
        }

        if (requestRepository
                .existsByEmailIgnoreCaseAndStatus(
                        email,
                        "PENDING")) {

            throw new IllegalArgumentException(
                    "A registration request with this email is already pending."
            );
        }

        if (requestRepository
                .existsByRegNoIgnoreCaseAndStatus(
                        regNo,
                        "PENDING")) {

            throw new IllegalArgumentException(
                    "A registration request with this registration number is already pending."
            );
        }

        StudentRegistrationRequest registrationRequest =
                new StudentRegistrationRequest();

        registrationRequest.setRegNo(regNo);

        registrationRequest.setName(name);

        registrationRequest.setBatchStartYear(
                request.getBatchStartYear()
        );

        registrationRequest.setBatchEndYear(
                request.getBatchEndYear()
        );

        registrationRequest.setDepartmentId(
                department.getDepartmentId()
        );

        registrationRequest.setTutorFacultyId(
                tutor.getFacultyId()
        );

        registrationRequest.setEmail(email);

        registrationRequest.setPasswordHash(
                PasswordUtil.hashPassword(
                        request.getPassword()
                )
        );

        registrationRequest.setStatus("PENDING");

        registrationRequest.setRequestedAt(
                LocalDateTime.now()
        );

        return requestRepository.save(
                registrationRequest
        );
    }

    // =========================================================
    // FACULTY - VIEW PENDING REQUESTS
    // =========================================================

    public List<StudentRegistrationRequest> getPendingRequests(
            String facultyId,
            String adminLevel) {

        if (isBlank(facultyId)) {
            throw new IllegalArgumentException(
                    "Faculty identity is required."
            );
        }

        Faculty faculty = facultyRepository.findById(facultyId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Faculty account not found."
                        )
                );

        if (!"ACTIVE".equalsIgnoreCase(
                faculty.getAccountStatus())) {

            throw new IllegalArgumentException(
                    "Faculty account is not active."
            );
        }

        if ("SUPER_ADMIN".equalsIgnoreCase(adminLevel)) {

            return requestRepository
                    .findByStatusOrderByRequestedAtAsc(
                            "PENDING"
                    );
        }

        return requestRepository
                .findByTutorFacultyIdAndStatusOrderByRequestedAtAsc(
                        faculty.getFacultyId(),
                        "PENDING"
                );
    }

    // =========================================================
    // FACULTY - APPROVE REQUEST
    // =========================================================

    @Transactional
    public StudentRegistrationRequest approveRequest(
            Integer requestId,
            String facultyId,
            String adminLevel) {

        Faculty faculty = validateFaculty(
                facultyId,
                adminLevel
        );

        StudentRegistrationRequest registrationRequest =
                requestRepository.findById(requestId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Registration request not found."
                                )
                        );

        validateRequestAccess(
                registrationRequest,
                faculty
        );

        if (!"PENDING".equalsIgnoreCase(
                registrationRequest.getStatus())) {

            throw new IllegalArgumentException(
                    "This registration request has already been reviewed."
            );
        }

        String email =
                registrationRequest.getEmail().trim();

        String regNo =
                registrationRequest.getRegNo().trim();

        if (studentRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException(
                    "A student account already exists with this email."
            );
        }

        if (studentRepository.existsByRegNoIgnoreCase(regNo)) {
            throw new IllegalArgumentException(
                    "A student account already exists with this registration number."
            );
        }

        Student student = new Student();

        student.setRegNo(
                registrationRequest.getRegNo()
        );

        student.setName(
                registrationRequest.getName()
        );

        student.setBatchStartYear(
                registrationRequest.getBatchStartYear()
        );

        student.setBatchEndYear(
                registrationRequest.getBatchEndYear()
        );

        student.setDepartmentId(
                registrationRequest.getDepartmentId()
        );

        student.setTutorFacultyId(
                registrationRequest.getTutorFacultyId()
        );

        student.setEmail(
                registrationRequest.getEmail()
        );

        student.setPasswordHash(
                registrationRequest.getPasswordHash()
        );

        student.setAccountStatus("ACTIVE");

        studentRepository.save(student);

        registrationRequest.setStatus("APPROVED");

        registrationRequest.setReviewedAt(
                LocalDateTime.now()
        );

        registrationRequest.setReviewedByFacultyId(
                faculty.getFacultyId()
        );

        return requestRepository.save(
                registrationRequest
        );
    }

    // =========================================================
    // FACULTY - REJECT REQUEST
    // =========================================================

    @Transactional
    public StudentRegistrationRequest rejectRequest(
            Integer requestId,
            String facultyId,
            String adminLevel) {

        Faculty faculty = validateFaculty(
                facultyId,
                adminLevel
        );

        StudentRegistrationRequest registrationRequest =
                requestRepository.findById(requestId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Registration request not found."
                                )
                        );

        validateRequestAccess(
                registrationRequest,
                faculty
        );

        if (!"PENDING".equalsIgnoreCase(
                registrationRequest.getStatus())) {

            throw new IllegalArgumentException(
                    "This registration request has already been reviewed."
            );
        }

        registrationRequest.setStatus("REJECTED");

        registrationRequest.setReviewedAt(
                LocalDateTime.now()
        );

        registrationRequest.setReviewedByFacultyId(
                faculty.getFacultyId()
        );

        return requestRepository.save(
                registrationRequest
        );
    }

    // =========================================================
    // FACULTY VALIDATION
    // =========================================================

    private Faculty validateFaculty(
            String facultyId,
            String adminLevel) {

        if (isBlank(facultyId)) {
            throw new IllegalArgumentException(
                    "Faculty identity is required."
            );
        }

        Faculty faculty = facultyRepository.findById(facultyId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Faculty account not found."
                        )
                );

        if (!"ACTIVE".equalsIgnoreCase(
                faculty.getAccountStatus())) {

            throw new IllegalArgumentException(
                    "Faculty account is not active."
            );
        }

        if ("SUPER_ADMIN".equalsIgnoreCase(adminLevel)) {

            if (!"SUPER_ADMIN".equalsIgnoreCase(
                    faculty.getAdminLevel())) {

                throw new IllegalArgumentException(
                        "Unauthorized admin level."
                );
            }

        } else {

            if (!"NORMAL".equalsIgnoreCase(
                    faculty.getAdminLevel())) {

                throw new IllegalArgumentException(
                        "Invalid faculty admin level."
                );
            }
        }

        return faculty;
    }

    // =========================================================
    // REQUEST ACCESS VALIDATION
    // =========================================================

    private void validateRequestAccess(
            StudentRegistrationRequest registrationRequest,
            Faculty faculty) {

        if ("SUPER_ADMIN".equalsIgnoreCase(
                faculty.getAdminLevel())) {

            return;
        }

        if (!faculty.getFacultyId().equals(
                registrationRequest.getTutorFacultyId())) {

            throw new IllegalArgumentException(
                    "You are not the assigned tutor for this request."
            );
        }
    }

    // =========================================================
    // UTILITY
    // =========================================================

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    public long getPendingRequestCount(
        String facultyId,
        String adminLevel) {

    Faculty faculty =
            validateFaculty(
                    facultyId,
                    adminLevel
            );

    if ("SUPER_ADMIN".equalsIgnoreCase(adminLevel)) {

        return requestRepository.countByStatus(
                "PENDING"
        );
    }

    return requestRepository
            .countByTutorFacultyIdAndStatus(
                    faculty.getFacultyId(),
                    "PENDING"
            );
}
}