package com.campuscue.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "event_images")
public class EventImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_image_id")
    private Integer eventImageId;

    @Column(name = "event_id", nullable = false)
    private Integer eventId;

    @Column(name = "image_url", nullable = false, length = 500)
    private String imageUrl;

    @Column(name = "image_type", nullable = false, length = 20)
    private String imageType;

    @Column(name = "uploaded_by_type", nullable = false, length = 20)
    private String uploadedByType;

    @Column(name = "uploaded_by_id", nullable = false, length = 50)
    private String uploadedById;

    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    public EventImage() {
    }

    public Integer getEventImageId() {
        return eventImageId;
    }

    public void setEventImageId(Integer eventImageId) {
        this.eventImageId = eventImageId;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }

    public String getUploadedByType() {
        return uploadedByType;
    }

    public void setUploadedByType(String uploadedByType) {
        this.uploadedByType = uploadedByType;
    }

    public String getUploadedById() {
        return uploadedById;
    }

    public void setUploadedById(String uploadedById) {
        this.uploadedById = uploadedById;
    }

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(LocalDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}