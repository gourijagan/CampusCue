package com.campuscue.repository;

import com.campuscue.model.EventRegistration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EventRegistrationRepository
        extends JpaRepository<EventRegistration, Integer> {

    boolean existsByEventIdAndStudentIdAndRegistrationStatus(
            Integer eventId,
            Integer studentId,
            String registrationStatus
    );

    List<EventRegistration> findByStudentIdOrderByRegisteredAtDesc(
            Integer studentId
    );

    Optional<EventRegistration> findByRegistrationIdAndStudentId(
            Integer registrationId,
            Integer studentId
    );

    List<EventRegistration> findByEventIdOrderByRegisteredAtAsc(
            Integer eventId
    );

    List<EventRegistration>
    findByEventIdAndRegistrationStatusOrderByRegisteredAtAsc(
            Integer eventId,
            String registrationStatus
    );
}