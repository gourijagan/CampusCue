package com.campuscue.service;

import com.campuscue.model.Event;
import com.campuscue.model.EventImage;
import com.campuscue.model.Faculty;
import com.campuscue.repository.EventCoordinatorRepository;
import com.campuscue.repository.EventImageRepository;
import com.campuscue.repository.EventRepository;
import com.campuscue.repository.FacultyRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class EventImageService {

    private final EventImageRepository imageRepository;
    private final EventRepository eventRepository;
    private final FacultyRepository facultyRepository;
    private final EventCoordinatorRepository coordinatorRepository;

    private final Path uploadDirectory =
            Paths.get("uploads/event-images");

    public EventImageService(
            EventImageRepository imageRepository,
            EventRepository eventRepository,
            FacultyRepository facultyRepository,
            EventCoordinatorRepository coordinatorRepository) {

        this.imageRepository = imageRepository;
        this.eventRepository = eventRepository;
        this.facultyRepository = facultyRepository;
        this.coordinatorRepository = coordinatorRepository;
    }

    public EventImage uploadImage(
            Integer eventId,
            MultipartFile file,
            String imageType,
            String userType,
            String userId) throws IOException {

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(
                    "Please select an image."
            );
        }

        if (imageType == null || imageType.isBlank()) {
            throw new IllegalArgumentException(
                    "Image type is required."
            );
        }

        String normalizedImageType =
                imageType.trim().toUpperCase();

        if (!normalizedImageType.equals("POSTER")
                && !normalizedImageType.equals("THUMBNAIL")
                && !normalizedImageType.equals("BACKGROUND")
                && !normalizedImageType.equals("GALLERY")) {

            throw new IllegalArgumentException(
                    "Image type must be POSTER, THUMBNAIL, BACKGROUND or GALLERY."
            );
        }

        if (userType == null || userType.isBlank()
                || userId == null || userId.isBlank()) {

            throw new SecurityException(
                    "Login is required."
            );
        }

        Event event = eventRepository
                .findByEventIdAndStatus(
                        eventId,
                        "ACTIVE"
                )
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Active event not found."
                        ));

        checkPermission(
                event,
                userType,
                userId
        );

        String originalFilename =
                file.getOriginalFilename();

        if (originalFilename == null
                || originalFilename.isBlank()) {

            throw new IllegalArgumentException(
                    "Invalid image file."
            );
        }

        String filename =
                originalFilename.toLowerCase();

        if (!filename.endsWith(".jpg")
                && !filename.endsWith(".jpeg")
                && !filename.endsWith(".png")
                && !filename.endsWith(".webp")) {

            throw new IllegalArgumentException(
                    "Only JPG, JPEG, PNG and WEBP images are allowed."
            );
        }

        if (file.getSize() > 5 * 1024 * 1024) {
            throw new IllegalArgumentException(
                    "Image size cannot exceed 5 MB."
            );
        }

        /*
         * Only one active thumbnail and one active
         * background are allowed for each event.
         */
        if (normalizedImageType.equals("THUMBNAIL")
                || normalizedImageType.equals("BACKGROUND")) {

            imageRepository
                    .findFirstByEventIdAndImageTypeAndStatus(
                            eventId,
                            normalizedImageType,
                            "ACTIVE"
                    )
                    .ifPresent(existingImage -> {

                        existingImage.setStatus("DELETED");

                        imageRepository.save(existingImage);
                    });
        }

        Files.createDirectories(uploadDirectory);

        String extension =
                getFileExtension(originalFilename);

        String storedFilename =
                UUID.randomUUID() + extension;

        Path targetPath =
                uploadDirectory.resolve(storedFilename);

        Files.copy(
                file.getInputStream(),
                targetPath,
                StandardCopyOption.REPLACE_EXISTING
        );

        EventImage eventImage =
                new EventImage();

        eventImage.setEventId(eventId);

        eventImage.setImageUrl(
                "/uploads/event-images/"
                        + storedFilename
        );

        eventImage.setImageType(
                normalizedImageType
        );

        eventImage.setUploadedByType(
                userType.toUpperCase()
        );

        eventImage.setUploadedById(
                userId
        );

        eventImage.setUploadedAt(
                LocalDateTime.now()
        );

        eventImage.setStatus(
                "ACTIVE"
        );

        return imageRepository.save(eventImage);
    }

    public List<EventImage> getEventImages(
            Integer eventId) {

        return imageRepository
                .findByEventIdAndStatusOrderByUploadedAtAsc(
                        eventId,
                        "ACTIVE"
                );
    }

    public void deleteImage(
            Integer imageId,
            String userType,
            String userId) {

        if (userType == null || userType.isBlank()
                || userId == null || userId.isBlank()) {

            throw new SecurityException(
                    "Login is required."
            );
        }

        EventImage image =
                imageRepository.findById(imageId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Image not found."
                                ));

        if (!"ACTIVE".equalsIgnoreCase(
                image.getStatus())) {

            throw new IllegalArgumentException(
                    "Image is already deleted."
            );
        }

        Event event =
                eventRepository
                        .findByEventIdAndStatus(
                                image.getEventId(),
                                "ACTIVE"
                        )
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Active event not found."
                                ));

        checkPermission(
                event,
                userType,
                userId
        );

        image.setStatus("DELETED");

        imageRepository.save(image);
    }

    private void checkPermission(
            Event event,
            String userType,
            String userId) {

        if ("FACULTY".equalsIgnoreCase(userType)) {

            Faculty faculty =
                    facultyRepository
                            .findById(userId)
                            .orElseThrow(() ->
                                    new SecurityException(
                                            "Faculty account not found."
                                    ));

            if (!"ACTIVE".equalsIgnoreCase(
                    faculty.getAccountStatus())) {

                throw new SecurityException(
                        "Faculty account is not active."
                );
            }

            return;
        }

        if ("STUDENT".equalsIgnoreCase(userType)) {

            Integer studentId;

            try {
                studentId =
                        Integer.parseInt(userId);

            } catch (NumberFormatException e) {

                throw new SecurityException(
                        "Invalid student session."
                );
            }

            boolean isCoordinator =
                    coordinatorRepository
                            .existsByEventIdAndStudentIdAndStatus(
                                    event.getEventId(),
                                    studentId,
                                    "ACTIVE"
                            );

            if (!isCoordinator) {

                throw new SecurityException(
                        "You are not an active coordinator for this event."
                );
            }

            return;
        }

        throw new SecurityException(
                "You do not have permission to manage images."
        );
    }

    private String getFileExtension(
            String filename) {

        int dotIndex =
                filename.lastIndexOf(".");

        if (dotIndex == -1) {
            return "";
        }

        return filename
                .substring(dotIndex)
                .toLowerCase();
    }
}