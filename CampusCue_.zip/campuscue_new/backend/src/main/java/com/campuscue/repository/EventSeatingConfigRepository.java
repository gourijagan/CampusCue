package com.campuscue.repository;

import com.campuscue.model.EventSeatingConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventSeatingConfigRepository
        extends JpaRepository<EventSeatingConfig, Integer> {
}