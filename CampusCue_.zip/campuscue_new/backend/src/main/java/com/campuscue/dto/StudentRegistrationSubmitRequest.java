package com.campuscue.dto;

public class StudentRegistrationSubmitRequest {

    private String regNo;
    private String name;
    private Integer batchStartYear;
    private Integer batchEndYear;
    private Integer departmentId;
    private String tutorFacultyId;
    private String email;
    private String password;

    public StudentRegistrationSubmitRequest() {
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBatchStartYear() {
        return batchStartYear;
    }

    public void setBatchStartYear(Integer batchStartYear) {
        this.batchStartYear = batchStartYear;
    }

    public Integer getBatchEndYear() {
        return batchEndYear;
    }

    public void setBatchEndYear(Integer batchEndYear) {
        this.batchEndYear = batchEndYear;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getTutorFacultyId() {
        return tutorFacultyId;
    }

    public void setTutorFacultyId(String tutorFacultyId) {
        this.tutorFacultyId = tutorFacultyId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}