package com.campuscue.controller;

import com.campuscue.dto.LoginRequest;
import com.campuscue.dto.LoginResponse;
import com.campuscue.service.LoginService;

import jakarta.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final LoginService loginService;

    public AuthController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request,
            HttpSession session) {

        try {
            LoginResponse response =
                    loginService.login(
                            request.getEmail(),
                            request.getPassword()
                    );

            /*
             * Store only safe account information in the session.
             * Never store the password or password hash.
             */
            session.setAttribute("userType", response.getUserType());
            session.setAttribute("userId", response.getUserId());
            session.setAttribute("name", response.getName());
            session.setAttribute("email", response.getEmail());
            session.setAttribute("departmentId", response.getDepartmentId());
            session.setAttribute("designation", response.getDesignation());
            session.setAttribute("adminLevel", response.getAdminLevel());

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));
        }
    }

    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(HttpSession session) {

        Object userType = session.getAttribute("userType");

        if (userType == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", "Not logged in."
                    ));
        }

        LoginResponse response = new LoginResponse(
                true,
                "Authenticated user.",
                (String) session.getAttribute("userType"),
                (String) session.getAttribute("userId"),
                (String) session.getAttribute("name"),
                (String) session.getAttribute("email"),
                (Integer) session.getAttribute("departmentId"),
                (String) session.getAttribute("designation"),
                (String) session.getAttribute("adminLevel")
        );

        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {

        session.invalidate();

        return ResponseEntity.ok(
                Map.of(
                        "success", true,
                        "message", "Logged out successfully."
                )
        );
    }
}