package com.campuscue.repository;

import com.campuscue.model.Event;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EventRepository extends JpaRepository<Event, Integer> {

    List<Event> findByStatusOrderByEventDateAscStartTimeAsc(
            String status
    );

    Optional<Event> findByEventIdAndStatus(
            Integer eventId,
            String status
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            SELECT e
            FROM Event e
            WHERE e.eventId = :eventId
              AND e.status = :status
            """)
    Optional<Event> findActiveEventForUpdate(
            @Param("eventId") Integer eventId,
            @Param("status") String status
    );
    List<Event> findByCreatedByFacultyIdOrderByEventDateAscStartTimeAsc(
        String createdByFacultyId
);
}