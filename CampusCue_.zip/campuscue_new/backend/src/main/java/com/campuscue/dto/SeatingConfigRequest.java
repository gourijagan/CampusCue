package com.campuscue.dto;

public class SeatingConfigRequest {

    private String layoutType;
    private Integer rowsCount;
    private Integer columnsCount;
    private Boolean rearLockEnabled;
    private Integer rearLockStartPercent;

    public SeatingConfigRequest() {
    }

    public String getLayoutType() {
        return layoutType;
    }

    public void setLayoutType(String layoutType) {
        this.layoutType = layoutType;
    }

    public Integer getRowsCount() {
        return rowsCount;
    }

    public void setRowsCount(Integer rowsCount) {
        this.rowsCount = rowsCount;
    }

    public Integer getColumnsCount() {
        return columnsCount;
    }

    public void setColumnsCount(Integer columnsCount) {
        this.columnsCount = columnsCount;
    }

    public Boolean getRearLockEnabled() {
        return rearLockEnabled;
    }

    public void setRearLockEnabled(Boolean rearLockEnabled) {
        this.rearLockEnabled = rearLockEnabled;
    }

    public Integer getRearLockStartPercent() {
        return rearLockStartPercent;
    }

    public void setRearLockStartPercent(
            Integer rearLockStartPercent) {
        this.rearLockStartPercent =
                rearLockStartPercent;
    }
}