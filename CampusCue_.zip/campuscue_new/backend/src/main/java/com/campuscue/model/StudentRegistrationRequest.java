package com.campuscue.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "student_registration_requests")
public class StudentRegistrationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_id")
    private Integer requestId;

    @Column(name = "reg_no", nullable = false)
    private String regNo;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "batch_start_year", nullable = false)
    private Integer batchStartYear;

    @Column(name = "batch_end_year", nullable = false)
    private Integer batchEndYear;

    @Column(name = "department_id", nullable = false)
    private Integer departmentId;

    @Column(name = "tutor_faculty_id", nullable = false)
    private String tutorFacultyId;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "requested_at", nullable = false)
    private LocalDateTime requestedAt;

    @Column(name = "reviewed_at")
    private LocalDateTime reviewedAt;

    @Column(name = "reviewed_by_faculty_id")
    private String reviewedByFacultyId;

    public StudentRegistrationRequest() {
    }

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBatchStartYear() {
        return batchStartYear;
    }

    public void setBatchStartYear(Integer batchStartYear) {
        this.batchStartYear = batchStartYear;
    }

    public Integer getBatchEndYear() {
        return batchEndYear;
    }

    public void setBatchEndYear(Integer batchEndYear) {
        this.batchEndYear = batchEndYear;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getTutorFacultyId() {
        return tutorFacultyId;
    }

    public void setTutorFacultyId(String tutorFacultyId) {
        this.tutorFacultyId = tutorFacultyId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getRequestedAt() {
        return requestedAt;
    }

    public void setRequestedAt(LocalDateTime requestedAt) {
        this.requestedAt = requestedAt;
    }

    public LocalDateTime getReviewedAt() {
        return reviewedAt;
    }

    public void setReviewedAt(LocalDateTime reviewedAt) {
        this.reviewedAt = reviewedAt;
    }

    public String getReviewedByFacultyId() {
        return reviewedByFacultyId;
    }

    public void setReviewedByFacultyId(String reviewedByFacultyId) {
        this.reviewedByFacultyId = reviewedByFacultyId;
    }
}