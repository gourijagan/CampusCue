package com.campuscue.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "event_seating_configs")
public class EventSeatingConfig {

    @Id
    @Column(name = "event_id")
    private Integer eventId;

    @Column(name = "layout_type", nullable = false)
    private String layoutType;

    @Column(name = "rows_count", nullable = false)
    private Integer rowsCount;

    @Column(name = "columns_count", nullable = false)
    private Integer columnsCount;

    @Column(name = "seat_count", nullable = false)
    private Integer seatCount;

    @Column(name = "rear_lock_enabled", nullable = false)
    private Boolean rearLockEnabled;

    @Column(name = "rear_lock_start_percent", nullable = false)
    private Integer rearLockStartPercent;

    @Column(name = "configured_by_faculty_id", nullable = false)
    private String configuredByFacultyId;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    public EventSeatingConfig() {
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getLayoutType() {
        return layoutType;
    }

    public void setLayoutType(String layoutType) {
        this.layoutType = layoutType;
    }

    public Integer getRowsCount() {
        return rowsCount;
    }

    public void setRowsCount(Integer rowsCount) {
        this.rowsCount = rowsCount;
    }

    public Integer getColumnsCount() {
        return columnsCount;
    }

    public void setColumnsCount(Integer columnsCount) {
        this.columnsCount = columnsCount;
    }

    public Integer getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(Integer seatCount) {
        this.seatCount = seatCount;
    }

    public Boolean getRearLockEnabled() {
        return rearLockEnabled;
    }

    public void setRearLockEnabled(Boolean rearLockEnabled) {
        this.rearLockEnabled = rearLockEnabled;
    }

    public Integer getRearLockStartPercent() {
        return rearLockStartPercent;
    }

    public void setRearLockStartPercent(Integer rearLockStartPercent) {
        this.rearLockStartPercent = rearLockStartPercent;
    }

    public String getConfiguredByFacultyId() {
        return configuredByFacultyId;
    }

    public void setConfiguredByFacultyId(String configuredByFacultyId) {
        this.configuredByFacultyId = configuredByFacultyId;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}