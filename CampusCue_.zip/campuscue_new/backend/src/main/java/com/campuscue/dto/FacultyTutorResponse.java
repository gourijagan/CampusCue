package com.campuscue.dto;

public class FacultyTutorResponse {

    private String facultyId;
    private String name;
    private String designation;

    public FacultyTutorResponse() {
    }

    public FacultyTutorResponse(
            String facultyId,
            String name,
            String designation) {

        this.facultyId = facultyId;
        this.name = name;
        this.designation = designation;
    }

    public String getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(String facultyId) {
        this.facultyId = facultyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}