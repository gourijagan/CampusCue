package com.campuscue.controller;

import com.campuscue.dto.EventRegistrationRequest;
import com.campuscue.model.EventRegistration;
import com.campuscue.service.EventRegistrationService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class EventRegistrationController {

    private final EventRegistrationService registrationService;

    public EventRegistrationController(
            EventRegistrationService registrationService) {

        this.registrationService = registrationService;
    }

    @PostMapping("/{eventId}/registrations")
    public ResponseEntity<?> register(
            @PathVariable Integer eventId,
            @RequestBody EventRegistrationRequest request,
            HttpSession session) {

        Object userType =
                session.getAttribute("userType");

        Object userId =
                session.getAttribute("userId");

        if (userType == null || userId == null) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", "You must be logged in."
                    ));
        }

        if (!"STUDENT".equals(userType)) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Only students can register for events."
                    ));
        }

        try {

            Integer studentId =
                    Integer.valueOf((String) userId);

            EventRegistration registration =
                    registrationService.registerStudent(
                            eventId,
                            studentId,
                            request
                    );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message",
                            "Registration successful.",
                            "registrationId",
                            registration.getRegistrationId(),
                            "eventId",
                            registration.getEventId(),
                            "studentId",
                            registration.getStudentId(),
                            "numberOfSeats",
                            registration.getNumberOfSeats(),
                            "registrationStatus",
                            registration.getRegistrationStatus()
                    )
            );

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (IllegalStateException e) {

            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));
        }
    }
    @GetMapping("/event/{eventId}")
public ResponseEntity<?> getEventRegistrations(
        @PathVariable Integer eventId,
        HttpSession session
) {
    String userType = (String) session.getAttribute("userType");

    if (!"FACULTY".equals(userType)) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(Map.of("message", "Faculty login required."));
    }

    return ResponseEntity.ok(
            registrationService.getRegistrationsForEvent(eventId)
    );
}
@GetMapping("/event/{eventId}/details")
public ResponseEntity<?> getEventRegistrationDetails(
        @PathVariable Integer eventId,
        HttpSession session) {

    String userType =
            (String) session.getAttribute("userType");

    if (!"FACULTY".equals(userType)) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(
                        Map.of(
                                "message",
                                "Faculty login required."
                        )
                );
    }

    try {

        return ResponseEntity.ok(
                registrationService
                        .getRegistrationDetailsForEvent(
                                eventId
                        )
        );

    } catch (IllegalArgumentException e) {

        return ResponseEntity
                .badRequest()
                .body(
                        Map.of(
                                "success",
                                false,
                                "message",
                                e.getMessage()
                        )
                );
    }
}


@GetMapping("/event/{eventId}/search")
public ResponseEntity<?> searchEventRegistrations(
        @PathVariable Integer eventId,
        @RequestParam(required = false) String search,
        @RequestParam(required = false) String status,
        HttpSession session) {

    String userType =
            (String) session.getAttribute("userType");

    if (!"FACULTY".equals(userType)) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(
                        Map.of(
                                "message",
                                "Faculty login required."
                        )
                );
    }

    try {

        return ResponseEntity.ok(
                registrationService
                        .searchEventRegistrations(
                                eventId,
                                search,
                                status
                        )
        );

    } catch (IllegalArgumentException e) {

        return ResponseEntity
                .badRequest()
                .body(
                        Map.of(
                                "success",
                                false,
                                "message",
                                e.getMessage()
                        )
                );
    }
}


@GetMapping("/event/{eventId}/statistics")
public ResponseEntity<?> getRegistrationStatistics(
        @PathVariable Integer eventId,
        HttpSession session) {

    String userType =
            (String) session.getAttribute("userType");

    if (!"FACULTY".equals(userType)) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(
                        Map.of(
                                "message",
                                "Faculty login required."
                        )
                );
    }

    try {

        return ResponseEntity.ok(
                registrationService
                        .getRegistrationStatistics(
                                eventId
                        )
        );

    } catch (IllegalArgumentException e) {

        return ResponseEntity
                .badRequest()
                .body(
                        Map.of(
                                "success",
                                false,
                                "message",
                                e.getMessage()
                        )
                );
    }
}
}