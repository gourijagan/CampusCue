package com.campuscue.dto;

import java.util.List;

public class SeatSelectionRequest {

    private List<Integer> seatIds;
    private String holdToken;

    public SeatSelectionRequest() {
    }

    public List<Integer> getSeatIds() {
        return seatIds;
    }

    public void setSeatIds(List<Integer> seatIds) {
        this.seatIds = seatIds;
    }

    public String getHoldToken() {
        return holdToken;
    }

    public void setHoldToken(String holdToken) {
        this.holdToken = holdToken;
    }
}