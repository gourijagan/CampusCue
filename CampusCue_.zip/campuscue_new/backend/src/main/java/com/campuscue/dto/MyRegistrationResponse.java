package com.campuscue.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class MyRegistrationResponse {

    /*
     * ============================================================
     * REGISTRATION INFORMATION
     * ============================================================
     */

    private Integer registrationId;

    private Integer eventId;

    private String eventTitle;

    private LocalDate eventDate;

    private LocalTime startTime;

    private LocalTime endTime;

    private String venue;

    private Integer numberOfSeats;

    private String registrationStatus;

    private LocalDateTime registeredAt;


    /*
     * ============================================================
     * PARTICIPANT INFORMATION
     * ============================================================
     */

    private List<ParticipantResponse> participants =
            new ArrayList<>();

    private Integer participantCount;


    /*
     * ============================================================
     * CONSTRUCTORS
     * ============================================================
     */

    public MyRegistrationResponse() {
    }


    /*
     * ============================================================
     * GETTERS / SETTERS
     * ============================================================
     */

    public Integer getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(
            Integer registrationId) {

        this.registrationId =
                registrationId;
    }


    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(
            Integer eventId) {

        this.eventId =
                eventId;
    }


    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(
            String eventTitle) {

        this.eventTitle =
                eventTitle;
    }


    public LocalDate getEventDate() {
        return eventDate;
    }

    public void setEventDate(
            LocalDate eventDate) {

        this.eventDate =
                eventDate;
    }


    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(
            LocalTime startTime) {

        this.startTime =
                startTime;
    }


    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(
            LocalTime endTime) {

        this.endTime =
                endTime;
    }


    public String getVenue() {
        return venue;
    }

    public void setVenue(
            String venue) {

        this.venue =
                venue;
    }


    public Integer getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(
            Integer numberOfSeats) {

        this.numberOfSeats =
                numberOfSeats;
    }


    public String getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(
            String registrationStatus) {

        this.registrationStatus =
                registrationStatus;
    }


    public LocalDateTime getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(
            LocalDateTime registeredAt) {

        this.registeredAt =
                registeredAt;
    }


    public List<ParticipantResponse> getParticipants() {
        return participants;
    }

    public void setParticipants(
            List<ParticipantResponse> participants) {

        this.participants =
                participants;
    }


    public Integer getParticipantCount() {
        return participantCount;
    }

    public void setParticipantCount(
            Integer participantCount) {

        this.participantCount =
                participantCount;
    }


    /*
     * ============================================================
     * PARTICIPANT RESPONSE
     * ============================================================
     *
     * Every student is represented equally.
     *
     * There is deliberately no "leader" field.
     */

    public static class ParticipantResponse {

        private Integer studentId;

        private String name;

        private String email;


        public ParticipantResponse() {
        }


        public ParticipantResponse(
                Integer studentId,
                String name,
                String email) {

            this.studentId =
                    studentId;

            this.name =
                    name;

            this.email =
                    email;
        }


        public Integer getStudentId() {
            return studentId;
        }

        public void setStudentId(
                Integer studentId) {

            this.studentId =
                    studentId;
        }


        public String getName() {
            return name;
        }

        public void setName(
                String name) {

            this.name =
                    name;
        }


        public String getEmail() {
            return email;
        }

        public void setEmail(
                String email) {

            this.email =
                    email;
        }
    }
}