package com.campuscue.repository;

import com.campuscue.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DepartmentRepository
        extends JpaRepository<Department, Integer> {

    List<Department> findAllByOrderByDepartmentNameAsc();

    Optional<Department> findByDepartmentCodeIgnoreCase(
            String departmentCode
    );
}