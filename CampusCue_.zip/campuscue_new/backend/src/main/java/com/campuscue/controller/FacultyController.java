package com.campuscue.controller;

import com.campuscue.dto.FacultyTutorResponse;
import com.campuscue.model.Faculty;
import com.campuscue.repository.FacultyRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/faculty")
public class FacultyController {

    private final FacultyRepository facultyRepository;

    public FacultyController(
            FacultyRepository facultyRepository) {

        this.facultyRepository = facultyRepository;
    }

    @GetMapping("/department/{departmentId}")
    public List<FacultyTutorResponse> getFacultyByDepartment(
            @PathVariable Integer departmentId) {

        List<Faculty> facultyList =
                facultyRepository
                        .findByDepartmentIdAndAccountStatusOrderByNameAsc(
                                departmentId,
                                "ACTIVE"
                        );

        return facultyList.stream()
                .map(faculty ->
                        new FacultyTutorResponse(
                                faculty.getFacultyId(),
                                faculty.getName(),
                                faculty.getDesignation()
                        )
                )
                .toList();
    }
}