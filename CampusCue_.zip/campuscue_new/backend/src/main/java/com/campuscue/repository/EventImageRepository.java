package com.campuscue.repository;

import com.campuscue.model.EventImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EventImageRepository
        extends JpaRepository<EventImage, Integer> {

    List<EventImage> findByEventIdAndStatusOrderByUploadedAtAsc(
            Integer eventId,
            String status
    );

    Optional<EventImage> findFirstByEventIdAndImageTypeAndStatus(
            Integer eventId,
            String imageType,
            String status
    );
}