package com.campuscue.repository;

import com.campuscue.model.RegistrationSeat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RegistrationSeatRepository extends JpaRepository<RegistrationSeat, Integer> {

    List<RegistrationSeat> findByRegistrationId(Integer registrationId);

    List<RegistrationSeat> findByRegistrationIdOrderBySeatIdAsc(Integer registrationId);

    List<RegistrationSeat> findByEventId(Integer eventId);

    void deleteByRegistrationId(Integer registrationId);

    boolean existsByEventIdAndSeatId(Integer eventId, Integer seatId);
}
