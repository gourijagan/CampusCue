package com.campuscue.controller;

import com.campuscue.dto.AssignCoordinatorRequest;
import com.campuscue.model.EventCoordinator;
import com.campuscue.service.EventCoordinatorService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class EventCoordinatorController {

    private final EventCoordinatorService coordinatorService;

    public EventCoordinatorController(
            EventCoordinatorService coordinatorService
    ) {
        this.coordinatorService = coordinatorService;
    }

    @PostMapping("/{eventId}/coordinators")
    public ResponseEntity<?> assignCoordinator(
            @PathVariable Integer eventId,
            @RequestBody AssignCoordinatorRequest request,
            HttpSession session
    ) {

        String userType =
                (String) session.getAttribute("userType");

        String facultyId =
                (String) session.getAttribute("userId");

        if (!"FACULTY".equals(userType)
                || facultyId == null) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "message",
                            "Faculty login required."
                    ));
        }

        try {

            EventCoordinator coordinator =
                    coordinatorService.assignCoordinator(
                            eventId,
                            request,
                            facultyId
                    );

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(Map.of(
                            "message",
                            "Student assigned as event coordinator successfully.",
                            "eventCoordinatorId",
                            coordinator.getEventCoordinatorId(),
                            "eventId",
                            coordinator.getEventId(),
                            "studentId",
                            coordinator.getStudentId()
                    ));

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "message",
                            e.getMessage()
                    ));

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "message",
                            e.getMessage()
                    ));
        }
    }

    @GetMapping("/{eventId}/coordinators")
    public ResponseEntity<?> getCoordinators(
            @PathVariable Integer eventId,
            HttpSession session
    ) {

        String userType =
                (String) session.getAttribute("userType");

        if (!"FACULTY".equals(userType)) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "message",
                            "Faculty login required."
                    ));
        }

        List<EventCoordinator> coordinators =
                coordinatorService.getActiveCoordinators(
                        eventId
                );

        return ResponseEntity.ok(coordinators);
    }
    @GetMapping("/coordinator-events")
public ResponseEntity<?> getCoordinatorEvents(
        HttpSession session
) {

    String userType =
            (String) session.getAttribute("userType");

    String userId =
            (String) session.getAttribute("userId");

    if (!"STUDENT".equals(userType)
            || userId == null) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(Map.of(
                        "message",
                        "Student login required."
                ));
    }

    try {

        Integer studentId =
                Integer.parseInt(userId);

        return ResponseEntity.ok(
                coordinatorService.getCoordinatorEvents(
                        studentId
                )
        );

    } catch (NumberFormatException e) {

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(Map.of(
                        "message",
                        "Invalid student session."
                ));
    }
}
}