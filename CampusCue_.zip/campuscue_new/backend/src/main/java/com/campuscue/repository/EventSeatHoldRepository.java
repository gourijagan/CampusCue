package com.campuscue.repository;

import com.campuscue.model.EventSeatHold;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface EventSeatHoldRepository
        extends JpaRepository<EventSeatHold, Integer> {

    List<EventSeatHold> findByEventIdAndExpiresAtAfter(
            Integer eventId,
            LocalDateTime now
    );

    List<EventSeatHold> findByHoldToken(
            String holdToken
    );

    List<EventSeatHold> findByEventIdAndStudentIdAndExpiresAtAfter(
            Integer eventId,
            Integer studentId,
            LocalDateTime now
    );

    void deleteByExpiresAtBefore(
            LocalDateTime time
    );

    void deleteByHoldToken(
            String holdToken
    );
}