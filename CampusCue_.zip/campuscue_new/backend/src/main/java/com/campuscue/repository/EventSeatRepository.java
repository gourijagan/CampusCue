package com.campuscue.repository;

import com.campuscue.model.EventSeat;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EventSeatRepository extends JpaRepository<EventSeat, Integer> {

    List<EventSeat> findByEventIdOrderByPositionOrderAsc(Integer eventId);

    Optional<EventSeat> findBySeatIdAndEventId(Integer seatId, Integer eventId);

    void deleteByEventId(Integer eventId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            SELECT s
            FROM EventSeat s
            WHERE s.eventId = :eventId
            AND s.seatId IN :seatIds
            ORDER BY s.positionOrder ASC
            """)
    List<EventSeat> findSelectedSeatsForUpdate(
            @Param("eventId") Integer eventId,
            @Param("seatIds") List<Integer> seatIds
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            SELECT s
            FROM EventSeat s
            WHERE s.eventId = :eventId
            ORDER BY s.positionOrder ASC
            """)
    List<EventSeat> findSeatsForUpdate(
            @Param("eventId") Integer eventId
    );
}
