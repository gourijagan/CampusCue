package com.campuscue.service;

import com.campuscue.dto.EventRegistrationRequest;
import com.campuscue.dto.MyRegistrationResponse;
import com.campuscue.model.Event;
import com.campuscue.model.EventParticipant;
import com.campuscue.model.EventRegistration;
import com.campuscue.model.EventSeat;
import com.campuscue.model.EventSeatHold;
import com.campuscue.model.RegistrationSeat;
import com.campuscue.model.Student;

import com.campuscue.repository.EventParticipantRepository;
import com.campuscue.repository.EventRegistrationRepository;
import com.campuscue.repository.EventRepository;
import com.campuscue.repository.EventSeatHoldRepository;
import com.campuscue.repository.EventSeatRepository;
import com.campuscue.repository.RegistrationSeatRepository;
import com.campuscue.repository.StudentRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class EventRegistrationService {

    private final EventRepository eventRepository;
    private final StudentRepository studentRepository;
    private final EventRegistrationRepository registrationRepository;
    private final EventParticipantRepository participantRepository;

    private final EventSeatRepository eventSeatRepository;
    private final EventSeatHoldRepository eventSeatHoldRepository;
    private final RegistrationSeatRepository registrationSeatRepository;

    public EventRegistrationService(
            EventRepository eventRepository,
            StudentRepository studentRepository,
            EventRegistrationRepository registrationRepository,
            EventParticipantRepository participantRepository,
            EventSeatRepository eventSeatRepository,
            EventSeatHoldRepository eventSeatHoldRepository,
            RegistrationSeatRepository registrationSeatRepository) {

        this.eventRepository = eventRepository;
        this.studentRepository = studentRepository;
        this.registrationRepository = registrationRepository;
        this.participantRepository = participantRepository;

        this.eventSeatRepository = eventSeatRepository;
        this.eventSeatHoldRepository = eventSeatHoldRepository;
        this.registrationSeatRepository = registrationSeatRepository;
    }

    /*
     * ============================================================
     * STUDENT REGISTRATION
     * ============================================================
     */

    @Transactional
    public EventRegistration registerStudent(
            Integer eventId,
            Integer registeringStudentId,
            EventRegistrationRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Registration details are required."
            );
        }

        if (request.getNumberOfSeats() == null) {
            throw new IllegalArgumentException(
                    "Number of seats is required."
            );
        }

        int numberOfSeats = request.getNumberOfSeats();

        if (numberOfSeats < 1 || numberOfSeats > 8) {
            throw new IllegalArgumentException(
                    "A registration must contain between 1 and 8 seats."
            );
        }

        Student registeringStudent =
                studentRepository.findById(registeringStudentId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Registering student was not found."
                                )
                        );

        if (!"ACTIVE".equalsIgnoreCase(
                registeringStudent.getAccountStatus())) {

            throw new SecurityException(
                    "Student account is not active."
            );
        }

        /*
         * Lock the event row during registration.
         */
        Event event =
                eventRepository.findActiveEventForUpdate(
                        eventId,
                        "ACTIVE"
                ).orElseThrow(() ->
                        new IllegalArgumentException(
                                "Event not found or is not active."
                        )
                );

        /*
         * Deadline check
         */
        if (event.getRegistrationDeadline() == null) {
            throw new IllegalStateException(
                    "Registration deadline is not configured."
            );
        }

        if (LocalDateTime.now().isAfter(
                event.getRegistrationDeadline())) {

            throw new IllegalStateException(
                    "Registration deadline has passed."
            );
        }

        /*
         * Existing registration check
         */
        boolean alreadyRegistered =
                registrationRepository
                        .existsByEventIdAndStudentIdAndRegistrationStatus(
                                eventId,
                                registeringStudentId,
                                "CONFIRMED"
                        );

        boolean alreadyWaitlisted =
                registrationRepository
                        .existsByEventIdAndStudentIdAndRegistrationStatus(
                                eventId,
                                registeringStudentId,
                                "WAITLISTED"
                        );

        if (alreadyRegistered) {
            throw new IllegalStateException(
                    "You are already registered for this event."
            );
        }

        if (alreadyWaitlisted) {
            throw new IllegalStateException(
                    "You are already on the waitlist for this event."
            );
        }

        /*
         * ========================================================
         * PARTICIPANT VALIDATION
         * ========================================================
         */

        List<String> requestedEmails =
                request.getParticipantEmails();

        if (requestedEmails == null) {
            requestedEmails = new ArrayList<>();
        }

        if (requestedEmails.size() != numberOfSeats - 1) {

            throw new IllegalArgumentException(
                    "For " + numberOfSeats
                            + " seats, exactly "
                            + (numberOfSeats - 1)
                            + " additional student email(s) are required."
            );
        }

        Set<String> uniqueEmails =
                new HashSet<>();

        List<Student> participants =
                new ArrayList<>();

        /*
         * Registering student is automatically a participant.
         */
        participants.add(registeringStudent);

        for (String email : requestedEmails) {

            if (email == null || email.isBlank()) {

                throw new IllegalArgumentException(
                        "Participant email cannot be empty."
                );
            }

            String normalizedEmail =
                    email.trim().toLowerCase(Locale.ROOT);

            /*
             * Duplicate email inside same registration.
             */
            if (!uniqueEmails.add(normalizedEmail)) {

                throw new IllegalArgumentException(
                        "Duplicate participant email: "
                                + normalizedEmail
                );
            }

            /*
             * Registering student must not be entered again.
             */
            if (normalizedEmail.equals(
                    registeringStudent.getEmail()
                            .trim()
                            .toLowerCase(Locale.ROOT))) {

                throw new IllegalArgumentException(
                        "The registering student's email should not "
                                + "be entered again."
                );
            }

            /*
             * Student must already exist.
             */
            Student participant =
                    studentRepository
                            .findByEmailIgnoreCase(normalizedEmail)
                            .orElseThrow(() ->
                                    new IllegalArgumentException(
                                            "No verified student account "
                                                    + "was found for: "
                                                    + normalizedEmail
                                    )
                            );

            /*
             * Participant account must be active.
             */
            if (!"ACTIVE".equalsIgnoreCase(
                    participant.getAccountStatus())) {

                throw new IllegalArgumentException(
                        "Student account is not active: "
                                + normalizedEmail
                );
            }

            /*
             * Participant cannot already participate.
             */
            if (participantRepository
                    .existsByEventIdAndStudentId(
                            eventId,
                            participant.getStudentId())) {

                throw new IllegalStateException(
                        "Student is already registered for this event: "
                                + normalizedEmail
                );
            }

            /*
             * Participant cannot already be waiting.
             */
            if (registrationRepository
                    .existsByEventIdAndStudentIdAndRegistrationStatus(
                            eventId,
                            participant.getStudentId(),
                            "WAITLISTED")) {

                throw new IllegalStateException(
                        "Student is already on the waitlist for this event: "
                                + normalizedEmail
                );
            }

            participants.add(participant);
        }

        /*
         * Registering student itself must not already
         * appear as an event participant.
         */
        if (participantRepository.existsByEventIdAndStudentId(
                eventId,
                registeringStudentId)) {

            throw new IllegalStateException(
                    "You are already a participant in this event."
            );
        }

        /*
         * ========================================================
         * SEATING VALIDATION
         * ========================================================
         *
         * If seating is being used, a confirmed registration
         * must have:
         *
         * - seatIds
         * - holdToken
         *
         * The selected seats must belong to that hold.
         */

        List<Integer> requestedSeatIds =
                request.getSeatIds();

        String holdToken =
                request.getHoldToken();

        boolean seatingRequested =
                requestedSeatIds != null
                        && !requestedSeatIds.isEmpty();

        if (seatingRequested) {

            if (requestedSeatIds.size() != numberOfSeats) {

                throw new IllegalArgumentException(
                        "The number of selected seats must match "
                                + "the number of registration seats."
                );
            }

            if (holdToken == null || holdToken.isBlank()) {

                throw new IllegalArgumentException(
                        "Seat hold token is required."
                );
            }

            validateSeatHold(
                    eventId,
                    registeringStudentId,
                    requestedSeatIds,
                    holdToken
            );
        }

        /*
         * ========================================================
         * CONFIRM OR WAITLIST
         * ========================================================
         */

        boolean confirmed =
                event.getAvailableSeats() >= numberOfSeats;

        /*
         * If seating is explicitly being used and the group
         * is confirmed, the held seats must exist.
         */
        if (confirmed && event.getAvailableSeats() < numberOfSeats) {

            throw new IllegalStateException(
                    "Not enough seats are available."
            );
        }

        EventRegistration registration =
                new EventRegistration();

        registration.setEventId(eventId);
        registration.setStudentId(registeringStudentId);
        registration.setNumberOfSeats(numberOfSeats);

        registration.setRegistrationStatus(
                confirmed
                        ? "CONFIRMED"
                        : "WAITLISTED"
        );

        registration.setRegisteredAt(
                LocalDateTime.now()
        );

        EventRegistration savedRegistration =
                registrationRepository.save(registration);

        /*
         * ========================================================
         * STORE PARTICIPANTS
         * ========================================================
         */

        for (Student participant : participants) {

            EventParticipant eventParticipant =
                    new EventParticipant();

            eventParticipant.setEventId(eventId);

            eventParticipant.setRegistrationId(
                    savedRegistration.getRegistrationId()
            );

            eventParticipant.setStudentId(
                    participant.getStudentId()
            );

            participantRepository.save(
                    eventParticipant
            );
        }

        /*
         * ========================================================
         * CONFIRMED REGISTRATION
         * ========================================================
         */

        if (confirmed) {

            /*
             * Consume normal event capacity.
             */
            event.setAvailableSeats(
                    event.getAvailableSeats()
                            - numberOfSeats
            );

            eventRepository.save(event);

            /*
             * Convert temporary held seats into BOOKED seats.
             */
            if (seatingRequested) {

                bookHeldSeats(
                        eventId,
                        registeringStudentId,
                        savedRegistration.getRegistrationId(),
                        requestedSeatIds,
                        holdToken
                );
            }
        }

        /*
         * ========================================================
         * WAITLISTED REGISTRATION
         * ========================================================
         *
         * A waitlisted registration does not consume seats.
         *
         * If a hold exists, we do not book those seats because
         * the registration was not confirmed.
         */
        if (!confirmed && seatingRequested) {

            throw new IllegalStateException(
                    "There are not enough available seats "
                            + "to confirm this registration. "
                            + "Please select fewer seats."
            );
        }

        return savedRegistration;
    }


    /*
     * ============================================================
     * VALIDATE SEAT HOLD
     * ============================================================
     */

    private void validateSeatHold(
            Integer eventId,
            Integer studentId,
            List<Integer> seatIds,
            String holdToken) {

        LocalDateTime now =
                LocalDateTime.now();

        List<EventSeatHold> holds =
                eventSeatHoldRepository
                        .findByHoldToken(holdToken);

        if (holds == null || holds.isEmpty()) {

            throw new IllegalStateException(
                    "Seat hold was not found or has expired."
            );
        }

        /*
         * Remove expired holds from consideration.
         */
        List<EventSeatHold> validHolds =
                new ArrayList<>();

        for (EventSeatHold hold : holds) {

            if (hold.getEventId().equals(eventId)
                    && hold.getStudentId().equals(studentId)
                    && hold.getExpiresAt().isAfter(now)) {

                validHolds.add(hold);
            }
        }

        if (validHolds.size() != seatIds.size()) {

            throw new IllegalStateException(
                    "The selected seats are no longer held by you."
            );
        }

        Set<Integer> heldSeatIds =
                new HashSet<>();

        for (EventSeatHold hold : validHolds) {
            heldSeatIds.add(hold.getSeatId());
        }

        for (Integer seatId : seatIds) {

            if (!heldSeatIds.contains(seatId)) {

                throw new IllegalStateException(
                        "One or more selected seats are not "
                                + "held by you."
                );
            }
        }
    }


    /*
     * ============================================================
     * BOOK HELD SEATS
     * ============================================================
     */

    private void bookHeldSeats(
            Integer eventId,
            Integer studentId,
            Integer registrationId,
            List<Integer> seatIds,
            String holdToken) {

        LocalDateTime now =
                LocalDateTime.now();

        /*
         * Retrieve all holds for this token.
         */
        List<EventSeatHold> holds =
                eventSeatHoldRepository
                        .findByHoldToken(holdToken);

        if (holds == null || holds.isEmpty()) {

            throw new IllegalStateException(
                    "Seat hold could not be found."
            );
        }

        Set<Integer> requestedSeatSet =
                new HashSet<>(seatIds);

        List<EventSeatHold> matchingHolds =
                new ArrayList<>();

        for (EventSeatHold hold : holds) {

            if (hold.getEventId().equals(eventId)
                    && hold.getStudentId().equals(studentId)
                    && hold.getExpiresAt().isAfter(now)
                    && requestedSeatSet.contains(
                            hold.getSeatId())) {

                matchingHolds.add(hold);
            }
        }

        if (matchingHolds.size() != seatIds.size()) {

            throw new IllegalStateException(
                    "One or more selected seat holds "
                            + "are no longer valid."
            );
        }

        /*
         * Process every selected seat.
         */
        for (Integer seatId : seatIds) {

            EventSeat seat =
                    eventSeatRepository
                            .findBySeatIdAndEventId(
                                    seatId,
                                    eventId
                            )
                            .orElseThrow(() ->
                                    new IllegalStateException(
                                            "Selected seat was not found."
                                    )
                            );

            /*
             * Seat must not already be booked.
             */
            if ("BOOKED".equalsIgnoreCase(
                    seat.getSeatState())) {

                throw new IllegalStateException(
                        "Seat "
                                + seat.getSeatLabel()
                                + " is already booked."
                );
            }

            /*
             * Create permanent registration_seats record.
             */
            RegistrationSeat registrationSeat =
                    new RegistrationSeat();

            registrationSeat.setRegistrationId(
                    registrationId
            );

            registrationSeat.setEventId(
                    eventId
            );

            registrationSeat.setSeatId(
                    seatId
            );

            registrationSeat.setAssignedAt(
                    LocalDateTime.now()
            );

            registrationSeatRepository.save(
                    registrationSeat
            );

            /*
             * Change temporary state to permanent BOOKED.
             */
            seat.setSeatState("BOOKED");

            eventSeatRepository.save(seat);
        }

        /*
         * Remove temporary holds after successful booking.
         */
        eventSeatHoldRepository.deleteByHoldToken(
                holdToken
        );
    }


    /*
     * ============================================================
     * BASIC STUDENT REGISTRATIONS
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<EventRegistration> getStudentRegistrations(
            Integer studentId) {

        return registrationRepository
                .findByStudentIdOrderByRegisteredAtDesc(
                        studentId
                );
    }


    /*
     * ============================================================
     * MY REGISTRATIONS
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<MyRegistrationResponse> getStudentRegistrationSummaries(
            Integer studentId) {

        List<EventRegistration> registrations =
                registrationRepository
                        .findByStudentIdOrderByRegisteredAtDesc(
                                studentId
                        );

        List<MyRegistrationResponse> responses =
                new ArrayList<>();

        for (EventRegistration registration : registrations) {

            Event event =
                    eventRepository
                            .findById(
                                    registration.getEventId()
                            )
                            .orElse(null);

            if (event == null) {
                continue;
            }

            MyRegistrationResponse response =
                    buildRegistrationResponse(
                            registration,
                            event
                    );

            responses.add(response);
        }

        return responses;
    }


    /*
     * ============================================================
     * BUILD REGISTRATION RESPONSE
     * ============================================================
     */

    private MyRegistrationResponse buildRegistrationResponse(
            EventRegistration registration,
            Event event) {

        MyRegistrationResponse response =
                new MyRegistrationResponse();

        response.setRegistrationId(
                registration.getRegistrationId()
        );

        response.setEventId(
                registration.getEventId()
        );

        response.setEventTitle(
                event.getTitle()
        );

        response.setEventDate(
                event.getEventDate()
        );

        response.setStartTime(
                event.getStartTime()
        );

        response.setEndTime(
                event.getEndTime()
        );

        response.setVenue(
                event.getVenue()
        );

        response.setNumberOfSeats(
                registration.getNumberOfSeats()
        );

        response.setRegistrationStatus(
                registration.getRegistrationStatus()
        );

        response.setRegisteredAt(
                registration.getRegisteredAt()
        );

        /*
         * Participant information.
         */
        List<EventParticipant> participants =
                participantRepository
                        .findByRegistrationIdOrderByParticipantIdAsc(
                                registration.getRegistrationId()
                        );

        List<MyRegistrationResponse.ParticipantResponse>
                participantResponses =
                new ArrayList<>();

        for (EventParticipant participant : participants) {

            Student student =
                    studentRepository
                            .findById(
                                    participant.getStudentId()
                            )
                            .orElse(null);

            if (student == null) {
                continue;
            }

            participantResponses.add(
                    new MyRegistrationResponse.ParticipantResponse(
                            student.getStudentId(),
                            student.getName(),
                            student.getEmail()
                    )
            );
        }

        response.setParticipants(
                participantResponses
        );

        response.setParticipantCount(
                participantResponses.size()
        );

        return response;
    }


    /*
     * ============================================================
     * FACULTY REGISTRATION DASHBOARD
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<MyRegistrationResponse> getRegistrationDetailsForEvent(
            Integer eventId) {

        Event event =
                eventRepository
                        .findById(eventId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Event not found."
                                )
                        );

        List<EventRegistration> registrations =
                registrationRepository
                        .findByEventIdOrderByRegisteredAtAsc(
                                eventId
                        );

        List<MyRegistrationResponse> responses =
                new ArrayList<>();

        for (EventRegistration registration : registrations) {

            responses.add(
                    buildRegistrationResponse(
                            registration,
                            event
                    )
            );
        }

        return responses;
    }


    /*
     * ============================================================
     * FACULTY SEARCH / FILTER
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<MyRegistrationResponse> searchEventRegistrations(
            Integer eventId,
            String search,
            String status) {

        List<MyRegistrationResponse> registrations =
                getRegistrationDetailsForEvent(eventId);

        String normalizedSearch =
                search == null
                        ? ""
                        : search.trim().toLowerCase(Locale.ROOT);

        String normalizedStatus =
                status == null
                        ? "ALL"
                        : status.trim().toUpperCase(Locale.ROOT);

        List<MyRegistrationResponse> filtered =
                new ArrayList<>();

        for (MyRegistrationResponse registration
                : registrations) {

            if (!"ALL".equals(normalizedStatus)
                    && !normalizedStatus.equalsIgnoreCase(
                            registration.getRegistrationStatus())) {

                continue;
            }

            if (normalizedSearch.isBlank()) {

                filtered.add(registration);
                continue;
            }

            if (registration.getRegistrationId() != null
                    && String.valueOf(
                            registration.getRegistrationId()
                    ).contains(normalizedSearch)) {

                filtered.add(registration);
                continue;
            }

            boolean participantMatched = false;

            if (registration.getParticipants() != null) {

                for (
                        MyRegistrationResponse.ParticipantResponse participant
                        : registration.getParticipants()
                ) {

                    String participantName =
                            participant.getName() == null
                                    ? ""
                                    : participant.getName()
                                    .toLowerCase(Locale.ROOT);

                    String participantEmail =
                            participant.getEmail() == null
                                    ? ""
                                    : participant.getEmail()
                                    .toLowerCase(Locale.ROOT);

                    String participantId =
                            participant.getStudentId() == null
                                    ? ""
                                    : String.valueOf(
                                            participant.getStudentId()
                                    );

                    if (participantName.contains(
                            normalizedSearch)
                            || participantEmail.contains(
                            normalizedSearch)
                            || participantId.contains(
                            normalizedSearch)) {

                        participantMatched = true;
                        break;
                    }
                }
            }

            if (participantMatched) {
                filtered.add(registration);
            }
        }

        return filtered;
    }


    /*
     * ============================================================
     * REGISTRATION STATISTICS
     * ============================================================
     */

    @Transactional(readOnly = true)
    public RegistrationStatistics getRegistrationStatistics(
            Integer eventId) {

        List<EventRegistration> registrations =
                registrationRepository
                        .findByEventIdOrderByRegisteredAtAsc(
                                eventId
                        );

        int totalRegistrations = 0;
        int confirmedRegistrations = 0;
        int waitlistedRegistrations = 0;
        int cancelledRegistrations = 0;

        int confirmedSeats = 0;
        int waitlistedSeats = 0;

        for (EventRegistration registration
                : registrations) {

            totalRegistrations++;

            String status =
                    registration.getRegistrationStatus();

            if ("CONFIRMED".equalsIgnoreCase(status)) {

                confirmedRegistrations++;

                confirmedSeats +=
                        registration.getNumberOfSeats();

            } else if ("WAITLISTED".equalsIgnoreCase(status)) {

                waitlistedRegistrations++;

                waitlistedSeats +=
                        registration.getNumberOfSeats();

            } else if ("CANCELLED".equalsIgnoreCase(status)) {

                cancelledRegistrations++;
            }
        }

        Event event =
                eventRepository
                        .findById(eventId)
                        .orElse(null);

        int totalSeats =
                event == null || event.getTotalSeats() == null
                        ? 0
                        : event.getTotalSeats();

        int availableSeats =
                event == null || event.getAvailableSeats() == null
                        ? 0
                        : event.getAvailableSeats();

        double occupancyPercentage = 0;

        if (totalSeats > 0) {

            occupancyPercentage =
                    ((double) (totalSeats - availableSeats)
                            / totalSeats) * 100.0;
        }

        return new RegistrationStatistics(
                totalRegistrations,
                confirmedRegistrations,
                waitlistedRegistrations,
                cancelledRegistrations,
                confirmedSeats,
                waitlistedSeats,
                totalSeats,
                availableSeats,
                occupancyPercentage
        );
    }


    /*
     * ============================================================
     * CANCELLATION
     * ============================================================
     */

    @Transactional
    public void cancelRegistration(
            Integer registrationId,
            Integer studentId) {

        EventRegistration registration =
                registrationRepository
                        .findByRegistrationIdAndStudentId(
                                registrationId,
                                studentId
                        )
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Registration not found."
                                )
                        );

        String currentStatus =
                registration.getRegistrationStatus();

        if (!"CONFIRMED".equalsIgnoreCase(currentStatus)
                && !"WAITLISTED".equalsIgnoreCase(currentStatus)) {

            throw new IllegalStateException(
                    "Only confirmed or waitlisted registrations "
                            + "can be cancelled."
            );
        }

        /*
         * Waitlisted registration.
         */
        if ("WAITLISTED".equalsIgnoreCase(currentStatus)) {

            registration.setRegistrationStatus(
                    "CANCELLED"
            );

            registrationRepository.save(
                    registration
            );

            participantRepository.deleteByRegistrationId(
                    registrationId
            );

            return;
        }

        /*
         * Confirmed registration.
         */
        Event event =
                eventRepository.findActiveEventForUpdate(
                        registration.getEventId(),
                        "ACTIVE"
                )
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Event not found or is no longer active."
                        )
                );

        int seatsToRestore =
                registration.getNumberOfSeats();

        /*
         * Release permanently booked seats.
         */
        List<RegistrationSeat> registrationSeats =
                registrationSeatRepository
                        .findByRegistrationId(
                                registrationId
                        );

        for (RegistrationSeat registrationSeat
                : registrationSeats) {

            eventSeatRepository
                    .findBySeatIdAndEventId(
                            registrationSeat.getSeatId(),
                            registration.getEventId()
                    )
                    .ifPresent(seat -> {

                        seat.setSeatState("AVAILABLE");

                        eventSeatRepository.save(seat);
                    });
        }

        registrationSeatRepository
                .deleteByRegistrationId(
                        registrationId
                );

        registration.setRegistrationStatus(
                "CANCELLED"
        );

        registrationRepository.save(
                registration
        );

        participantRepository.deleteByRegistrationId(
                registrationId
        );

        int restoredSeats =
                event.getAvailableSeats()
                        + seatsToRestore;

        if (restoredSeats > event.getTotalSeats()) {

            restoredSeats =
                    event.getTotalSeats();
        }

        event.setAvailableSeats(
                restoredSeats
        );

        eventRepository.save(event);

        promoteWaitlistedRegistrations(event);
    }


    /*
     * ============================================================
     * WAITLIST PROMOTION
     * ============================================================
     */

    @Transactional
    protected void promoteWaitlistedRegistrations(
            Event event) {

        List<EventRegistration> waitlisted =
                registrationRepository
                        .findByEventIdAndRegistrationStatusOrderByRegisteredAtAsc(
                                event.getEventId(),
                                "WAITLISTED"
                        );

        if (waitlisted.isEmpty()) {
            return;
        }

        int availableSeats =
                event.getAvailableSeats();

        boolean changed = false;

        for (EventRegistration registration
                : waitlisted) {

            int requestedSeats =
                    registration.getNumberOfSeats();

            if (requestedSeats > availableSeats) {
                continue;
            }

            registration.setRegistrationStatus(
                    "CONFIRMED"
            );

            registrationRepository.save(
                    registration
            );

            availableSeats -=
                    requestedSeats;

            changed = true;
        }

        if (changed) {

            event.setAvailableSeats(
                    availableSeats
            );

            eventRepository.save(event);
        }
    }


    /*
     * ============================================================
     * FACULTY REGISTRATION LIST
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<EventRegistration> getRegistrationsForEvent(
            Integer eventId) {

        return registrationRepository
                .findByEventIdOrderByRegisteredAtAsc(
                        eventId
                );
    }


    /*
     * ============================================================
     * WAITLIST LIST
     * ============================================================
     */

    @Transactional(readOnly = true)
    public List<EventRegistration> getWaitlistedRegistrations(
            Integer eventId) {

        return registrationRepository
                .findByEventIdAndRegistrationStatusOrderByRegisteredAtAsc(
                        eventId,
                        "WAITLISTED"
                );
    }


    /*
     * ============================================================
     * STATISTICS DTO
     * ============================================================
     */

    public static class RegistrationStatistics {

        private int totalRegistrations;
        private int confirmedRegistrations;
        private int waitlistedRegistrations;
        private int cancelledRegistrations;

        private int confirmedSeats;
        private int waitlistedSeats;

        private int totalSeats;
        private int availableSeats;

        private double occupancyPercentage;

        public RegistrationStatistics(
                int totalRegistrations,
                int confirmedRegistrations,
                int waitlistedRegistrations,
                int cancelledRegistrations,
                int confirmedSeats,
                int waitlistedSeats,
                int totalSeats,
                int availableSeats,
                double occupancyPercentage) {

            this.totalRegistrations =
                    totalRegistrations;

            this.confirmedRegistrations =
                    confirmedRegistrations;

            this.waitlistedRegistrations =
                    waitlistedRegistrations;

            this.cancelledRegistrations =
                    cancelledRegistrations;

            this.confirmedSeats =
                    confirmedSeats;

            this.waitlistedSeats =
                    waitlistedSeats;

            this.totalSeats =
                    totalSeats;

            this.availableSeats =
                    availableSeats;

            this.occupancyPercentage =
                    occupancyPercentage;
        }

        public int getTotalRegistrations() {
            return totalRegistrations;
        }

        public int getConfirmedRegistrations() {
            return confirmedRegistrations;
        }

        public int getWaitlistedRegistrations() {
            return waitlistedRegistrations;
        }

        public int getCancelledRegistrations() {
            return cancelledRegistrations;
        }

        public int getConfirmedSeats() {
            return confirmedSeats;
        }

        public int getWaitlistedSeats() {
            return waitlistedSeats;
        }

        public int getTotalSeats() {
            return totalSeats;
        }

        public int getAvailableSeats() {
            return availableSeats;
        }

        public double getOccupancyPercentage() {
            return occupancyPercentage;
        }
    }
}