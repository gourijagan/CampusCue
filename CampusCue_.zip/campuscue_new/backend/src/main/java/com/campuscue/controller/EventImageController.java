package com.campuscue.controller;

import com.campuscue.model.EventImage;
import com.campuscue.service.EventImageService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/events")
public class EventImageController {

    private final EventImageService imageService;

    public EventImageController(
            EventImageService imageService) {

        this.imageService = imageService;
    }

    @PostMapping(
            value = "/{eventId}/images",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<?> uploadImage(
            @PathVariable Integer eventId,
            @RequestParam("file") MultipartFile file,
            @RequestParam("imageType") String imageType,
            HttpSession session) {

        String userType =
                (String) session.getAttribute("userType");

        String userId =
                (String) session.getAttribute("userId");

        if (userType == null || userId == null) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "You must be logged in."
                    ));
        }

        try {

            EventImage image =
                    imageService.uploadImage(
                            eventId,
                            file,
                            imageType,
                            userType,
                            userId
                    );

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(Map.of(
                            "success", true,
                            "message",
                            "Image uploaded successfully.",
                            "image", image
                    ));

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (Exception e) {

            return ResponseEntity
                    .status(
                            HttpStatus.INTERNAL_SERVER_ERROR
                    )
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Could not upload image."
                    ));
        }
    }

    @GetMapping("/{eventId}/images")
    public ResponseEntity<?> getEventImages(
            @PathVariable Integer eventId) {

        try {

            List<EventImage> images =
                    imageService.getEventImages(eventId);

            return ResponseEntity.ok(images);

        } catch (Exception e) {

            return ResponseEntity
                    .status(
                            HttpStatus.INTERNAL_SERVER_ERROR
                    )
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Could not load event images."
                    ));
        }
    }

    @DeleteMapping("/images/{imageId}")
    public ResponseEntity<?> deleteImage(
            @PathVariable Integer imageId,
            HttpSession session) {

        String userType =
                (String) session.getAttribute("userType");

        String userId =
                (String) session.getAttribute("userId");

        if (userType == null || userId == null) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of(
                            "success", false,
                            "message",
                            "You must be logged in."
                    ));
        }

        try {

            imageService.deleteImage(
                    imageId,
                    userType,
                    userId
            );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message",
                            "Image deleted successfully."
                    )
            );

        } catch (SecurityException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "success", false,
                            "message", e.getMessage()
                    ));

        } catch (Exception e) {

            return ResponseEntity
                    .status(
                            HttpStatus.INTERNAL_SERVER_ERROR
                    )
                    .body(Map.of(
                            "success", false,
                            "message",
                            "Could not delete image."
                    ));
        }
    }
}