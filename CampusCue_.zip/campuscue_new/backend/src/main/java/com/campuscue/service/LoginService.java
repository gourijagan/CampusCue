package com.campuscue.service;

import com.campuscue.dto.LoginResponse;
import com.campuscue.model.Faculty;
import com.campuscue.model.Student;
import com.campuscue.repository.FacultyRepository;
import com.campuscue.repository.StudentRepository;
import com.campuscue.util.PasswordUtil;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService {

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;

    public LoginService(
            StudentRepository studentRepository,
            FacultyRepository facultyRepository) {

        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
    }

    public LoginResponse login(String email, String password) {

        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email is required.");
        }

        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("Password is required.");
        }

        String normalizedEmail = email.trim();
        String passwordHash = PasswordUtil.hashPassword(password);

        Optional<Student> studentOptional =
                studentRepository.findByEmailIgnoreCase(normalizedEmail);

        if (studentOptional.isPresent()) {

            Student student = studentOptional.get();

            if (!"ACTIVE".equalsIgnoreCase(student.getAccountStatus())) {
                throw new SecurityException("Account is not active.");
            }

            if (!passwordHash.equals(student.getPasswordHash())) {
                throw new SecurityException("Invalid email or password.");
            }

            return new LoginResponse(
                    true,
                    "Login successful.",
                    "STUDENT",
                    String.valueOf(student.getStudentId()),
                    student.getName(),
                    student.getEmail(),
                    student.getDepartmentId(),
                    null,
                    null
            );
        }

        Optional<Faculty> facultyOptional =
                facultyRepository.findByEmailIgnoreCase(normalizedEmail);

        if (facultyOptional.isPresent()) {

            Faculty faculty = facultyOptional.get();

            if (!"ACTIVE".equalsIgnoreCase(faculty.getAccountStatus())) {
                throw new SecurityException("Account is not active.");
            }

            if (!passwordHash.equals(faculty.getPasswordHash())) {
                throw new SecurityException("Invalid email or password.");
            }

            return new LoginResponse(
                    true,
                    "Login successful.",
                    "FACULTY",
                    faculty.getFacultyId(),
                    faculty.getName(),
                    faculty.getEmail(),
                    faculty.getDepartmentId(),
                    faculty.getDesignation(),
                    faculty.getAdminLevel()
            );
        }

        throw new SecurityException("Invalid email or password.");
    }
}