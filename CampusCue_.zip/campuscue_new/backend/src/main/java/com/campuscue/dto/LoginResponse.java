package com.campuscue.dto;

public class LoginResponse {

    private boolean success;
    private String message;

    private String userType;
    private String userId;
    private String name;
    private String email;

    private Integer departmentId;

    private String designation;
    private String adminLevel;

    public LoginResponse() {
    }

    public LoginResponse(
            boolean success,
            String message,
            String userType,
            String userId,
            String name,
            String email,
            Integer departmentId,
            String designation,
            String adminLevel) {

        this.success = success;
        this.message = message;
        this.userType = userType;
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.departmentId = departmentId;
        this.designation = designation;
        this.adminLevel = adminLevel;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getAdminLevel() {
        return adminLevel;
    }

    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }
}