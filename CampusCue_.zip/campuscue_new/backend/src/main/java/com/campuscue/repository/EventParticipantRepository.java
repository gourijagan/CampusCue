package com.campuscue.repository;

import com.campuscue.model.EventParticipant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EventParticipantRepository
        extends JpaRepository<EventParticipant, Integer> {

    boolean existsByEventIdAndStudentId(
            Integer eventId,
            Integer studentId
    );

    List<EventParticipant> findByRegistrationIdOrderByParticipantIdAsc(
            Integer registrationId
    );
    void deleteByRegistrationId(Integer registrationId);

}