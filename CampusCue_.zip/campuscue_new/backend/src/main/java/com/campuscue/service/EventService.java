package com.campuscue.service;

import com.campuscue.dto.EventCreateRequest;
import com.campuscue.dto.EventUpdateRequest;
import com.campuscue.model.Event;
import com.campuscue.model.EventCoordinator;
import com.campuscue.model.Faculty;
import com.campuscue.repository.EventCoordinatorRepository;
import com.campuscue.repository.EventRepository;
import com.campuscue.repository.FacultyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Service
public class EventService {

    private final EventRepository eventRepository;
    private final FacultyRepository facultyRepository;
    private final EventCoordinatorRepository coordinatorRepository;

    public EventService(
            EventRepository eventRepository,
            FacultyRepository facultyRepository,
            EventCoordinatorRepository coordinatorRepository) {

        this.eventRepository = eventRepository;
        this.facultyRepository = facultyRepository;
        this.coordinatorRepository = coordinatorRepository;
    }

    public List<Event> getActiveEvents() {

        return eventRepository
                .findByStatusOrderByEventDateAscStartTimeAsc("ACTIVE");
    }

    public Event getActiveEventById(Integer eventId) {

        return eventRepository
                .findByEventIdAndStatus(eventId, "ACTIVE")
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Event not found."
                        )
                );
    }

    public Event createEvent(
            EventCreateRequest request,
            String facultyId) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Event details are required."
            );
        }

        if (request.getTitle() == null ||
                request.getTitle().isBlank()) {

            throw new IllegalArgumentException(
                    "Event title is required."
            );
        }

        if (request.getVenue() == null ||
                request.getVenue().isBlank()) {

            throw new IllegalArgumentException(
                    "Event venue is required."
            );
        }

        if (request.getEventType() == null ||
                request.getEventType().isBlank()) {

            throw new IllegalArgumentException(
                    "Event type is required."
            );
        }

        String eventType =
                request.getEventType().trim().toUpperCase();

        if (!eventType.equals("GENERAL") &&
                !eventType.equals("DEPARTMENT")) {

            throw new IllegalArgumentException(
                    "Event type must be GENERAL or DEPARTMENT."
            );
        }

        if (request.getEventDate() == null) {

            throw new IllegalArgumentException(
                    "Event date is required."
            );
        }

        if (request.getStartTime() == null ||
                request.getEndTime() == null) {

            throw new IllegalArgumentException(
                    "Start time and end time are required."
            );
        }

        if (!request.getEndTime()
                .isAfter(request.getStartTime())) {

            throw new IllegalArgumentException(
                    "End time must be after start time."
            );
        }

        if (request.getRegistrationDeadline() == null) {

            throw new IllegalArgumentException(
                    "Registration deadline is required."
            );
        }

        if (request.getTotalSeats() == null ||
                request.getTotalSeats() <= 0) {

            throw new IllegalArgumentException(
                    "Total seats must be greater than zero."
            );
        }

        if (request.getRegistrationDeadline()
                .isAfter(
                        LocalDateTime.of(
                                request.getEventDate(),
                                request.getEndTime()
                        )
                )) {

            throw new IllegalArgumentException(
                    "Registration deadline cannot be after the event ends."
            );
        }

        /*
         * Get the actual logged-in faculty from the database.
         *
         * We deliberately do NOT trust the departmentId
         * sent by the frontend.
         */
        Faculty faculty =
                facultyRepository.findById(facultyId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Faculty account was not found."
                                )
                        );

        if (!"ACTIVE".equalsIgnoreCase(
                faculty.getAccountStatus())) {

            throw new SecurityException(
                    "Faculty account is not active."
            );
        }

        /*
         * Department handling:
         *
         * GENERAL EVENT
         *      -> no department
         *
         * DEPARTMENT EVENT
         *      -> automatically use the logged-in
         *         faculty's department.
         */
        Integer departmentId = null;

        if (eventType.equals("DEPARTMENT")) {

            departmentId = faculty.getDepartmentId();

            if (departmentId == null) {

                throw new IllegalArgumentException(
                        "This faculty account is not assigned to a department."
                );
            }
        }

        Event event = new Event();

        event.setTitle(request.getTitle().trim());
        event.setDescription(request.getDescription());
        event.setEventType(eventType);

        /*
         * IMPORTANT:
         * departmentId comes from the faculty database,
         * not from the browser.
         */
        event.setDepartmentId(departmentId);

        event.setVenue(request.getVenue().trim());
        event.setEventDate(request.getEventDate());
        event.setStartTime(request.getStartTime());
        event.setEndTime(request.getEndTime());

        event.setRegistrationDeadline(
                request.getRegistrationDeadline()
        );

        event.setTotalSeats(request.getTotalSeats());
        event.setAvailableSeats(request.getTotalSeats());

        event.setEligibility(request.getEligibility());

        event.setStatus("ACTIVE");
        event.setCreatedByFacultyId(facultyId);
        event.setCreatedAt(LocalDateTime.now());

        return eventRepository.save(event);
    }

    public List<Event> getEventsCreatedByFaculty(
            String facultyId) {

        return eventRepository
                .findByCreatedByFacultyIdOrderByEventDateAscStartTimeAsc(
                        facultyId
                );
    }

    /**
     * Updates an event.
     *
     * Authorized users:
     * 1. Active faculty/admin
     * 2. Active student coordinator assigned to this event
     */
    @Transactional
    public Event updateEvent(
            Integer eventId,
            EventUpdateRequest request,
            String userType,
            String userId) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Event details are required."
            );
        }

        if (userType == null || userType.isBlank()) {
            throw new SecurityException(
                    "Login is required."
            );
        }

        if (userId == null || userId.isBlank()) {
            throw new SecurityException(
                    "User session is invalid."
            );
        }

        Event event = eventRepository
                .findByEventIdAndStatus(eventId, "ACTIVE")
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Active event not found."
                        )
                );

        /*
         * FACULTY / ADMIN
         */
        if ("FACULTY".equalsIgnoreCase(userType)) {

            Faculty faculty = facultyRepository
                    .findById(userId)
                    .orElseThrow(() ->
                            new SecurityException(
                                    "Faculty account not found."
                            )
                    );

            if (!"ACTIVE".equalsIgnoreCase(
                    faculty.getAccountStatus())) {

                throw new SecurityException(
                        "Faculty account is not active."
                );
            }

        /*
         * STUDENT COORDINATOR
         */
        } else if ("STUDENT".equalsIgnoreCase(userType)) {

            Integer studentId;

            try {

                studentId = Integer.parseInt(userId);

            } catch (NumberFormatException e) {

                throw new SecurityException(
                        "Invalid student session."
                );
            }

            boolean isCoordinator =
                    coordinatorRepository
                            .existsByEventIdAndStudentIdAndStatus(
                                    eventId,
                                    studentId,
                                    "ACTIVE"
                            );

            if (!isCoordinator) {

                throw new SecurityException(
                        "You are not an active coordinator for this event."
                );
            }

        } else {

            throw new SecurityException(
                    "You do not have permission to edit this event."
            );
        }

        /*
         * Validate the new event information.
         */

        if (request.getTitle() == null ||
                request.getTitle().isBlank()) {

            throw new IllegalArgumentException(
                    "Event title is required."
            );
        }

        if (request.getVenue() == null ||
                request.getVenue().isBlank()) {

            throw new IllegalArgumentException(
                    "Event venue is required."
            );
        }

        if (request.getEventDate() == null ||
                request.getEventDate().isBlank()) {

            throw new IllegalArgumentException(
                    "Event date is required."
            );
        }

        if (request.getStartTime() == null ||
                request.getStartTime().isBlank() ||
                request.getEndTime() == null ||
                request.getEndTime().isBlank()) {

            throw new IllegalArgumentException(
                    "Start time and end time are required."
            );
        }

        if (request.getRegistrationDeadline() == null ||
                request.getRegistrationDeadline().isBlank()) {

            throw new IllegalArgumentException(
                    "Registration deadline is required."
            );
        }

        LocalDate newEventDate;
        LocalTime newStartTime;
        LocalTime newEndTime;
        LocalDateTime newRegistrationDeadline;

        try {

            newEventDate =
                    LocalDate.parse(request.getEventDate());

            newStartTime =
                    LocalTime.parse(request.getStartTime());

            newEndTime =
                    LocalTime.parse(request.getEndTime());

            newRegistrationDeadline =
                    LocalDateTime.parse(
                            request.getRegistrationDeadline()
                    );

        } catch (Exception e) {

            throw new IllegalArgumentException(
                    "Invalid date or time format."
            );
        }

        if (!newEndTime.isAfter(newStartTime)) {

            throw new IllegalArgumentException(
                    "End time must be after start time."
            );
        }

        if (newRegistrationDeadline.isAfter(
                LocalDateTime.of(
                        newEventDate,
                        newEndTime
                )
        )) {

            throw new IllegalArgumentException(
                    "Registration deadline cannot be after the event ends."
            );
        }

        /*
         * Update only editable event details.
         *
         * Seat counts are intentionally NOT changed here.
         */
        event.setTitle(request.getTitle().trim());
        event.setDescription(request.getDescription());
        event.setVenue(request.getVenue().trim());
        event.setEventDate(newEventDate);
        event.setStartTime(newStartTime);
        event.setEndTime(newEndTime);

        event.setRegistrationDeadline(
                newRegistrationDeadline
        );

        event.setEligibility(request.getEligibility());

        return eventRepository.save(event);
    }
}