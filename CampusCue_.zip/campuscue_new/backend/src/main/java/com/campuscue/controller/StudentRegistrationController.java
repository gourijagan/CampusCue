package com.campuscue.controller;

import com.campuscue.dto.StudentRegistrationSubmitRequest;
import com.campuscue.model.StudentRegistrationRequest;
import com.campuscue.service.StudentRegistrationService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/student-registration")
public class StudentRegistrationController {

    private final StudentRegistrationService registrationService;

    public StudentRegistrationController(
            StudentRegistrationService registrationService) {

        this.registrationService = registrationService;
    }

    // =========================================================
    // STUDENT - SUBMIT REGISTRATION
    // =========================================================

    @PostMapping
    public ResponseEntity<?> submitRegistration(
            @RequestBody StudentRegistrationSubmitRequest request) {

        try {

            StudentRegistrationRequest savedRequest =
                    registrationService.submitRequest(request);

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message",
                            "Registration request submitted successfully. Please wait for your tutor's approval.",
                            "requestId",
                            savedRequest.getRequestId()
                    )
            );

        } catch (IllegalArgumentException e) {

            return ResponseEntity.badRequest()
                    .body(
                            Map.of(
                                    "success", false,
                                    "message", e.getMessage()
                            )
                    );
        }
    }

    // =========================================================
    // FACULTY - VIEW PENDING REQUESTS
    // =========================================================

    @GetMapping("/pending")
    public ResponseEntity<?> getPendingRequests(
            HttpSession session) {

        try {

            String userType =
                    (String) session.getAttribute("userType");

            String facultyId =
                    (String) session.getAttribute("userId");

            String adminLevel =
                    (String) session.getAttribute("adminLevel");

            if (!"FACULTY".equalsIgnoreCase(userType)) {

                return ResponseEntity.status(403)
                        .body(
                                Map.of(
                                        "success", false,
                                        "message",
                                        "Faculty access is required."
                                )
                        );
            }

            List<StudentRegistrationRequest> requests =
                    registrationService.getPendingRequests(
                            facultyId,
                            adminLevel
                    );

            /*
             * We do NOT return password_hash to the frontend.
             */
            List<Map<String, Object>> response =
                    requests.stream()
                            .map(request ->
                                    Map.<String, Object>of(
                                            "requestId",
                                            request.getRequestId(),

                                            "regNo",
                                            request.getRegNo(),

                                            "name",
                                            request.getName(),

                                            "batchStartYear",
                                            request.getBatchStartYear(),

                                            "batchEndYear",
                                            request.getBatchEndYear(),

                                            "departmentId",
                                            request.getDepartmentId(),

                                            "tutorFacultyId",
                                            request.getTutorFacultyId(),

                                            "email",
                                            request.getEmail(),

                                            "status",
                                            request.getStatus(),

                                            "requestedAt",
                                            request.getRequestedAt()
                                    )
                            )
                            .toList();

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {

            return ResponseEntity.badRequest()
                    .body(
                            Map.of(
                                    "success", false,
                                    "message", e.getMessage()
                            )
                    );
        }
    }

    // =========================================================
    // FACULTY - APPROVE REQUEST
    // =========================================================

    @PostMapping("/{requestId}/approve")
    public ResponseEntity<?> approveRequest(
            @PathVariable Integer requestId,
            HttpSession session) {

        try {

            String userType =
                    (String) session.getAttribute("userType");

            String facultyId =
                    (String) session.getAttribute("userId");

            String adminLevel =
                    (String) session.getAttribute("adminLevel");

            if (!"FACULTY".equalsIgnoreCase(userType)) {

                return ResponseEntity.status(403)
                        .body(
                                Map.of(
                                        "success", false,
                                        "message",
                                        "Faculty access is required."
                                )
                        );
            }

            StudentRegistrationRequest approvedRequest =
                    registrationService.approveRequest(
                            requestId,
                            facultyId,
                            adminLevel
                    );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message",
                            "Student registration approved successfully.",
                            "requestId",
                            approvedRequest.getRequestId()
                    )
            );

        } catch (IllegalArgumentException e) {

            return ResponseEntity.badRequest()
                    .body(
                            Map.of(
                                    "success", false,
                                    "message", e.getMessage()
                            )
                    );
        }
    }

    // =========================================================
    // FACULTY - REJECT REQUEST
    // =========================================================

    @PostMapping("/{requestId}/reject")
    public ResponseEntity<?> rejectRequest(
            @PathVariable Integer requestId,
            HttpSession session) {

        try {

            String userType =
                    (String) session.getAttribute("userType");

            String facultyId =
                    (String) session.getAttribute("userId");

            String adminLevel =
                    (String) session.getAttribute("adminLevel");

            if (!"FACULTY".equalsIgnoreCase(userType)) {

                return ResponseEntity.status(403)
                        .body(
                                Map.of(
                                        "success", false,
                                        "message",
                                        "Faculty access is required."
                                )
                        );
            }

            StudentRegistrationRequest rejectedRequest =
                    registrationService.rejectRequest(
                            requestId,
                            facultyId,
                            adminLevel
                    );

            return ResponseEntity.ok(
                    Map.of(
                            "success", true,
                            "message",
                            "Student registration rejected.",
                            "requestId",
                            rejectedRequest.getRequestId()
                    )
            );

        } catch (IllegalArgumentException e) {

            return ResponseEntity.badRequest()
                    .body(
                            Map.of(
                                    "success", false,
                                    "message", e.getMessage()
                            )
                    );
        }
    }
    @GetMapping("/pending/count")
public ResponseEntity<?> getPendingRequestCount(
        HttpSession session) {

    String userType =
            (String) session.getAttribute("userType");

    String facultyId =
            (String) session.getAttribute("userId");

    String adminLevel =
            (String) session.getAttribute("adminLevel");

    if (!"FACULTY".equals(userType)
            || facultyId == null) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(Map.of(
                        "success", false,
                        "message",
                        "Faculty login required."
                ));
    }

    try {

        long count =
                registrationService
                        .getPendingRequestCount(
                                facultyId,
                                adminLevel
                        );

        return ResponseEntity.ok(
                Map.of(
                        "success", true,
                        "count", count
                )
        );

    } catch (SecurityException e) {

        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(Map.of(
                        "success", false,
                        "message", e.getMessage()
                ));

    } catch (IllegalArgumentException e) {

        return ResponseEntity
                .badRequest()
                .body(Map.of(
                        "success", false,
                        "message", e.getMessage()
                ));
    }
}
}