package com.campuscue.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "event_coordinators",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uq_event_coordinator",
                        columnNames = {"event_id", "student_id"}
                )
        }
)
public class EventCoordinator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_coordinator_id")
    private Integer eventCoordinatorId;

    @Column(name = "event_id", nullable = false)
    private Integer eventId;

    @Column(name = "student_id", nullable = false)
    private Integer studentId;

    @Column(name = "assigned_by_faculty_id", nullable = false)
    private String assignedByFacultyId;

    @Column(name = "assigned_at", nullable = false)
    private LocalDateTime assignedAt;

    @Column(name = "status", nullable = false)
    private String status;

    public EventCoordinator() {
    }

    public Integer getEventCoordinatorId() {
        return eventCoordinatorId;
    }

    public void setEventCoordinatorId(Integer eventCoordinatorId) {
        this.eventCoordinatorId = eventCoordinatorId;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getAssignedByFacultyId() {
        return assignedByFacultyId;
    }

    public void setAssignedByFacultyId(String assignedByFacultyId) {
        this.assignedByFacultyId = assignedByFacultyId;
    }

    public LocalDateTime getAssignedAt() {
        return assignedAt;
    }

    public void setAssignedAt(LocalDateTime assignedAt) {
        this.assignedAt = assignedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}