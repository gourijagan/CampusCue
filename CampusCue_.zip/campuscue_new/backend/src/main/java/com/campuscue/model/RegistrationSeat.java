package com.campuscue.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "registration_seats")
public class RegistrationSeat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registration_seat_id")
    private Integer registrationSeatId;

    @Column(name = "registration_id", nullable = false)
    private Integer registrationId;

    @Column(name = "event_id", nullable = false)
    private Integer eventId;

    @Column(name = "seat_id", nullable = false)
    private Integer seatId;

    @Column(name = "assigned_at", nullable = false)
    private LocalDateTime assignedAt;

    public RegistrationSeat() {
    }

    public Integer getRegistrationSeatId() {
        return registrationSeatId;
    }

    public void setRegistrationSeatId(Integer registrationSeatId) {
        this.registrationSeatId = registrationSeatId;
    }

    public Integer getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(Integer registrationId) {
        this.registrationId = registrationId;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getSeatId() {
        return seatId;
    }

    public void setSeatId(Integer seatId) {
        this.seatId = seatId;
    }

    public LocalDateTime getAssignedAt() {
        return assignedAt;
    }

    public void setAssignedAt(LocalDateTime assignedAt) {
        this.assignedAt = assignedAt;
    }
}