package com.campuscue.repository;

import com.campuscue.model.StudentRegistrationRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StudentRegistrationRequestRepository
        extends JpaRepository<StudentRegistrationRequest, Integer> {

    boolean existsByEmailIgnoreCaseAndStatus(
            String email,
            String status
    );

    boolean existsByRegNoIgnoreCaseAndStatus(
            String regNo,
            String status
    );

    List<StudentRegistrationRequest>
    findByTutorFacultyIdAndStatusOrderByRequestedAtAsc(
            String tutorFacultyId,
            String status
    );

    List<StudentRegistrationRequest>
    findByStatusOrderByRequestedAtAsc(
            String status
    );
    long countByTutorFacultyIdAndStatus(
    String tutorFacultyId,
    String status
);

long countByStatus(
    String status
);
}