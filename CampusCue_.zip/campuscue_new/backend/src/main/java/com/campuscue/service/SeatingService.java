package com.campuscue.service;

import com.campuscue.dto.SeatingConfigRequest;
import com.campuscue.model.Event;
import com.campuscue.model.EventSeat;
import com.campuscue.model.EventSeatHold;
import com.campuscue.model.EventSeatingConfig;
import com.campuscue.model.RegistrationSeat;
import com.campuscue.repository.EventRepository;
import com.campuscue.repository.EventSeatHoldRepository;
import com.campuscue.repository.EventSeatRepository;
import com.campuscue.repository.EventSeatingConfigRepository;
import com.campuscue.repository.RegistrationSeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SeatingService {

    private static final int HOLD_MINUTES = 5;

    private final EventRepository eventRepository;
    private final EventSeatRepository seatRepository;
    private final EventSeatHoldRepository holdRepository;
    private final EventSeatingConfigRepository configRepository;
    private final RegistrationSeatRepository registrationSeatRepository;

    public SeatingService(
            EventRepository eventRepository,
            EventSeatRepository seatRepository,
            EventSeatHoldRepository holdRepository,
            EventSeatingConfigRepository configRepository,
            RegistrationSeatRepository registrationSeatRepository) {

        this.eventRepository = eventRepository;
        this.seatRepository = seatRepository;
        this.holdRepository = holdRepository;
        this.configRepository = configRepository;
        this.registrationSeatRepository =
                registrationSeatRepository;
    }

    @Transactional
    public EventSeatingConfig configureSeating(
            Integer eventId,
            SeatingConfigRequest request,
            String facultyId) {

        Event event =
                eventRepository.findById(eventId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Event not found."
                                ));

        if (request == null ||
                request.getLayoutType() == null ||
                request.getLayoutType().isBlank()) {

            throw new IllegalArgumentException(
                    "Layout type is required."
            );
        }

        String layout =
                request.getLayoutType()
                        .trim()
                        .toUpperCase();

        Set<String> allowed =
                Set.of(
                        "TRADITIONAL",
                        "ROUND_TABLE",
                        "HORSE_SHOE",
                        "GROUP_PODS",
                        "PAIR_PODS",
                        "THEATRE",
                        "CLASSROOM",
                        "HERRINGBONE",
                        "CUSTOM"
                );

        if (!allowed.contains(layout)) {
            throw new IllegalArgumentException(
                    "Unsupported seating layout."
            );
        }

        int seatCount =
                event.getTotalSeats();

        int rows =
                request.getRowsCount() == null ||
                        request.getRowsCount() <= 0
                        ? calculateRows(seatCount)
                        : request.getRowsCount();

        int columns =
                request.getColumnsCount() == null ||
                        request.getColumnsCount() <= 0
                        ? calculateColumns(
                                seatCount,
                                rows
                        )
                        : request.getColumnsCount();

        if (rows * columns < seatCount) {
            throw new IllegalArgumentException(
                    "Rows × columns must be at least the event seat count."
            );
        }

        boolean rearLock =
                Boolean.TRUE.equals(
                        request.getRearLockEnabled()
                );

        int rearLockPercent =
                request.getRearLockStartPercent() == null
                        ? 80
                        : request.getRearLockStartPercent();

        if (rearLockPercent < 1 ||
                rearLockPercent > 100) {

            throw new IllegalArgumentException(
                    "Rear-row lock percentage must be between 1 and 100."
            );
        }

        seatRepository.deleteByEventId(eventId);
        configRepository.deleteById(eventId);

        EventSeatingConfig config =
                new EventSeatingConfig();

        config.setEventId(eventId);
        config.setLayoutType(layout);
        config.setRowsCount(rows);
        config.setColumnsCount(columns);
        config.setSeatCount(seatCount);
        config.setRearLockEnabled(rearLock);
        config.setRearLockStartPercent(
                rearLockPercent
        );
        config.setConfiguredByFacultyId(
                facultyId
        );
        config.setUpdatedAt(
                LocalDateTime.now()
        );

        EventSeatingConfig savedConfig =
                configRepository.save(config);

        List<EventSeat> generated =
                generateSeats(
                        eventId,
                        seatCount,
                        rows,
                        columns,
                        layout,
                        rearLock,
                        rearLockPercent
                );

        seatRepository.saveAll(generated);

        return savedConfig;
    }

    private int calculateRows(
            int seatCount) {

        return Math.max(
                1,
                (int) Math.ceil(
                        Math.sqrt(seatCount)
                )
        );
    }

    private int calculateColumns(
            int seatCount,
            int rows) {

        return Math.max(
                1,
                (int) Math.ceil(
                        (double) seatCount /
                                rows
                )
        );
    }

    private List<EventSeat> generateSeats(
            Integer eventId,
            int seatCount,
            int rows,
            int columns,
            String layout,
            boolean rearLock,
            int rearLockPercent) {

        List<EventSeat> seats =
                new ArrayList<>();

        int position = 1;

        for (int row = 1;
             row <= rows && position <= seatCount;
             row++) {

            for (int column = 1;
                 column <= columns &&
                         position <= seatCount;
                 column++) {

                EventSeat seat =
                        new EventSeat();

                seat.setEventId(eventId);

                seat.setRowNumber(row);
                seat.setColumnNumber(column);

                seat.setSeatLabel(
                        createSeatLabel(
                                layout,
                                row,
                                column,
                                position
                        )
                );

                seat.setPositionOrder(
                        position
                );

              seat.setSeatGroup(
        String.valueOf(
                calculateSeatGroup(
                        layout,
                        position,
                        row,
                        column
                )
        )
);

                boolean locked =
                        rearLock &&
                        isRearSeat(
                                row,
                                rows,
                                rearLockPercent
                        );

                seat.setSeatState(
                        locked
                                ? "LOCKED"
                                : "AVAILABLE"
                );

                seats.add(seat);

                position++;
            }
        }

        return seats;
    }

    private String createSeatLabel(
            String layout,
            int row,
            int column,
            int position) {

        if ("ROUND_TABLE".equals(layout)) {
            int table =
                    ((position - 1) / 4) + 1;

            int seat =
                    ((position - 1) % 4) + 1;

            return "T" +
                    table +
                    "-S" +
                    seat;
        }

        return "R" +
                row +
                "-S" +
                column;
    }

    private Integer calculateSeatGroup(
            String layout,
            int position,
            int row,
            int column) {

        return switch (layout) {

            case "ROUND_TABLE" ->
                    ((position - 1) / 4) + 1;

            case "GROUP_PODS" ->
                    ((position - 1) / 4) + 1;

            case "PAIR_PODS" ->
                    ((position - 1) / 2) + 1;

            default ->
                    row;
        };
    }

    private boolean isRearSeat(
            int row,
            int rows,
            int percent) {

        double threshold =
                rows *
                        (percent / 100.0);

        return row >=
                Math.ceil(threshold);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getSeating(
            Integer eventId) {

        cleanupExpiredHolds();

        EventSeatingConfig config =
                configRepository.findById(eventId)
                        .orElse(null);

        List<EventSeat> seats =
                seatRepository
                        .findByEventIdOrderByPositionOrderAsc(
                                eventId
                        );

        LocalDateTime now =
                LocalDateTime.now();

        List<EventSeatHold> activeHolds =
                holdRepository
                        .findByEventIdAndExpiresAtAfter(
                                eventId,
                                now
                        );

        Map<Integer, EventSeatHold> holdBySeat =
                activeHolds.stream()
                        .collect(
                                Collectors.toMap(
                                        EventSeatHold::getSeatId,
                                        h -> h,
                                        (a, b) -> a
                                )
                        );

        List<Map<String, Object>> result =
                new ArrayList<>();

        for (EventSeat seat : seats) {

            String state =
                    seat.getSeatState();

            EventSeatHold hold =
                    holdBySeat.get(
                            seat.getSeatId()
                    );

            if (hold != null) {
                state =
                        "TEMPORARILY_HELD";
            }

            Map<String, Object> item =
                    new LinkedHashMap<>();

            item.put(
                    "seatId",
                    seat.getSeatId()
            );

            item.put(
                    "seatLabel",
                    seat.getSeatLabel()
            );

            item.put(
                    "rowNumber",
                    seat.getRowNumber()
            );

            item.put(
                    "columnNumber",
                    seat.getColumnNumber()
            );

            item.put(
                    "seatGroup",
                    seat.getSeatGroup()
            );

            item.put(
                    "positionOrder",
                    seat.getPositionOrder()
            );

            item.put(
                    "seatState",
                    state
            );

            if (hold != null) {
                item.put(
                        "holdExpiresAt",
                        hold.getExpiresAt()
                );
            }

            result.add(item);
        }

        Map<String, Object> response =
                new LinkedHashMap<>();

        response.put(
                "config",
                config
        );

        response.put(
                "seats",
                result
        );

        return response;
    }

    @Transactional
    public Map<String, Object> holdSeats(
            Integer eventId,
            Integer studentId,
            List<Integer> requestedSeatIds) {

        cleanupExpiredHolds();

        if (requestedSeatIds == null ||
                requestedSeatIds.isEmpty()) {

            throw new IllegalArgumentException(
                    "Select at least one seat."
            );
        }

        if (requestedSeatIds.size() > 8) {
            throw new IllegalArgumentException(
                    "A group can select at most 8 seats."
            );
        }

        List<Integer> seatIds =
                requestedSeatIds.stream()
                        .filter(Objects::nonNull)
                        .distinct()
                        .toList();

        if (seatIds.size() !=
                requestedSeatIds.size()) {

            throw new IllegalArgumentException(
                    "Duplicate seats were selected."
            );
        }

        List<EventSeat> seats =
                seatRepository
                        .findSelectedSeatsForUpdate(
                                eventId,
                                seatIds
                        );

        if (seats.size() != seatIds.size()) {
            throw new IllegalArgumentException(
                    "One or more selected seats do not belong to this event."
            );
        }

        LocalDateTime now =
                LocalDateTime.now();

        for (EventSeat seat : seats) {

            if ("BOOKED".equals(
                    seat.getSeatState())) {

                throw new IllegalStateException(
                        "Seat " +
                                seat.getSeatLabel() +
                                " is already booked."
                );
            }

            if ("LOCKED".equals(
                    seat.getSeatState())) {

                throw new IllegalStateException(
                        "Seat " +
                                seat.getSeatLabel() +
                                " is locked."
                );
            }

            List<EventSeatHold> holds =
                    holdRepository
                            .findByEventIdAndExpiresAtAfter(
                                    eventId,
                                    now
                            );

            boolean held =
                    holds.stream()
                            .anyMatch(
                                    h ->
                                            h.getSeatId()
                                                    .equals(
                                                            seat.getSeatId()
                                                    ) &&
                                            !h.getStudentId()
                                                    .equals(
                                                            studentId
                                                    )
                            );

            if (held) {
                throw new IllegalStateException(
                        "Seat " +
                                seat.getSeatLabel() +
                                " is temporarily held by another student."
                );
            }
        }

        /*
         * Existing holds belonging to this student for
         * this event are replaced by the new selection.
         */
        List<EventSeatHold> oldHolds =
                holdRepository
                        .findByEventIdAndStudentIdAndExpiresAtAfter(
                                eventId,
                                studentId,
                                now
                        );

        if (!oldHolds.isEmpty()) {
            String oldToken =
                    oldHolds.get(0).getHoldToken();

            holdRepository.deleteByHoldToken(
                    oldToken
            );
        }

        String token =
                UUID.randomUUID()
                        .toString();

        LocalDateTime expires =
                now.plusMinutes(
                        HOLD_MINUTES
                );

        for (EventSeat seat : seats) {

            EventSeatHold hold =
                    new EventSeatHold();

            hold.setEventId(eventId);
            hold.setSeatId(
                    seat.getSeatId()
            );
            hold.setStudentId(studentId);
            hold.setHoldToken(token);
            hold.setExpiresAt(expires);
           // hold.setCreatedAt(now);

            holdRepository.save(hold);
        }

        Map<String, Object> response =
                new LinkedHashMap<>();

        response.put(
                "holdToken",
                token
        );

        response.put(
                "expiresAt",
                expires
        );

        response.put(
                "seatIds",
                seatIds
        );

        return response;
    }

    @Transactional
    public void releaseHold(
            Integer eventId,
            Integer studentId,
            String token) {

        if (token == null ||
                token.isBlank()) {
            return;
        }

        List<EventSeatHold> holds =
                holdRepository
                        .findByHoldToken(token);

        for (EventSeatHold hold : holds) {

            if (!hold.getEventId()
                    .equals(eventId)) {
                continue;
            }

            if (!hold.getStudentId()
                    .equals(studentId)) {
                continue;
            }
        }

        holdRepository.deleteByHoldToken(
                token
        );
    }

    @Transactional
    public List<Integer> assignSeats(
            Integer eventId,
            Integer registrationId,
            Integer studentId,
            int groupSize,
            List<Integer> requestedSeatIds,
            String holdToken) {

        cleanupExpiredHolds();

        List<EventSeat> seats =
                seatRepository.findSeatsForUpdate(
                        eventId
                );

        if (seats.isEmpty()) {
            return List.of();
        }

        List<Integer> chosenIds =
                requestedSeatIds == null
                        ? List.of()
                        : requestedSeatIds.stream()
                                .filter(Objects::nonNull)
                                .distinct()
                                .toList();

        if (!chosenIds.isEmpty()) {

            if (chosenIds.size() !=
                    groupSize) {

                throw new IllegalArgumentException(
                        "The number of selected seats must equal the group size."
                );
            }

            if (holdToken == null ||
                    holdToken.isBlank()) {

                throw new IllegalStateException(
                        "Selected seats must be temporarily held before registration."
                );
            }

            validateHold(
                    eventId,
                    studentId,
                    holdToken,
                    chosenIds
            );

        } else {

            chosenIds =
                    findBestAutomaticAllocation(
                            seats,
                            groupSize
                    );

            if (chosenIds.size() !=
                    groupSize) {

                throw new IllegalStateException(
                        "A suitable group of seats could not be found."
                );
            }
        }

        List<Integer> finalIds =
                chosenIds;

        for (EventSeat seat : seats) {

            if (finalIds.contains(
                    seat.getSeatId())) {

                if ("BOOKED".equals(
                        seat.getSeatState())) {

                    throw new IllegalStateException(
                            "A selected seat was booked by another registration."
                    );
                }

                seat.setSeatState(
                        "BOOKED"
                );
            }
        }

        seatRepository.saveAll(seats);

        if (holdToken != null &&
                !holdToken.isBlank()) {

            holdRepository.deleteByHoldToken(
                    holdToken
            );
        }

        LocalDateTime now =
                LocalDateTime.now();

        for (Integer seatId : finalIds) {

            RegistrationSeat assignment =
                    new RegistrationSeat();

            assignment.setRegistrationId(
                    registrationId
            );

            assignment.setEventId(
                    eventId
            );

            assignment.setSeatId(
                    seatId
            );

            assignment.setAssignedAt(
                    now
            );

            registrationSeatRepository
                    .save(assignment);
        }

        return finalIds;
    }

    private void validateHold(
            Integer eventId,
            Integer studentId,
            String holdToken,
            List<Integer> seatIds) {

        LocalDateTime now =
                LocalDateTime.now();

        List<EventSeatHold> holds =
                holdRepository
                        .findByHoldToken(
                                holdToken
                        );

        Set<Integer> heldSeats =
                holds.stream()
                        .filter(
                                h ->
                                        h.getEventId()
                                                .equals(eventId) &&
                                        h.getStudentId()
                                                .equals(studentId) &&
                                        h.getExpiresAt()
                                                .isAfter(now)
                        )
                        .map(
                                EventSeatHold::getSeatId
                        )
                        .collect(
                                Collectors.toSet()
                        );

        if (!heldSeats.containsAll(
                seatIds
        )) {

            throw new IllegalStateException(
                    "Seat hold expired or is invalid."
            );
        }
    }

    private List<Integer> findBestAutomaticAllocation(
            List<EventSeat> seats,
            int groupSize) {

        List<EventSeat> available =
                seats.stream()
                        .filter(
                                s ->
                                        "AVAILABLE"
                                                .equals(
                                                        s.getSeatState()
                                                )
                        )
                        .toList();

        /*
         * First try contiguous seats in the same row.
         */
        for (int i = 0;
             i <= available.size() - groupSize;
             i++) {

            List<EventSeat> group =
                    available.subList(
                            i,
                            i + groupSize
                    );

            if (sameRowAndAdjacent(
                    group
            )) {

                return group.stream()
                        .map(
                                EventSeat::getSeatId
                        )
                        .toList();
            }
        }

        /*
         * Then try the same pod/table.
         */
        Map<String, List<EventSeat>> byGroup =
        available.stream()
                .filter(
                        s ->
                                s.getSeatGroup()
                                        != null
                )
                .collect(
                        Collectors.groupingBy(
                                EventSeat::getSeatGroup,
                                LinkedHashMap::new,
                                Collectors.toList()
                        )
                );

        for (List<EventSeat> group :
                byGroup.values()) {

            if (group.size() >= groupSize) {

                return group.stream()
                        .limit(groupSize)
                        .map(
                                EventSeat::getSeatId
                        )
                        .toList();
            }
        }

        /*
         * Fair fallback:
         * use front-to-back available seats.
         *
         * This means a large group is not rejected
         * simply because a few front seats are split.
         */
        return available.stream()
                .limit(groupSize)
                .map(
                        EventSeat::getSeatId
                )
                .toList();
    }

    private boolean sameRowAndAdjacent(
            List<EventSeat> seats) {

        if (seats.isEmpty()) {
            return false;
        }

        int row =
                seats.get(0)
                        .getRowNumber();

        for (int i = 1;
             i < seats.size();
             i++) {

            if (!Objects.equals(
                    seats.get(i)
                            .getRowNumber(),
                    row
            )) {
                return false;
            }

            if (seats.get(i)
                    .getColumnNumber() !=
                    seats.get(i - 1)
                            .getColumnNumber() + 1) {

                return false;
            }
        }

        return true;
    }

    @Transactional
    public void releaseRegistrationSeats(
            Integer registrationId) {

        List<RegistrationSeat> assignments =
                registrationSeatRepository
                        .findByRegistrationIdOrderBySeatIdAsc(
                                registrationId
                        );

        if (assignments.isEmpty()) {
            return;
        }

        List<Integer> ids =
                assignments.stream()
                        .map(
                                RegistrationSeat::getSeatId
                        )
                        .toList();

        List<EventSeat> seats =
                seatRepository.findAllById(
                        ids
                );

        for (EventSeat seat : seats) {
            if ("BOOKED".equals(
                    seat.getSeatState())) {

                seat.setSeatState(
                        "AVAILABLE"
                );
            }
        }

        seatRepository.saveAll(
                seats
        );

        registrationSeatRepository
                .deleteByRegistrationId(
                        registrationId
                );
    }

    @Transactional
    public void cleanupExpiredHolds() {

        holdRepository.deleteByExpiresAtBefore(
                LocalDateTime.now()
        );
    }
}