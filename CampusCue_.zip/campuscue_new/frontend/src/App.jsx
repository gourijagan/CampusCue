import { Navigate, Route, Routes } from "react-router-dom";

import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import StudentDashboardPage from "./pages/StudentDashboardPage";
import EventsPage from "./pages/EventsPage";
import EventDetailsPage from "./pages/EventDetailsPage";
import MyRegistrationsPage from "./pages/MyRegistrationsPage";
import FacultyDashboardPage from "./pages/FacultyDashboardPage";
import FacultyProtectedRoute from "./components/FacultyProtectedRoute";
import CreateEventPage from "./pages/CreateEventPage";
import FacultyEventDetailsPage from "./pages/FacultyEventDetailsPage";
import CoordinatorEventEditPage from "./pages/CoordinatorEventEditPage";
import EventImageManagementPage from "./pages/EventImageManagementPage";
import FacultyEventsPage from "./pages/FacultyEventsPage";
import FacultyRequestsPage from "./pages/FacultyRequestsPage";
import FacultySeatingPage from "./pages/FacultySeatingPage";
import SeatingSettingsPage from "./pages/SeatingSettingsPage";

import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={<Navigate to="/login" replace />}
      />
      <Route
  path="/faculty/dashboard"
  element={
    <FacultyProtectedRoute>
      <FacultyDashboardPage />
    </FacultyProtectedRoute>
  }
/>
      <Route
        path="/login"
        element={<LoginPage />}
      />

      <Route
  path="/faculty/create-event"
  element={
    <FacultyProtectedRoute>
      <CreateEventPage />
    </FacultyProtectedRoute>
  }
/>

<Route
  path="/faculty/events/:eventId/seating"
  element={<SeatingSettingsPage />}
/>

<Route
  path="/faculty/events/:eventId"
  element={
    <FacultyProtectedRoute>
      <FacultyEventDetailsPage />
    </FacultyProtectedRoute>
  }
/>
      <Route
  path="/faculty/events"
  element={
    <FacultyProtectedRoute>
      <FacultyEventsPage />
    </FacultyProtectedRoute>
  }
/>
<Route
    path="/faculty/events/:eventId/seating"
    element={
        <FacultySeatingPage />
    }
/>
      <Route
        path="/register"
        element={<RegisterPage />}
      />

      <Route
        path="/student/dashboard"
        element={
          <ProtectedRoute>
            <StudentDashboardPage />
          </ProtectedRoute>
        }
      />
 
  <Route
  path="/faculty/requests"
  element={
    <FacultyProtectedRoute>
      <FacultyRequestsPage />
    </FacultyProtectedRoute>
  }
/>
       <Route
  path="/events/:eventId/coordinator/edit"
  element={
    <ProtectedRoute>
      <CoordinatorEventEditPage />
    </ProtectedRoute>
  }
/>

    <Route
  path="/events/:eventId/coordinator/images"
  element={
    <ProtectedRoute>
      <EventImageManagementPage />
    </ProtectedRoute>
  }
/> 

      <Route
        path="/events"
        element={
          <ProtectedRoute>
            <EventsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/events/:eventId"
        element={
          <ProtectedRoute>
            <EventDetailsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/my-registrations"
        element={
          <ProtectedRoute>
            <MyRegistrationsPage />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default App;