import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function FacultyEventsPage() {
  const navigate = useNavigate();

  const [events, setEvents] = useState([]);
  const [thumbnailMap, setThumbnailMap] = useState({});

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] =
    useState("ALL");

  useEffect(() => {
    loadMyEvents();
  }, []);

  async function loadMyEvents() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        "http://localhost:8080/api/events/faculty/my-events",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not load your events."
        );
      }

      setEvents(data);

      await loadThumbnails(data);
    } catch (error) {
      console.error(
        "Load faculty events error:",
        error
      );

      setError(
        error.message ||
          "Could not load your events."
      );
    } finally {
      setLoading(false);
    }
  }

  async function loadThumbnails(eventList) {
    const thumbnails = {};

    await Promise.all(
      eventList.map(async (event) => {
        try {
          const response = await fetch(
            `http://localhost:8080/api/events/${event.eventId}/images`,
            {
              method: "GET",
              credentials: "include",
            }
          );

          if (!response.ok) {
            return;
          }

          const images = await response.json();

          const thumbnail = images.find(
            (image) =>
              image.imageType === "THUMBNAIL"
          );

          if (thumbnail) {
            thumbnails[event.eventId] =
              thumbnail.imageUrl;
          }
        } catch (error) {
          console.error(
            "Thumbnail loading error:",
            error
          );
        }
      })
    );

    setThumbnailMap(thumbnails);
  }

  const filteredEvents = events.filter(
    (event) => {

      const search =
        searchText.trim().toLowerCase();

      const matchesSearch =
        search === "" ||
        event.title
          ?.toLowerCase()
          .includes(search) ||
        event.venue
          ?.toLowerCase()
          .includes(search);

      const matchesStatus =
        statusFilter === "ALL" ||
        event.status === statusFilter;

      return (
        matchesSearch &&
        matchesStatus
      );
    }
  );

  const activeEvents = events.filter(
    (event) =>
      event.status === "ACTIVE"
  ).length;

  const cancelledEvents = events.filter(
    (event) =>
      event.status === "CANCELLED"
  ).length;

  const completedEvents = events.filter(
    (event) =>
      event.status === "COMPLETED"
  ).length;

  function formatDate(dateString) {
    if (!dateString) {
      return "Not available";
    }

    return new Date(
      `${dateString}T00:00:00`
    ).toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>
            Loading your events...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        <div className="events-page-header">

          <div>
            <h1>
              My Events
            </h1>

            <p className="events-page-subtitle">
              Manage the events created
              by your faculty account.
            </p>
          </div>

          <div className="coordinator-actions">

            <button
              className="back-button"
              onClick={() =>
                navigate("/faculty/dashboard")
              }
            >
              ← Dashboard
            </button>

            <button
              className="register-button"
              onClick={() =>
                navigate(
                  "/faculty/create-event"
                )
              }
            >
              + Create Event
            </button>

          </div>

        </div>

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}

        {/* Statistics */}
        <div className="faculty-event-stat-grid">

          <div className="faculty-event-stat-card">
            <span>
              Total Events
            </span>

            <strong>
              {events.length}
            </strong>
          </div>

          <div className="faculty-event-stat-card">
            <span>
              Active
            </span>

            <strong>
              {activeEvents}
            </strong>
          </div>

          <div className="faculty-event-stat-card">
            <span>
              Completed
            </span>

            <strong>
              {completedEvents}
            </strong>
          </div>

          <div className="faculty-event-stat-card">
            <span>
              Cancelled
            </span>

            <strong>
              {cancelledEvents}
            </strong>
          </div>

        </div>

        {/* Filters */}
        <section className="events-filter-panel">

          <div className="events-filter-row">

            <div className="form-group">

              <label htmlFor="faculty-event-search">
                Search
              </label>

              <input
                id="faculty-event-search"
                type="text"
                value={searchText}
                onChange={(event) =>
                  setSearchText(
                    event.target.value
                  )
                }
                placeholder="Search event or venue..."
              />

            </div>

            <div className="form-group">

              <label htmlFor="faculty-status-filter">
                Status
              </label>

              <select
                id="faculty-status-filter"
                value={statusFilter}
                onChange={(event) =>
                  setStatusFilter(
                    event.target.value
                  )
                }
              >
                <option value="ALL">
                  All
                </option>

                <option value="ACTIVE">
                  Active
                </option>

                <option value="COMPLETED">
                  Completed
                </option>

                <option value="CANCELLED">
                  Cancelled
                </option>

              </select>

            </div>

          </div>

        </section>

        {filteredEvents.length === 0 ? (

          <div className="event-empty-state">

            <h2>
              No events found
            </h2>

            <p>
              There are no events matching
              your current filters.
            </p>

            <button
              className="register-button"
              onClick={() =>
                navigate(
                  "/faculty/create-event"
                )
              }
            >
              Create Your First Event
            </button>

          </div>

        ) : (

          <div className="event-list-grid">

            {filteredEvents.map(
              (event) => {

                const thumbnail =
                  thumbnailMap[
                    event.eventId
                  ];

                return (
                  <article
                    className="event-card"
                    key={event.eventId}
                  >

                    <div className="event-card-thumbnail">

                      {thumbnail ? (

                        <img
                          src={`http://localhost:8080${thumbnail}`}
                          alt={event.title}
                        />

                      ) : (

                        <div className="event-card-thumbnail-placeholder">
                          CAMPUSCUE
                        </div>

                      )}

                    </div>

                    <div className="event-card-body">

                      <div className="event-card-top-row">

                        <span className="event-type-badge">
                          {event.eventType}
                        </span>

                        <span className="event-type-badge">
                          {event.status}
                        </span>

                      </div>

                      <h2>
                        {event.title}
                      </h2>

                      <div className="event-card-info">

                        <div>
                          <strong>
                            Date
                          </strong>

                          <span>
                            {formatDate(
                              event.eventDate
                            )}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Venue
                          </strong>

                          <span>
                            {event.venue}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Seats
                          </strong>

                          <span>
                            {event.availableSeats}
                            {" / "}
                            {event.totalSeats}
                            {" available"}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Deadline
                          </strong>

                          <span>
                            {new Date(
                              event.registrationDeadline
                            ).toLocaleString(
                              "en-IN",
                              {
                                day: "2-digit",
                                month: "short",
                                hour: "2-digit",
                                minute: "2-digit",
                              }
                            )}
                          </span>
                        </div>

                      </div>

                      <div className="faculty-event-actions">

                        <button
                          className="register-button"
                          onClick={() =>
                            navigate(
                              `/faculty/events/${event.eventId}`
                            )
                          }
                        >
                          Manage Event
                        </button>

                        <button
                          className="back-button"
                          onClick={() =>
                            navigate(
                              `/events/${event.eventId}`
                            )
                          }
                        >
                          View Event
                        </button>

                      </div>

                    </div>

                  </article>
                );
              }
            )}

          </div>

        )}

      </div>

    </main>
  );
}

export default FacultyEventsPage;