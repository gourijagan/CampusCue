import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function FacultySeatingPage() {

  const { eventId } =
    useParams();

  const navigate =
    useNavigate();

  const [event, setEvent] =
    useState(null);

  const [form, setForm] =
    useState({
      layoutType:
        "TRADITIONAL",
      rowsCount: 5,
      columnsCount: 10,
      rearLockEnabled:
        false,
      rearLockStartPercent:
        80,
    });

  const [message, setMessage] =
    useState("");

  const [error, setError] =
    useState("");

  const [saving, setSaving] =
    useState(false);

  useEffect(() => {
    loadEvent();
    loadExistingConfig();
  }, [eventId]);

  async function loadEvent() {

    try {

      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}`,
          {
            credentials:
              "include",
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not load event."
        );
      }

      setEvent(data);

    } catch (error) {

      setError(
        error.message
      );
    }
  }

  async function loadExistingConfig() {

    try {

      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}/seating`,
          {
            credentials:
              "include",
          }
        );

      if (!response.ok) {
        return;
      }

      const data =
        await response.json();

      if (data.config) {

        setForm({
          layoutType:
            data.config.layoutType,
          rowsCount:
            data.config.rowsCount,
          columnsCount:
            data.config.columnsCount,
          rearLockEnabled:
            data.config.rearLockEnabled,
          rearLockStartPercent:
            data.config.rearLockStartPercent,
        });
      }

    } catch (error) {

      console.error(error);
    }
  }

  function handleChange(event) {

    const {
      name,
      value,
      type,
      checked,
    } = event.target;

    setForm(
      current => ({
        ...current,
        [name]:
          type === "checkbox"
            ? checked
            : value,
      })
    );
  }

  async function handleSubmit(
    eventObject
  ) {

    eventObject.preventDefault();

    setSaving(true);
    setMessage("");
    setError("");

    try {

      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}/seating/config`,
          {
            method:
              "PUT",
            credentials:
              "include",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                layoutType:
                  form.layoutType,
                rowsCount:
                  Number(
                    form.rowsCount
                  ),
                columnsCount:
                  Number(
                    form.columnsCount
                  ),
                rearLockEnabled:
                  form.rearLockEnabled,
                rearLockStartPercent:
                  Number(
                    form.rearLockStartPercent
                  ),
              }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {

        setError(
          data.message ||
            "Could not save seating."
        );

        return;
      }

      setMessage(
        "Seating configuration saved successfully."
      );

    } catch (error) {

      console.error(error);

      setError(
        "Could not connect to the CampusCue server."
      );

    } finally {

      setSaving(false);
    }
  }

  if (!event) {

    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>
            Loading seating configuration...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        <button
          className="back-button"
          onClick={() =>
            navigate(
              `/faculty/events/${eventId}`
            )
          }
        >
          ← Event
        </button>

        <h1>
          Seating Configuration
        </h1>

        <p>
          {event.title}
        </p>

        <p>
          Total event seats:
          {" "}
          <strong>
            {event.totalSeats}
          </strong>
        </p>

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}

        <form
          className="event-form"
          onSubmit={
            handleSubmit
          }
        >

          <div className="form-group">

            <label>
              Seating Layout
            </label>

            <select
              name="layoutType"
              value={
                form.layoutType
              }
              onChange={
                handleChange
              }
            >

              <option value="TRADITIONAL">
                Traditional
              </option>

              <option value="ROUND_TABLE">
                Round Table
              </option>

              <option value="HORSE_SHOE">
                Horse Shoe
              </option>

              <option value="GROUP_PODS">
                Group Pods
              </option>

              <option value="PAIR_PODS">
                Pair Pods
              </option>

              <option value="THEATRE">
                Theatre
              </option>

              <option value="CLASSROOM">
                Classroom
              </option>

              <option value="HERRINGBONE">
                Herringbone
              </option>

              <option value="CUSTOM">
                Custom / Other
              </option>

            </select>

          </div>

          <div className="form-group">

            <label>
              Rows
            </label>

            <input
              type="number"
              name="rowsCount"
              min="1"
              value={
                form.rowsCount
              }
              onChange={
                handleChange
              }
              required
            />

          </div>

          <div className="form-group">

            <label>
              Columns
            </label>

            <input
              type="number"
              name="columnsCount"
              min="1"
              value={
                form.columnsCount
              }
              onChange={
                handleChange
              }
              required
            />

          </div>

          <div className="form-group">

            <label>

              <input
                type="checkbox"
                name="rearLockEnabled"
                checked={
                  form.rearLockEnabled
                }
                onChange={
                  handleChange
                }
              />

              {" "}
              Enable rear-row locking

            </label>

          </div>

          {form.rearLockEnabled && (
            <div className="form-group">

              <label>
                Rear lock starts at
                {" "}
                {form.rearLockStartPercent}%
                {" "}
                of the room
              </label>

              <input
                type="number"
                name="rearLockStartPercent"
                min="1"
                max="100"
                value={
                  form.rearLockStartPercent
                }
                onChange={
                  handleChange
                }
              />

              <small>
                Example: 80 means the
                last 20% of rows are
                locked for normal
                manual selection.
              </small>

            </div>
          )}

          <button
            className="register-button"
            type="submit"
            disabled={saving}
          >
            {saving
              ? "Saving..."
              : "Save Seating Configuration"}
          </button>

        </form>

      </div>

    </main>
  );
}

export default FacultySeatingPage;