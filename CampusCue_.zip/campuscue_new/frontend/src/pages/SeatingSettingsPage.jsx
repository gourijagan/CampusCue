import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function SeatingSettingsPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const [layoutType, setLayoutType] = useState("CLASSROOM");
  const [rowsCount, setRowsCount] = useState(5);
  const [columnsCount, setColumnsCount] = useState(10);
  const [rearLockEnabled, setRearLockEnabled] = useState(false);
  const [rearLockStartPercent, setRearLockStartPercent] = useState(80);

  const layouts = [
    {
      value: "TRADITIONAL",
      label: "Traditional",
      description: "Normal rows and columns of individual seats."
    },
    {
      value: "ROUND_TABLE",
      label: "Round Table",
      description: "Seats arranged around tables."
    },
    {
      value: "HORSE_SHOE",
      label: "Horse Shoe",
      description: "Seats arranged in a U-shaped layout."
    },
    {
      value: "GROUP_PODS",
      label: "Group Pods",
      description: "Small groups of seats around shared tables."
    },
    {
      value: "PAIR_PODS",
      label: "Pair Pods",
      description: "Seats grouped into pairs."
    },
    {
      value: "THEATRE",
      label: "Theatre",
      description: "Forward-facing rows suitable for presentations."
    },
    {
      value: "CLASSROOM",
      label: "Classroom",
      description: "Forward-facing classroom arrangement."
    },
    {
      value: "HERRINGBONE",
      label: "Herringbone",
      description: "Angled rows facing toward the front."
    },
    {
      value: "CUSTOM",
      label: "Custom",
      description: "Custom arrangement based on rows and columns."
    }
  ];

  useEffect(() => {
    loadData();
  }, [eventId]);

  async function loadData() {
    setLoading(true);
    setError("");

    try {
      const eventResponse = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          credentials: "include"
        }
      );

      if (!eventResponse.ok) {
        throw new Error("Unable to load event.");
      }

      const eventData = await eventResponse.json();
      setEvent(eventData);

      const seatingResponse = await fetch(
        `http://localhost:8080/api/events/${eventId}/seating`,
        {
          credentials: "include"
        }
      );

      if (seatingResponse.ok) {
        const seatingData = await seatingResponse.json();

        const config = seatingData?.config;

        if (config) {
          setLayoutType(
            config.layoutType || "CLASSROOM"
          );

          setRowsCount(
            Number(config.rowsCount || 5)
          );

          setColumnsCount(
            Number(config.columnsCount || 10)
          );

          setRearLockEnabled(
            Boolean(config.rearLockEnabled)
          );

          setRearLockStartPercent(
            Number(
              config.rearLockStartPercent || 80
            )
          );
        }
      }

    } catch (err) {
      setError(
        err.message ||
        "Unable to load seating settings."
      );
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings(event) {
    event.preventDefault();

    setMessage("");
    setError("");

    if (rowsCount < 1 || columnsCount < 1) {
      setError(
        "Rows and columns must both be at least 1."
      );
      return;
    }

    if (
      rearLockStartPercent < 0 ||
      rearLockStartPercent > 100
    ) {
      setError(
        "Rear lock percentage must be between 0 and 100."
      );
      return;
    }

    setSaving(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/seating/config`,
        {
          method: "PUT",
          credentials: "include",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            layoutType,
            rowsCount: Number(rowsCount),
            columnsCount: Number(columnsCount),
            rearLockEnabled,
            rearLockStartPercent:
              Number(rearLockStartPercent)
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
          "Unable to save seating configuration."
        );
      }

      setMessage(
        "Seating configuration saved successfully."
      );

    } catch (err) {
      setError(
        err.message ||
        "Unable to save seating configuration."
      );
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div style={styles.page}>
        <div style={styles.card}>
          <p>Loading seating settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>

      <div style={styles.header}>

        <button
          type="button"
          onClick={() =>
            navigate(`/faculty/events/${eventId}`)
          }
          style={styles.backButton}
        >
          ← Back
        </button>

        <div>
          <h1 style={styles.title}>
            Seat Settings
          </h1>

          {event && (
            <p style={styles.subtitle}>
              {event.title}
            </p>
          )}
        </div>

      </div>

      <form
        onSubmit={saveSettings}
        style={styles.card}
      >

        <h2 style={styles.sectionTitle}>
          Seating Layout
        </h2>

        <p style={styles.helpText}>
          Choose how seats should be arranged for this
          event.
        </p>

        <div style={styles.layoutGrid}>

          {layouts.map((layout) => (

            <button
              key={layout.value}
              type="button"
              onClick={() =>
                setLayoutType(layout.value)
              }
              style={{
                ...styles.layoutCard,
                ...(layoutType === layout.value
                  ? styles.layoutCardSelected
                  : {})
              }}
            >

              <div style={styles.layoutName}>
                {layout.label}
              </div>

              <div style={styles.layoutDescription}>
                {layout.description}
              </div>

            </button>

          ))}

        </div>

        <div style={styles.divider} />

        <h2 style={styles.sectionTitle}>
          Seat Dimensions
        </h2>

        <div style={styles.formGrid}>

          <div>
            <label style={styles.label}>
              Number of Rows
            </label>

            <input
              type="number"
              min="1"
              max="100"
              value={rowsCount}
              onChange={(e) =>
                setRowsCount(e.target.value)
              }
              style={styles.input}
            />
          </div>

          <div>
            <label style={styles.label}>
              Seats per Row
            </label>

            <input
              type="number"
              min="1"
              max="100"
              value={columnsCount}
              onChange={(e) =>
                setColumnsCount(e.target.value)
              }
              style={styles.input}
            />
          </div>

        </div>

        <div style={styles.totalBox}>

          <span>
            Total generated seats
          </span>

          <strong>
            {Number(rowsCount || 0) *
              Number(columnsCount || 0)}
          </strong>

        </div>

        <div style={styles.divider} />

        <h2 style={styles.sectionTitle}>
          Rear Row Management
        </h2>

        <label style={styles.checkboxRow}>

          <input
            type="checkbox"
            checked={rearLockEnabled}
            onChange={(e) =>
              setRearLockEnabled(
                e.target.checked
              )
            }
          />

          <span>
            Enable rear-row locking
          </span>

        </label>

        <p style={styles.helpText}>
          Rear seats remain locked initially so the
          system can preserve them for larger groups
          when required.
        </p>

        {rearLockEnabled && (

          <div style={styles.rearLockBox}>

            <label style={styles.label}>
              Rear lock starts at (%)
            </label>

            <input
              type="number"
              min="0"
              max="100"
              value={rearLockStartPercent}
              onChange={(e) =>
                setRearLockStartPercent(
                  e.target.value
                )
              }
              style={styles.inputSmall}
            />

            <p style={styles.smallText}>
              Example: 80 means the final 20% of the
              seating positions are initially locked.
            </p>

          </div>

        )}

        {message && (
          <div style={styles.success}>
            {message}
          </div>
        )}

        {error && (
          <div style={styles.error}>
            {error}
          </div>
        )}

        <div style={styles.actions}>

          <button
            type="button"
            onClick={() =>
              navigate(`/faculty/events/${eventId}`)
            }
            style={styles.cancelButton}
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={saving}
            style={styles.saveButton}
          >
            {saving
              ? "Saving..."
              : "Save Seating Settings"}
          </button>

        </div>

      </form>

    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f4f6f8",
    padding: "30px",
    boxSizing: "border-box"
  },

  header: {
    maxWidth: "1100px",
    margin: "0 auto 24px",
    display: "flex",
    alignItems: "center",
    gap: "18px"
  },

  backButton: {
  border: "1px solid #d1d5db",
  background: "#ffffff",
  color: "#111827",
  padding: "10px 16px",
  borderRadius: "8px",
  cursor: "pointer",
  fontSize: "14px",
  fontWeight: "600"
},

  title: {
    margin: 0,
    fontSize: "30px"
  },

  subtitle: {
    margin: "5px 0 0",
    color: "#666"
  },

  card: {
    maxWidth: "1100px",
    margin: "0 auto",
    background: "white",
    padding: "30px",
    borderRadius: "14px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.08)"
  },

  sectionTitle: {
    margin: "0 0 8px",
    fontSize: "20px"
  },

  helpText: {
    color: "#666",
    marginTop: "6px",
    marginBottom: "20px"
  },

  layoutGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(210px, 1fr))",
    gap: "14px"
  },

  layoutCard: {
    textAlign: "left",
    padding: "18px",
    background: "#fafafa",
    border: "2px solid #e2e2e2",
    borderRadius: "10px",
    cursor: "pointer"
  },

  layoutCardSelected: {
    border: "2px solid #2563eb",
    background: "#eff6ff"
  },

  layoutName: {
    fontWeight: "700",
    fontSize: "16px",
    marginBottom: "7px"
  },

  layoutDescription: {
    fontSize: "13px",
    color: "#666",
    lineHeight: "1.4"
  },

  divider: {
    height: "1px",
    background: "#e5e7eb",
    margin: "30px 0"
  },

  formGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(auto-fit, minmax(220px, 1fr))",
    gap: "20px",
    maxWidth: "600px"
  },

  label: {
    display: "block",
    fontWeight: "600",
    marginBottom: "8px"
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    padding: "12px",
    border: "1px solid #d1d5db",
    borderRadius: "8px",
    fontSize: "15px"
  },

  inputSmall: {
    width: "180px",
    padding: "12px",
    border: "1px solid #d1d5db",
    borderRadius: "8px",
    fontSize: "15px"
  },

  totalBox: {
    marginTop: "20px",
    padding: "15px 18px",
    background: "#f8fafc",
    borderRadius: "8px",
    display: "flex",
    justifyContent: "space-between",
    maxWidth: "600px"
  },

  checkboxRow: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    fontWeight: "600",
    cursor: "pointer"
  },

  rearLockBox: {
    marginTop: "15px",
    padding: "18px",
    background: "#f8fafc",
    borderRadius: "10px",
    maxWidth: "500px"
  },

  smallText: {
    color: "#666",
    fontSize: "13px"
  },

  success: {
    marginTop: "20px",
    padding: "13px",
    borderRadius: "8px",
    background: "#ecfdf5",
    color: "#166534"
  },

  error: {
    marginTop: "20px",
    padding: "13px",
    borderRadius: "8px",
    background: "#fef2f2",
    color: "#b91c1c"
  },

  actions: {
    marginTop: "30px",
    display: "flex",
    justifyContent: "flex-end",
    gap: "12px"
  },

  cancelButton: {
  padding: "12px 20px",
  border: "1px solid #d1d5db",
  background: "#ffffff",
  color: "#111827",
  borderRadius: "8px",
  cursor: "pointer",
  fontWeight: "600",
  fontSize: "14px"
},

  saveButton: {
    padding: "12px 22px",
    border: "none",
    background: "#2563eb",
    color: "white",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "600"
  }
};

export default SeatingSettingsPage;