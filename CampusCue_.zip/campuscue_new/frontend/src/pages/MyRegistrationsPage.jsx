import {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useNavigate,
} from "react-router-dom";

function MyRegistrationsPage() {
  const navigate = useNavigate();

  const [registrations, setRegistrations] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const [message, setMessage] =
    useState("");

  const [statusFilter, setStatusFilter] =
    useState("ALL");

  const [searchText, setSearchText] =
    useState("");

  const [cancellingId, setCancellingId] =
    useState(null);

  useEffect(() => {
    loadRegistrations();
  }, []);

  // =========================================================
  // LOAD REGISTRATIONS
  // =========================================================

  async function loadRegistrations() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        "http://localhost:8080/api/my-registrations",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not load registrations."
        );
      }

      setRegistrations(
        Array.isArray(data)
          ? data
          : []
      );
    } catch (error) {
      console.error(
        "My registrations error:",
        error
      );

      setError(
        error.message ||
          "Could not load your registrations."
      );
    } finally {
      setLoading(false);
    }
  }

  // =========================================================
  // CANCEL REGISTRATION
  // =========================================================

  async function handleCancel(
    registrationId,
    status
  ) {
    const isWaitlisted =
      status === "WAITLISTED";

    const confirmation =
      window.confirm(
        isWaitlisted
          ? "Remove this registration from the waitlist?"
          : "Cancel this registration? The seats may be given to waiting groups."
      );

    if (!confirmation) {
      return;
    }

    setCancellingId(
      registrationId
    );

    setMessage("");
    setError("");

    try {
      const response =
        await fetch(
          `http://localhost:8080/api/my-registrations/${registrationId}`,
          {
            method: "DELETE",
            credentials: "include",
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not cancel registration."
        );
      }

      setMessage(
        data.message ||
          "Registration cancelled successfully."
      );

      await loadRegistrations();
    } catch (error) {
      console.error(
        "Cancellation error:",
        error
      );

      setError(
        error.message ||
          "Could not cancel registration."
      );
    } finally {
      setCancellingId(null);
    }
  }

  // =========================================================
  // DATE
  // =========================================================

  function formatDate(
    dateString
  ) {
    if (!dateString) {
      return "Not available";
    }

    const date =
      new Date(
        `${dateString}T00:00:00`
      );

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  }

  // =========================================================
  // TIME
  // =========================================================

  function formatTime(
    timeString
  ) {
    if (!timeString) {
      return "";
    }

    const [
      hour,
      minute,
    ] =
      timeString.split(":");

    const date =
      new Date();

    date.setHours(
      Number(hour),
      Number(minute),
      0,
      0
    );

    return date.toLocaleTimeString(
      "en-IN",
      {
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  // =========================================================
  // DATE + TIME
  // =========================================================

  function formatDateTime(
    value
  ) {
    if (!value) {
      return "Not available";
    }

    return new Date(
      value
    ).toLocaleString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  // =========================================================
  // STATUS CLASS
  // =========================================================

  function getStatusClass(
    status
  ) {
    if (
      status ===
      "CONFIRMED"
    ) {
      return "event-label-registered";
    }

    if (
      status ===
      "WAITLISTED"
    ) {
      return "event-label-closing";
    }

    return "event-label-full";
  }

  // =========================================================
  // SEAT DISPLAY
  // =========================================================

  function getRegistrationSeatLabels(
    registration
  ) {
    /*
     * Support several possible backend response
     * formats so the page remains compatible
     * with the existing registration API.
     */

    if (
      Array.isArray(
        registration.seatLabels
      )
    ) {
      return registration.seatLabels;
    }

    if (
      Array.isArray(
        registration.seats
      )
    ) {
      return registration.seats
        .map(
          (seat) =>
            seat.seatLabel ||
            seat.label ||
            seat.seatId
        )
        .filter(Boolean);
    }

    if (
      Array.isArray(
        registration.registrationSeats
      )
    ) {
      return registration.registrationSeats
        .map(
          (seat) =>
            seat.seatLabel ||
            seat.label ||
            seat.seatId
        )
        .filter(Boolean);
    }

    return [];
  }

  // =========================================================
  // STATISTICS
  // =========================================================

  const statistics =
    useMemo(() => {
      const confirmed =
        registrations.filter(
          (item) =>
            item.registrationStatus ===
            "CONFIRMED"
        );

      const waitlisted =
        registrations.filter(
          (item) =>
            item.registrationStatus ===
            "WAITLISTED"
        );

      const cancelled =
        registrations.filter(
          (item) =>
            item.registrationStatus ===
            "CANCELLED"
        );

      const confirmedSeats =
        confirmed.reduce(
          (
            total,
            item
          ) =>
            total +
            Number(
              item.numberOfSeats ||
                0
            ),
          0
        );

      const waitlistedSeats =
        waitlisted.reduce(
          (
            total,
            item
          ) =>
            total +
            Number(
              item.numberOfSeats ||
                0
            ),
          0
        );

      return {
        confirmed:
          confirmed.length,

        waitlisted:
          waitlisted.length,

        cancelled:
          cancelled.length,

        confirmedSeats,

        waitlistedSeats,
      };
    }, [registrations]);

  // =========================================================
  // FILTER
  // =========================================================

  const filteredRegistrations =
    useMemo(() => {
      const search =
        searchText
          .trim()
          .toLowerCase();

      return registrations.filter(
        (registration) => {
          const matchesStatus =
            statusFilter ===
              "ALL" ||
            registration.registrationStatus ===
              statusFilter;

          const matchesSearch =
            search === "" ||
            registration.eventTitle
              ?.toLowerCase()
              .includes(search) ||
            registration.venue
              ?.toLowerCase()
              .includes(search) ||
            String(
              registration.registrationId
            ).includes(search);

          return (
            matchesStatus &&
            matchesSearch
          );
        }
      );
    }, [
      registrations,
      statusFilter,
      searchText,
    ]);

  // =========================================================
  // LOADING
  // =========================================================

  if (loading) {
    return (
      <main className="dashboard-page">

        <div className="dashboard-card">

          <p>
            Loading your registrations...
          </p>

        </div>

      </main>
    );
  }

  // =========================================================
  // PAGE
  // =========================================================

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        {/* ===================================================
            HEADER
        ==================================================== */}

        <div className="events-page-header">

          <div>

            <h1>
              My Registrations
            </h1>

            <p className="events-page-subtitle">
              View your confirmed,
              waitlisted and cancelled
              event registrations.
            </p>

          </div>

          <button
            className="back-button"
            onClick={() =>
              navigate(
                "/student/dashboard"
              )
            }
          >
            ← Dashboard
          </button>

        </div>


        {/* ===================================================
            MESSAGES
        ==================================================== */}

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}


        {/* ===================================================
            STATISTICS
        ==================================================== */}

        <section className="event-section">

          <h2>
            Registration Summary
          </h2>

          <div className="event-details-grid">

            <div>
              <strong>
                Confirmed Groups
              </strong>

              <p>
                {statistics.confirmed}
              </p>
            </div>

            <div>
              <strong>
                Confirmed Seats
              </strong>

              <p>
                {statistics.confirmedSeats}
              </p>
            </div>

            <div>
              <strong>
                Waitlisted Groups
              </strong>

              <p>
                {statistics.waitlisted}
              </p>
            </div>

            <div>
              <strong>
                Waitlisted Seats
              </strong>

              <p>
                {statistics.waitlistedSeats}
              </p>
            </div>

            <div>
              <strong>
                Cancelled Groups
              </strong>

              <p>
                {statistics.cancelled}
              </p>
            </div>

          </div>

        </section>


        {/* ===================================================
            FILTERS
        ==================================================== */}

        <section className="events-filter-panel">

          <div className="events-search-box">

            <label htmlFor="registration-search">
              Search Registrations
            </label>

            <input
              id="registration-search"
              type="text"
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
              placeholder="Search event, venue or registration ID..."
            />

          </div>

          <div className="events-filter-row">

            <div className="form-group">

              <label htmlFor="registration-status">
                Status
              </label>

              <select
                id="registration-status"
                value={statusFilter}
                onChange={(event) =>
                  setStatusFilter(
                    event.target.value
                  )
                }
              >

                <option value="ALL">
                  All
                </option>

                <option value="CONFIRMED">
                  Confirmed
                </option>

                <option value="WAITLISTED">
                  Waitlisted
                </option>

                <option value="CANCELLED">
                  Cancelled
                </option>

              </select>

            </div>

          </div>

        </section>


        {/* ===================================================
            EMPTY STATE
        ==================================================== */}

        {filteredRegistrations.length ===
        0 ? (

          <section className="event-empty-state">

            <h2>
              No registrations found
            </h2>

            <p>
              You don't have any
              registrations matching
              the selected filters.
            </p>

            <button
              className="register-button"
              onClick={() => {
                setStatusFilter(
                  "ALL"
                );

                setSearchText("");
              }}
            >
              Clear Filters
            </button>

          </section>

        ) : (

          <div className="event-list-grid">

            {filteredRegistrations.map(
              (
                registration
              ) => {

                const status =
                  registration.registrationStatus;

                const canCancel =
                  status ===
                    "CONFIRMED" ||
                  status ===
                    "WAITLISTED";

                const seatLabels =
                  getRegistrationSeatLabels(
                    registration
                  );

                return (
                  <article
                    className="event-card"
                    key={
                      registration.registrationId
                    }
                  >

                    <div className="event-card-body">

                      {/* ===============================
                          TOP ROW
                      ================================ */}

                      <div className="event-card-top-row">

                        <span
                          className={`event-type-badge ${getStatusClass(
                            status
                          )}`}
                        >
                          {status}
                        </span>

                        <span className="registered-badge">

                          {
                            registration.numberOfSeats
                          }{" "}

                          {
                            registration.numberOfSeats ===
                            1
                              ? "seat"
                              : "seats"
                          }

                        </span>

                      </div>


                      {/* ===============================
                          EVENT TITLE
                      ================================ */}

                      <h2>
                        {
                          registration.eventTitle
                        }
                      </h2>


                      {/* ===============================
                          EVENT INFORMATION
                      ================================ */}

                      <div className="event-card-info">

                        <div>

                          <strong>
                            Registration ID
                          </strong>

                          <span>
                            {
                              registration.registrationId
                            }
                          </span>

                        </div>

                        <div>

                          <strong>
                            Date
                          </strong>

                          <span>
                            {formatDate(
                              registration.eventDate
                            )}
                          </span>

                        </div>

                        <div>

                          <strong>
                            Time
                          </strong>

                          <span>

                            {formatTime(
                              registration.startTime
                            )}

                            {" - "}

                            {formatTime(
                              registration.endTime
                            )}

                          </span>

                        </div>

                        <div>

                          <strong>
                            Venue
                          </strong>

                          <span>
                            {
                              registration.venue
                            }
                          </span>

                        </div>

                        <div>

                          <strong>
                            Registered At
                          </strong>

                          <span>
                            {formatDateTime(
                              registration.registeredAt
                            )}
                          </span>

                        </div>

                      </div>


                      {/* ===============================
                          ASSIGNED SEATS
                      ================================ */}

                      {status ===
                        "CONFIRMED" && (

                        <section
                          className="event-section"
                          style={{
                            marginTop:
                              "20px",
                          }}
                        >

                          <h3>
                            Assigned Seats
                          </h3>

                          {seatLabels.length >
                          0 ? (

                            <div
                              style={{
                                display:
                                  "flex",
                                gap:
                                  "8px",
                                flexWrap:
                                  "wrap",
                              }}
                            >

                              {seatLabels.map(
                                (
                                  label,
                                  index
                                ) => (

                                  <span
                                    key={`${label}-${index}`}
                                    style={{
                                      display:
                                        "inline-block",
                                      padding:
                                        "8px 12px",
                                      borderRadius:
                                        "8px",
                                      background:
                                        "#2563eb",
                                      color:
                                        "white",
                                      fontWeight:
                                        "700",
                                    }}
                                  >
                                    {label}
                                  </span>

                                )
                              )}

                            </div>

                          ) : (

                            <p>
                              Seat information
                              will appear here
                              once seat assignments
                              are returned by the
                              server.
                            </p>

                          )}

                        </section>

                      )}


                      {/* ===============================
                          PARTICIPANTS
                      ================================ */}

                      <section className="event-section">

                        <h3>
                          Participants
                        </h3>

                        {Array.isArray(
                          registration.participants
                        ) &&
                        registration
                          .participants
                          .length >
                          0 ? (

                          <div className="coordinator-list">

                            {registration.participants.map(
                              (
                                participant
                              ) => (

                                <div
                                  className="coordinator-card"
                                  key={
                                    participant.studentId
                                  }
                                >

                                  <p>

                                    <strong>
                                      Name:
                                    </strong>

                                    {" "}

                                    {
                                      participant.name
                                    }

                                  </p>

                                  <p>

                                    <strong>
                                      College Email:
                                    </strong>

                                    {" "}

                                    {
                                      participant.email
                                    }

                                  </p>

                                  <p>

                                    <strong>
                                      Student ID:
                                    </strong>

                                    {" "}

                                    {
                                      participant.studentId
                                    }

                                  </p>

                                </div>

                              )
                            )}

                          </div>

                        ) : (

                          <p>
                            Participant
                            information is
                            unavailable.
                          </p>

                        )}

                      </section>


                      {/* ===============================
                          ACTIONS
                      ================================ */}

                      <div className="faculty-event-actions">

                        <button
                          className="register-button"
                          onClick={() =>
                            navigate(
                              `/events/${registration.eventId}`
                            )
                          }
                        >
                          View Event
                        </button>


                        {canCancel && (

                          <button
                            className="back-button"
                            onClick={() =>
                              handleCancel(
                                registration.registrationId,
                                status
                              )
                            }
                            disabled={
                              cancellingId ===
                              registration.registrationId
                            }
                          >

                            {cancellingId ===
                            registration.registrationId
                              ? "Cancelling..."
                              : status ===
                                "WAITLISTED"
                              ? "Leave Waitlist"
                              : "Cancel Registration"}

                          </button>

                        )}

                      </div>

                    </div>

                  </article>
                );
              }
            )}

          </div>

        )}

      </div>

    </main>
  );
}

export default MyRegistrationsPage;