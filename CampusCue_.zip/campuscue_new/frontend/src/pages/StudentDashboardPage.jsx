import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function StudentDashboardPage() {
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function loadCurrentUser() {
      try {
        const response = await fetch(
          "http://localhost:8080/api/auth/me",
          {
            method: "GET",
            credentials: "include",
          }
        );

        const data = await response.json();

        if (!response.ok) {
          navigate("/login");
          return;
        }

        if (data.userType !== "STUDENT") {
          navigate("/login");
          return;
        }

        setUser(data);
      } catch (error) {
        console.error("Could not load current user:", error);
        setMessage("Could not connect to the CampusCue server.");
      } finally {
        setLoading(false);
      }
    }

    loadCurrentUser();
  }, [navigate]);

  async function handleLogout() {
    try {
      await fetch(
        "http://localhost:8080/api/auth/logout",
        {
          method: "POST",
          credentials: "include",
        }
      );
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      navigate("/login");
    }
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Loading your dashboard...</p>
        </div>
      </main>
    );
  }

  if (!user) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>{message || "Unable to load your account."}</p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-header">
        <div>
          <p className="dashboard-label">STUDENT DASHBOARD</p>

          <h1>
            Welcome, {user.name}
          </h1>

          <p className="dashboard-email">
            {user.email}
          </p>
        </div>

        <button
          className="logout-button"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>

      <section className="dashboard-grid">
        <div className="dashboard-card">
          <h2>Upcoming Events</h2>
          <p>
            Discover campus events and register before
            the deadline.
          </p>

          <button
            className="dashboard-action"
            onClick={() => navigate("/events")}
          >
            Browse Events
          </button>
        </div>

        <div className="dashboard-card">
          <h2>My Registrations</h2>
          <p>
            View the events you have registered for.
          </p>

          <button
            className="dashboard-action"
            onClick={() => navigate("/my-registrations")}
          >
            View Registrations
          </button>
        </div>

        <div className="dashboard-card">
          <h2>My Account</h2>

          <div className="account-details">
            <p>
              <strong>Name:</strong> {user.name}
            </p>

            <p>
              <strong>Email:</strong> {user.email}
            </p>

            <p>
              <strong>Student ID:</strong> {user.userId}
            </p>

            <p>
              <strong>Account Type:</strong> {user.userType}
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default StudentDashboardPage;