import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function EventDetailsPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [numberOfSeats, setNumberOfSeats] = useState(1);

  const [participantEmails, setParticipantEmails] =
    useState([]);

  const [registering, setRegistering] =
    useState(false);

  const [message, setMessage] = useState("");

  const [isCoordinator, setIsCoordinator] =
    useState(false);

  const [coordinatorChecking, setCoordinatorChecking] =
    useState(true);

  // =========================================================
  // SEATING
  // =========================================================

  const [seating, setSeating] = useState(null);

  const [seatingLoading, setSeatingLoading] =
    useState(true);

  const [selectedSeatIds, setSelectedSeatIds] =
    useState([]);

  const [holdToken, setHoldToken] =
    useState("");

  const [holdExpiresAt, setHoldExpiresAt] =
    useState(null);

  const [holdingSeats, setHoldingSeats] =
    useState(false);

  const [seatMessage, setSeatMessage] =
    useState("");

  const [seatError, setSeatError] =
    useState("");

  const [holdCountdown, setHoldCountdown] =
    useState("");

  useEffect(() => {
    loadEvent();
    checkCoordinatorStatus();
    loadSeating();
  }, [eventId]);

  // =========================================================
  // LOAD EVENT
  // =========================================================

  async function loadEvent() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        throw new Error(
          "Could not load event."
        );
      }

      const data = await response.json();

      setEvent(data);
    } catch (error) {
      console.error(
        "Load event error:",
        error
      );

      setError(
        "Could not load the event details."
      );
    } finally {
      setLoading(false);
    }
  }

  // =========================================================
  // LOAD SEATING
  // =========================================================

  async function loadSeating() {
    setSeatingLoading(true);
    setSeatError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/seating`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        /*
         * Seating is optional.
         * The event can still be registered for
         * without a configured seat map.
         */
        setSeating(null);
        return;
      }

      const data = await response.json();

      const config =
        data?.config ||
        data?.seatingConfig ||
        null;

      const rawSeats =
        data?.seats ||
        data?.eventSeats ||
        data?.seatMap ||
        [];

      const seats = Array.isArray(rawSeats)
        ? rawSeats
        : [];

      setSeating({
        config,
        seats,
      });
    } catch (error) {
      console.error(
        "Load seating error:",
        error
      );

      setSeating(null);
    } finally {
      setSeatingLoading(false);
    }
  }

  // =========================================================
  // COORDINATOR STATUS
  // =========================================================

  async function checkCoordinatorStatus() {
    setCoordinatorChecking(true);

    try {
      const response = await fetch(
        "http://localhost:8080/api/events/coordinator-events",
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        setIsCoordinator(false);
        return;
      }

      const events =
        await response.json();

      const coordinatorForThisEvent =
        events.some(
          (coordinatorEvent) =>
            Number(
              coordinatorEvent.eventId
            ) === Number(eventId)
        );

      setIsCoordinator(
        coordinatorForThisEvent
      );
    } catch (error) {
      console.error(
        "Coordinator status check error:",
        error
      );

      setIsCoordinator(false);
    } finally {
      setCoordinatorChecking(false);
    }
  }

  // =========================================================
  // NUMBER OF SEATS
  // =========================================================

  function handleSeatCountChange(
    eventObject
  ) {
    const seats =
      Number(eventObject.target.value);

    setNumberOfSeats(seats);

    setParticipantEmails(
      Array.from(
        {
          length: Math.max(
            0,
            seats - 1
          ),
        },
        (_, index) =>
          participantEmails[index] || ""
      )
    );

    /*
     * If the number of required seats changes,
     * clear the previous selection/hold.
     */
    if (
      selectedSeatIds.length > 0 ||
      holdToken
    ) {
      releaseCurrentHold();
    }

    setSelectedSeatIds([]);
    setHoldToken("");
    setHoldExpiresAt(null);

    setMessage("");
    setSeatMessage("");
    setSeatError("");
  }

  // =========================================================
  // PARTICIPANT EMAIL
  // =========================================================

  function handleParticipantEmailChange(
    index,
    value
  ) {
    setParticipantEmails(
      (current) => {
        const updated = [...current];

        updated[index] = value;

        return updated;
      }
    );
  }

  // =========================================================
  // SEAT HELPERS
  // =========================================================

  function getSeats() {
    if (!seating) {
      return [];
    }

    return Array.isArray(seating.seats)
      ? seating.seats
      : [];
  }

  function isSeatBooked(seat) {
    return (
      String(seat.seatState || "")
        .toUpperCase() === "BOOKED"
    );
  }

  function isSeatLocked(seat) {
    return (
      String(seat.seatState || "")
        .toUpperCase() === "LOCKED"
    );
  }

  function isSeatHeld(seat) {
    const state =
      String(
        seat.seatState || ""
      ).toUpperCase();

    return (
      state === "TEMPORARILY_HELD" ||
      state === "HELD"
    );
  }

  function isSeatAvailable(seat) {
    const state =
      String(
        seat.seatState || ""
      ).toUpperCase();

    return state === "AVAILABLE";
  }

  function isSeatSelected(seatId) {
    return selectedSeatIds.includes(
      Number(seatId)
    );
  }

  function getSeatClassName(seat) {
    const seatId =
      Number(seat.seatId);

    if (isSeatSelected(seatId)) {
      return "campuscue-seat selected";
    }

    if (isSeatBooked(seat)) {
      return "campuscue-seat booked";
    }

    if (isSeatLocked(seat)) {
      return "campuscue-seat locked";
    }

    if (isSeatHeld(seat)) {
      return "campuscue-seat held";
    }

    return "campuscue-seat available";
  }

  // =========================================================
  // SELECT SEAT
  // =========================================================

  function handleSeatClick(seat) {
    const seatId =
      Number(seat.seatId);

    if (
      isSeatBooked(seat) ||
      isSeatLocked(seat) ||
      isSeatHeld(seat)
    ) {
      return;
    }

    if (!isSeatAvailable(seat)) {
      return;
    }

    setSeatError("");
    setSeatMessage("");

    setSelectedSeatIds(
      (current) => {
        if (current.includes(seatId)) {
          return current.filter(
            (id) => id !== seatId
          );
        }

        if (
          current.length >= numberOfSeats
        ) {
          setSeatError(
            `Please select exactly ${numberOfSeats} seat${
              numberOfSeats === 1
                ? ""
                : "s"
            }.`
          );

          return current;
        }

        return [...current, seatId];
      }
    );
  }

  // =========================================================
  // HOLD SELECTED SEATS
  // =========================================================

  async function holdSelectedSeats() {
    setSeatError("");
    setSeatMessage("");

    if (
      selectedSeatIds.length !==
      numberOfSeats
    ) {
      setSeatError(
        `Please select exactly ${numberOfSeats} seat${
          numberOfSeats === 1
            ? ""
            : "s"
        } before continuing.`
      );

      return;
    }

    setHoldingSeats(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/seating/hold`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            seatIds: selectedSeatIds,
          }),
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not temporarily hold the selected seats."
        );
      }

      const result =
        data?.data || data;

      const token =
        result?.holdToken ||
        data?.holdToken ||
        "";

      const expires =
        result?.expiresAt ||
        data?.expiresAt ||
        null;

      if (!token) {
        throw new Error(
          "The server did not return a seat hold token."
        );
      }

      setHoldToken(token);
      setHoldExpiresAt(expires);

      setSeatMessage(
        "Your selected seats are temporarily held. Complete registration before the hold expires."
      );

      await loadSeating();
    } catch (error) {
      console.error(
        "Seat hold error:",
        error
      );

      setSeatError(
        error.message ||
          "Could not hold the selected seats."
      );
    } finally {
      setHoldingSeats(false);
    }
  }

  // =========================================================
  // RELEASE CURRENT HOLD
  // =========================================================

  async function releaseCurrentHold() {
    if (!holdToken) {
      return;
    }

    try {
      await fetch(
        `http://localhost:8080/api/events/${eventId}/seating/holds/${encodeURIComponent(
          holdToken
        )}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );
    } catch (error) {
      console.error(
        "Release hold error:",
        error
      );
    }

    setHoldToken("");
    setHoldExpiresAt(null);
  }

  // =========================================================
  // HOLD COUNTDOWN
  // =========================================================

  useEffect(() => {
    if (!holdExpiresAt) {
      setHoldCountdown("");
      return;
    }

    function updateCountdown() {
      const expiry =
        new Date(
          holdExpiresAt
        ).getTime();

      const now =
        Date.now();

      const remaining =
        expiry - now;

      if (remaining <= 0) {
        setHoldCountdown(
          "Expired"
        );

        setHoldToken("");
        setHoldExpiresAt(null);
        setSelectedSeatIds([]);

        loadSeating();

        return;
      }

      const totalSeconds =
        Math.floor(
          remaining / 1000
        );

      const minutes =
        Math.floor(
          totalSeconds / 60
        );

      const seconds =
        totalSeconds % 60;

      setHoldCountdown(
        `${minutes}:${String(
          seconds
        ).padStart(2, "0")}`
      );
    }

    updateCountdown();

    const interval =
      setInterval(
        updateCountdown,
        1000
      );

    return () =>
      clearInterval(interval);
  }, [holdExpiresAt]);

  // =========================================================
  // REGISTRATION
  // =========================================================

  async function handleRegistration(
    eventObject
  ) {
    eventObject.preventDefault();

    setMessage("");
    setSeatError("");

    /*
     * If seating has been configured and there
     * are enough seats available, require the
     * student to select seats.
     */
    const availableSeats =
      Number(
        event.availableSeats || 0
      );

    const seatingConfigured =
      getSeats().length > 0;

    if (
      seatingConfigured &&
      availableSeats > 0
    ) {
      if (
        selectedSeatIds.length !==
        numberOfSeats
      ) {
        setSeatError(
          `Please select exactly ${numberOfSeats} seat${
            numberOfSeats === 1
              ? ""
              : "s"
          } and hold them before registering.`
        );

        return;
      }

      if (!holdToken) {
        setSeatError(
          "Please click 'Hold Selected Seats' before registering."
        );

        return;
      }
    }

    setRegistering(true);

    try {
      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}/registrations`,
          {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type":
                "application/json",
            },
            body: JSON.stringify({
              numberOfSeats,
              participantEmails,
              seatIds:
                selectedSeatIds,
              holdToken:
                holdToken || null,
            }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        setMessage(
          data.message ||
            "Could not complete registration."
        );

        return;
      }

      if (
        data.registrationStatus ===
        "WAITLISTED"
      ) {
        setMessage(
          "The event is currently full. Your complete group has been placed on the waitlist."
        );
      } else {
        setMessage(
          "Registration successful. Your seats have been assigned."
        );
      }

      setNumberOfSeats(1);
      setParticipantEmails([]);
      setSelectedSeatIds([]);
      setHoldToken("");
      setHoldExpiresAt(null);

      await loadEvent();
      await loadSeating();
    } catch (error) {
      console.error(
        "Registration error:",
        error
      );

      setMessage(
        "Could not connect to the CampusCue server."
      );
    } finally {
      setRegistering(false);
    }
  }

  // =========================================================
  // FORMAT DATE
  // =========================================================

  function formatDate(
    dateString
  ) {
    if (!dateString) {
      return "Not available";
    }

    const date =
      new Date(
        `${dateString}T00:00:00`
      );

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  }

  // =========================================================
  // FORMAT TIME
  // =========================================================

  function formatTime(
    timeString
  ) {
    if (!timeString) {
      return "";
    }

    const [
      hour,
      minute,
    ] = timeString.split(":");

    const date =
      new Date();

    date.setHours(
      Number(hour),
      Number(minute),
      0,
      0
    );

    return date.toLocaleTimeString(
      "en-IN",
      {
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  // =========================================================
  // GROUP SEATS BY ROW
  // =========================================================

  const seatsByRow = useMemo(() => {
    const seats = getSeats();

    const grouped = {};

    seats.forEach((seat) => {
      const row =
        Number(
          seat.rowNumber || 1
        );

      if (!grouped[row]) {
        grouped[row] = [];
      }

      grouped[row].push(seat);
    });

    Object.keys(grouped).forEach(
      (row) => {
        grouped[row].sort(
          (a, b) =>
            Number(
              a.columnNumber || 0
            ) -
            Number(
              b.columnNumber || 0
            )
        );
      }
    );

    return grouped;
  }, [seating]);

  const rowNumbers =
    Object.keys(
      seatsByRow
    ).sort(
      (a, b) =>
        Number(a) -
        Number(b)
    );

  // =========================================================
  // MAXIMUM REGISTRATION SIZE
  // =========================================================

  const maximumSeats =
    Math.min(
      8,
      Math.max(
        1,
        Number(
          event?.totalSeats
        ) || 1
      )
    );

  // =========================================================
  // LOADING
  // =========================================================

  if (
    loading ||
    coordinatorChecking
  ) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>
            Loading event details...
          </p>
        </div>
      </main>
    );
  }

  // =========================================================
  // ERROR
  // =========================================================

  if (
    error ||
    !event
  ) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">

          <button
            className="back-button"
            onClick={() =>
              navigate("/events")
            }
          >
            ← Events
          </button>

          <p className="event-message">
            {error ||
              "Event not found."}
          </p>

        </div>
      </main>
    );
  }

  // =========================================================
  // RENDER
  // =========================================================

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        {/* ===================================================
            BACK
        ==================================================== */}

        <button
          className="back-button"
          onClick={() =>
            navigate("/events")
          }
        >
          ← Events
        </button>


        {/* ===================================================
            EVENT HEADING
        ==================================================== */}

        <h1>
          {event.title}
        </h1>

        <p className="event-status">
          Status:{" "}
          <strong>
            {event.status}
          </strong>
        </p>


        {/* ===================================================
            EVENT DETAILS
        ==================================================== */}

        <section className="event-section">

          <h2>
            Event Details
          </h2>

          <div className="event-details-grid">

            <div>
              <strong>
                Description
              </strong>

              <p>
                {event.description ||
                  "No description provided."}
              </p>
            </div>

            <div>
              <strong>
                Event Type
              </strong>

              <p>
                {event.eventType}
              </p>
            </div>

            <div>
              <strong>
                Venue
              </strong>

              <p>
                {event.venue}
              </p>
            </div>

            <div>
              <strong>
                Date
              </strong>

              <p>
                {formatDate(
                  event.eventDate
                )}
              </p>
            </div>

            <div>
              <strong>
                Time
              </strong>

              <p>
                {formatTime(
                  event.startTime
                )}
                {" - "}
                {formatTime(
                  event.endTime
                )}
              </p>
            </div>

            <div>
              <strong>
                Registration Deadline
              </strong>

              <p>
                {event.registrationDeadline}
              </p>
            </div>

            <div>
              <strong>
                Total Seats
              </strong>

              <p>
                {event.totalSeats}
              </p>
            </div>

            <div>
              <strong>
                Available Seats
              </strong>

              <p>
                {event.availableSeats}
              </p>
            </div>

            <div>
              <strong>
                Eligibility
              </strong>

              <p>
                {event.eligibility ||
                  "No specific eligibility."}
              </p>
            </div>

          </div>

        </section>


        {/* ===================================================
            COORDINATOR CONTROLS
        ==================================================== */}

        {isCoordinator && (
          <section
            className="event-section coordinator-panel"
          >

            <h2>
              Student Coordinator
            </h2>

            <p>
              You are assigned as a
              coordinator for this event.
            </p>

            <div className="coordinator-actions">

              <button
                className="register-button"
                onClick={() =>
                  navigate(
                    `/events/${eventId}/coordinator/edit`
                  )
                }
              >
                Edit Event Details
              </button>

              <button
                className="register-button"
                onClick={() =>
                  navigate(
                    `/events/${eventId}/coordinator/images`
                  )
                }
              >
                Manage Event Images
              </button>

            </div>

          </section>
        )}


        {/* ===================================================
            REGISTRATION
        ==================================================== */}

        <section className="event-section">

          <h2>
            Register for Event
          </h2>

          {event.availableSeats <= 0 && (
            <div
              className="event-message"
              style={{
                marginBottom: "20px",
              }}
            >

              <strong>
                This event is currently full.
              </strong>

              <br />

              You can still submit your
              registration. Your complete
              group will be placed on the
              waitlist and promoted when
              enough seats become available.

            </div>
          )}


          {/* =================================================
              SEAT MAP
          ================================================== */}

          {!seatingLoading &&
            getSeats().length > 0 &&
            event.availableSeats > 0 && (

              <div
                className="event-section"
                style={{
                  marginTop: "20px",
                }}
              >

                <h2>
                  Select Your Seats
                </h2>

                <p>
                  Select{" "}
                  <strong>
                    {numberOfSeats}
                  </strong>{" "}
                  seat
                  {numberOfSeats === 1
                    ? ""
                    : "s"}.
                </p>


                {/* LEGEND */}

                <div
                  style={{
                    display: "flex",
                    gap: "15px",
                    flexWrap: "wrap",
                    marginBottom: "20px",
                    fontSize: "14px",
                  }}
                >

                  <span>
                    🟢 Available
                  </span>

                  <span>
                    🔵 Selected
                  </span>

                  <span>
                    🔴 Booked
                  </span>

                  <span>
                    🟠 Held
                  </span>

                  <span>
                    ⚫ Locked
                  </span>

                </div>


                {/* FRONT */}

                <div
                  style={{
                    textAlign: "center",
                    fontWeight: "700",
                    marginBottom: "20px",
                    padding: "10px",
                    background: "#f1f5f9",
                    borderRadius: "8px",
                  }}
                >
                  FRONT
                </div>


                {/* SEAT MAP */}

                <div
                  style={{
                    overflowX: "auto",
                    padding: "10px",
                  }}
                >

                  {rowNumbers.map(
                    (rowNumber) => (

                      <div
                        key={rowNumber}
                        style={{
                          display: "flex",
                          alignItems:
                            "center",
                          gap: "8px",
                          marginBottom:
                            "10px",
                          minWidth:
                            "max-content",
                        }}
                      >

                        <div
                          style={{
                            width: "35px",
                            fontWeight: "700",
                            textAlign:
                              "center",
                          }}
                        >
                          {rowNumber}
                        </div>

                        {seatsByRow[
                          rowNumber
                        ].map(
                          (seat) => (

                            <button
                              key={
                                seat.seatId
                              }
                              type="button"
                              title={
                                seat.seatLabel
                              }
                              onClick={() =>
                                handleSeatClick(
                                  seat
                                )
                              }
                              className={getSeatClassName(
                                seat
                              )}
                              style={{
                                width: "48px",
                                height: "42px",
                                borderRadius:
                                  "8px",
                                border:
                                  "2px solid #cbd5e1",
                                cursor:
                                  isSeatAvailable(
                                    seat
                                  )
                                    ? "pointer"
                                    : "not-allowed",
                                background:
                                  isSeatSelected(
                                    seat.seatId
                                  )
                                    ? "#2563eb"
                                    : isSeatBooked(
                                        seat
                                      )
                                    ? "#ef4444"
                                    : isSeatLocked(
                                        seat
                                      )
                                    ? "#111827"
                                    : isSeatHeld(
                                        seat
                                      )
                                    ? "#f97316"
                                    : "#22c55e",
                                color:
                                  "white",
                                fontWeight:
                                  "700",
                                fontSize:
                                  "12px",
                              }}
                              disabled={
                                !isSeatAvailable(
                                  seat
                                )
                              }
                            >
                              {seat.seatLabel}
                            </button>

                          )
                        )}

                      </div>

                    )
                  )}

                </div>


                {/* SELECTION SUMMARY */}

                <div
                  style={{
                    marginTop: "20px",
                    padding: "15px",
                    background:
                      "#f8fafc",
                    borderRadius:
                      "10px",
                  }}
                >

                  <strong>
                    Selected Seats:
                  </strong>{" "}

                  {selectedSeatIds.length ===
                  0
                    ? "None"
                    : getSeats()
                        .filter(
                          (seat) =>
                            selectedSeatIds.includes(
                              Number(
                                seat.seatId
                              )
                            )
                        )
                        .map(
                          (seat) =>
                            seat.seatLabel
                        )
                        .join(", ")}

                </div>


                {/* HOLD */}

                <div
                  style={{
                    marginTop: "15px",
                  }}
                >

                  <button
                    type="button"
                    className="register-button"
                    onClick={
                      holdSelectedSeats
                    }
                    disabled={
                      holdingSeats ||
                      selectedSeatIds.length !==
                        numberOfSeats ||
                      Boolean(holdToken)
                    }
                  >
                    {holdingSeats
                      ? "Holding Seats..."
                      : holdToken
                      ? "Seats Held"
                      : "Hold Selected Seats"}
                  </button>

                </div>


                {/* HOLD TIMER */}

                {holdToken && (
                  <div
                    style={{
                      marginTop:
                        "15px",
                      padding:
                        "12px",
                      background:
                        "#eff6ff",
                      borderRadius:
                        "8px",
                      fontWeight:
                        "600",
                    }}
                  >
                    Seats temporarily held.

                    {holdCountdown && (
                      <>
                        {" "}
                        Complete registration
                        within{" "}
                        <strong>
                          {holdCountdown}
                        </strong>
                        .
                      </>
                    )}
                  </div>
                )}


                {seatMessage && (
                  <p
                    className="event-message"
                    style={{
                      marginTop:
                        "15px",
                    }}
                  >
                    {seatMessage}
                  </p>
                )}

                {seatError && (
                  <p
                    className="event-message"
                    style={{
                      marginTop:
                        "15px",
                    }}
                  >
                    {seatError}
                  </p>
                )}

              </div>
            )}


          {seatingLoading && (
            <p>
              Loading seating information...
            </p>
          )}


          {/* =================================================
              REGISTRATION FORM
          ================================================== */}

          <form
            className="event-form"
            onSubmit={
              handleRegistration
            }
          >

            {/* NUMBER OF SEATS */}

            <div className="form-group">

              <label htmlFor="numberOfSeats">
                Number of Seats
              </label>

              <select
                id="numberOfSeats"
                value={numberOfSeats}
                onChange={
                  handleSeatCountChange
                }
              >

                {Array.from(
                  {
                    length:
                      maximumSeats,
                  },
                  (_, index) => (
                    <option
                      key={
                        index + 1
                      }
                      value={
                        index + 1
                      }
                    >
                      {index + 1}
                    </option>
                  )
                )}

              </select>

            </div>


            {/* PARTICIPANT EMAILS */}

            {participantEmails.map(
              (
                email,
                index
              ) => (

                <div
                  className="form-group"
                  key={index}
                >

                  <label
                    htmlFor={`participant-email-${index}`}
                  >
                    Participant{" "}
                    {index + 2}{" "}
                    College Email
                  </label>

                  <input
                    id={`participant-email-${index}`}
                    type="email"
                    value={email}
                    onChange={(
                      eventObject
                    ) =>
                      handleParticipantEmailChange(
                        index,
                        eventObject
                          .target
                          .value
                      )
                    }
                    placeholder="student@jecc.ac.in"
                    required
                  />

                </div>

              )
            )}


            {/* SUBMIT */}

            <button
              className="register-button"
              type="submit"
              disabled={
                registering
              }
            >
              {registering
                ? "Processing..."
                : event.availableSeats <=
                    0
                ? "Join Waitlist"
                : "Register"}
            </button>


            {message && (
              <p className="event-message">
                {message}
              </p>
            )}

          </form>

        </section>

      </div>

    </main>
  );
}

export default EventDetailsPage;