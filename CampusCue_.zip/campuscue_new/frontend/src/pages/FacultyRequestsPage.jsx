import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function FacultyRequestsPage() {
  const navigate = useNavigate();

  const [faculty, setFaculty] = useState(null);
  const [departments, setDepartments] = useState([]);

  const [registrationRequests, setRegistrationRequests] =
    useState([]);

  const [loading, setLoading] = useState(true);
  const [requestsLoading, setRequestsLoading] =
    useState(true);

  const [processingRequestId, setProcessingRequestId] =
    useState(null);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadFaculty();
    loadDepartments();
    loadRegistrationRequests();
  }, []);

  async function loadFaculty() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/auth/me",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (
        !response.ok ||
        data.userType !== "FACULTY"
      ) {
        navigate("/login", {
          replace: true,
        });
        return;
      }

      setFaculty(data);

    } catch (error) {
      console.error(
        "Faculty request page error:",
        error
      );

      setError(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setLoading(false);
    }
  }

  async function loadDepartments() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/departments",
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        return;
      }

      const data = await response.json();

      setDepartments(data);

    } catch (error) {
      console.error(
        "Department loading error:",
        error
      );
    }
  }

  async function loadRegistrationRequests() {
    try {
      setRequestsLoading(true);
      setError("");

      const response = await fetch(
        "http://localhost:8080/api/student-registration/pending",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(
          data.message ||
            "Could not load student registration requests."
        );
        return;
      }

      setRegistrationRequests(
        Array.isArray(data) ? data : []
      );

    } catch (error) {
      console.error(
        "Registration request loading error:",
        error
      );

      setError(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setRequestsLoading(false);
    }
  }

  async function handleApproveRequest(requestId) {
    const confirmed = window.confirm(
      "Are you sure you want to approve this student registration?"
    );

    if (!confirmed) {
      return;
    }

    try {
      setProcessingRequestId(requestId);
      setMessage("");
      setError("");

      const response = await fetch(
        `http://localhost:8080/api/student-registration/${requestId}/approve`,
        {
          method: "POST",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(
          data.message ||
            "Could not approve the registration."
        );
        return;
      }

      setMessage(
        data.message ||
          "Student registration approved successfully."
      );

      await loadRegistrationRequests();

    } catch (error) {
      console.error(
        "Registration approval error:",
        error
      );

      setError(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setProcessingRequestId(null);
    }
  }

  async function handleRejectRequest(requestId) {
    const confirmed = window.confirm(
      "Are you sure you want to reject this student registration?"
    );

    if (!confirmed) {
      return;
    }

    try {
      setProcessingRequestId(requestId);
      setMessage("");
      setError("");

      const response = await fetch(
        `http://localhost:8080/api/student-registration/${requestId}/reject`,
        {
          method: "POST",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(
          data.message ||
            "Could not reject the registration."
        );
        return;
      }

      setMessage(
        data.message ||
          "Student registration rejected."
      );

      await loadRegistrationRequests();

    } catch (error) {
      console.error(
        "Registration rejection error:",
        error
      );

      setError(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setProcessingRequestId(null);
    }
  }

  function getRequestDepartmentName(request) {
    const department =
      departments.find(
        (item) =>
          Number(
            item.departmentId
          ) ===
          Number(request.departmentId)
      );

    return department
      ? department.departmentName
      : "Department";
  }

  function formatDateTime(dateTimeString) {
    if (!dateTimeString) {
      return "Not available";
    }

    const date = new Date(
      dateTimeString
    );

    return date.toLocaleString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  async function handleLogout() {
    try {
      await fetch(
        "http://localhost:8080/api/auth/logout",
        {
          method: "POST",
          credentials: "include",
        }
      );
    } catch (error) {
      console.error(
        "Logout error:",
        error
      );
    }

    navigate("/login", {
      replace: true,
    });
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>
            Loading requests...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        {/* =====================================================
            HEADER
        ===================================================== */}

        <div className="events-page-header">

          <div>

            <h1>
              Student Registration Requests
            </h1>

            <p className="events-page-subtitle">
              Review and manage student
              registration requests.
            </p>

          </div>

          <div
            style={{
              display: "flex",
              gap: "10px",
              alignItems: "center",
            }}
          >

            <button
              className="back-button"
              onClick={() =>
                navigate("/faculty/dashboard")
              }
            >
              Back to Dashboard
            </button>

            <button
              className="back-button"
              onClick={handleLogout}
            >
              Logout
            </button>

          </div>

        </div>

        {/* =====================================================
            FACULTY INFO
        ===================================================== */}

        {faculty && (
          <section className="faculty-profile-card">

            <div>

              <span className="faculty-profile-label">
                Reviewing Faculty
              </span>

              <h2>
                {faculty.name}
              </h2>

              <p>
                {faculty.email}
              </p>

            </div>

            <div className="faculty-profile-details">

              <div>
                <strong>
                  Faculty ID
                </strong>

                <span>
                  {faculty.userId}
                </span>
              </div>

              <div>
                <strong>
                  Designation
                </strong>

                <span>
                  {faculty.designation}
                </span>
              </div>

            </div>

          </section>
        )}

        {/* =====================================================
            MESSAGES
        ===================================================== */}

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}

        {/* =====================================================
            REQUEST SUMMARY
        ===================================================== */}

        <section className="faculty-event-section">

          <div className="events-page-header">

            <div>

              <h2>
                Pending Requests
              </h2>

              <p className="events-page-subtitle">
                Students waiting for approval.
              </p>

            </div>

            <strong>
              {registrationRequests.length} pending
            </strong>

          </div>

          {/* ===================================================
              REQUEST LIST
          =================================================== */}

          {requestsLoading ? (

            <p>
              Loading student registration
              requests...
            </p>

          ) : registrationRequests.length === 0 ? (

            <section className="event-empty-state">

              <h2>
                No Pending Requests
              </h2>

              <p>
                There are currently no student
                registration requests waiting
                for approval.
              </p>

            </section>

          ) : (

            <div className="event-list-grid">

              {registrationRequests.map(
                (request) => {

                  const processing =
                    processingRequestId ===
                    request.requestId;

                  return (

                    <article
                      className="event-card"
                      key={request.requestId}
                    >

                      <div className="event-card-body">

                        {/* REQUEST HEADER */}

                        <div className="event-card-top-row">

                          <span className="event-type-badge">
                            PENDING
                          </span>

                          <span className="registered-badge">
                            Request #
                            {request.requestId}
                          </span>

                        </div>

                        {/* STUDENT NAME */}

                        <h2>
                          {request.name}
                        </h2>

                        <p className="event-card-description">
                          Student registration
                          request awaiting
                          faculty approval.
                        </p>

                        {/* STUDENT DETAILS */}

                        <div className="event-card-info">

                          <div>

                            <strong>
                              Registration Number
                            </strong>

                            <span>
                              {request.regNo}
                            </span>

                          </div>

                          <div>

                            <strong>
                              College Email
                            </strong>

                            <span>
                              {request.email}
                            </span>

                          </div>

                          <div>

                            <strong>
                              Department
                            </strong>

                            <span>
                              {getRequestDepartmentName(
                                request
                              )}
                            </span>

                          </div>

                          <div>

                            <strong>
                              Batch
                            </strong>

                            <span>
                              {request.batchStartYear}
                              {" - "}
                              {request.batchEndYear}
                            </span>

                          </div>

                          <div>

                            <strong>
                              Tutor Faculty ID
                            </strong>

                            <span>
                              {request.tutorFacultyId}
                            </span>

                          </div>

                          <div>

                            <strong>
                              Requested At
                            </strong>

                            <span>
                              {formatDateTime(
                                request.requestedAt
                              )}
                            </span>

                          </div>

                        </div>

                        {/* ACTIONS */}

                        <div className="faculty-event-actions">

                          <button
                            className="register-button"
                            onClick={() =>
                              handleApproveRequest(
                                request.requestId
                              )
                            }
                            disabled={processing}
                          >
                            {processing
                              ? "Processing..."
                              : "Approve"}
                          </button>

                          <button
                            className="back-button"
                            onClick={() =>
                              handleRejectRequest(
                                request.requestId
                              )
                            }
                            disabled={processing}
                          >
                            {processing
                              ? "Processing..."
                              : "Reject"}
                          </button>

                        </div>

                      </div>

                    </article>

                  );
                }
              )}

            </div>

          )}

        </section>

      </div>

    </main>
  );
}

export default FacultyRequestsPage;