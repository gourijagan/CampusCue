import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function CoordinatorEventEditPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [venue, setVenue] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [registrationDeadline, setRegistrationDeadline] = useState("");
  const [eligibility, setEligibility] = useState("");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadEvent();
  }, [eventId]);

  async function loadEvent() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not load event.");
      }

      setEvent(data);

      setTitle(data.title || "");
      setDescription(data.description || "");
      setVenue(data.venue || "");
      setEventDate(data.eventDate || "");
      setStartTime(data.startTime || "");
      setEndTime(data.endTime || "");

      /*
       * Backend returns LocalDateTime.
       * HTML datetime-local needs:
       * YYYY-MM-DDTHH:MM
       */
      setRegistrationDeadline(
        data.registrationDeadline
          ? data.registrationDeadline.slice(0, 16)
          : ""
      );

      setEligibility(data.eligibility || "");

    } catch (error) {
      console.error("Load event error:", error);
      setError(
        error.message || "Could not load event details."
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(eventObject) {
    eventObject.preventDefault();

    setSaving(true);
    setMessage("");
    setError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          method: "PUT",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            title,
            description,
            venue,
            eventDate,
            startTime,
            endTime,
            registrationDeadline,
            eligibility,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not update event."
        );
      }

      setMessage("Event details updated successfully.");

      setTimeout(() => {
  navigate(`/events/${eventId}`);
}, 800);

    } catch (error) {
      console.error("Update event error:", error);

      setError(
        error.message ||
          "Could not connect to the CampusCue server."
      );

    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Loading event details...</p>
        </div>
      </main>
    );
  }

  if (error && !event) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">

          <button
            className="back-button"
            onClick={() =>
              navigate(`/events/${eventId}`)
            }
          >
            ← Back to Event
          </button>

          <p className="event-message">
            {error}
          </p>

        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-card">

        <button
          className="back-button"
          onClick={() =>
            navigate(`/events/${eventId}`)
          }
        >
          ← Back to Event
        </button>

        <h1>Edit Event Details</h1>

        {event && (
          <p>
            You are editing:
            <strong> {event.title}</strong>
          </p>
        )}

        <form
          className="event-form"
          onSubmit={handleSubmit}
        >

          <div className="form-group">
            <label htmlFor="title">
              Event Title
            </label>

            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) =>
                setTitle(e.target.value)
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">
              Description
            </label>

            <textarea
              id="description"
              value={description}
              onChange={(e) =>
                setDescription(e.target.value)
              }
              rows="5"
            />
          </div>

          <div className="form-group">
            <label htmlFor="venue">
              Venue
            </label>

            <input
              id="venue"
              type="text"
              value={venue}
              onChange={(e) =>
                setVenue(e.target.value)
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="eventDate">
              Event Date
            </label>

            <input
              id="eventDate"
              type="date"
              value={eventDate}
              onChange={(e) =>
                setEventDate(e.target.value)
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="startTime">
              Start Time
            </label>

            <input
              id="startTime"
              type="time"
              value={startTime}
              onChange={(e) =>
                setStartTime(e.target.value)
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="endTime">
              End Time
            </label>

            <input
              id="endTime"
              type="time"
              value={endTime}
              onChange={(e) =>
                setEndTime(e.target.value)
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="registrationDeadline">
              Registration Deadline
            </label>

            <input
              id="registrationDeadline"
              type="datetime-local"
              value={registrationDeadline}
              onChange={(e) =>
                setRegistrationDeadline(
                  e.target.value
                )
              }
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="eligibility">
              Eligibility
            </label>

            <textarea
              id="eligibility"
              value={eligibility}
              onChange={(e) =>
                setEligibility(e.target.value)
              }
              rows="3"
              placeholder="Example: All verified students"
            />
          </div>

          {error && (
            <p className="event-message">
              {error}
            </p>
          )}

          {message && (
            <p className="event-message">
              {message}
            </p>
          )}

          <button
            className="register-button"
            type="submit"
            disabled={saving}
          >
            {saving
              ? "Saving..."
              : "Save Changes"}
          </button>

        </form>
      </div>
    </main>
  );
}

export default CoordinatorEventEditPage;