import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

function EventsPage() {
  const navigate = useNavigate();

  const [events, setEvents] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [registeredEventIds, setRegisteredEventIds] =
    useState(new Set());

  const [thumbnailMap, setThumbnailMap] = useState({});

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [searchText, setSearchText] = useState("");
  const [eventTypeFilter, setEventTypeFilter] =
    useState("ALL");

  const [departmentFilter, setDepartmentFilter] =
    useState("ALL");

  const [availabilityFilter, setAvailabilityFilter] =
    useState("ALL");

  const [sortOption, setSortOption] =
    useState("DATE");

  useEffect(() => {
    loadPageData();
  }, []);

  async function loadPageData() {
    setLoading(true);
    setError("");

    await Promise.all([
      loadEvents(),
      loadDepartments(),
      loadMyRegistrations(),
    ]);

    setLoading(false);
  }

  async function loadEvents() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/events",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not load events."
        );
      }

      setEvents(data);

      await loadThumbnails(data);

    } catch (error) {
      console.error("Load events error:", error);

      setError(
        error.message ||
          "Could not load events from CampusCue."
      );
    }
  }

  async function loadDepartments() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/departments",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Could not load departments."
        );
      }

      setDepartments(data);

    } catch (error) {
      console.error(
        "Load departments error:",
        error
      );
    }
  }

  async function loadThumbnails(eventList) {
    const thumbnailData = {};

    await Promise.all(
      eventList.map(async (event) => {
        try {
          const response = await fetch(
            `http://localhost:8080/api/events/${event.eventId}/images`,
            {
              method: "GET",
              credentials: "include",
            }
          );

          if (!response.ok) {
            return;
          }

          const images = await response.json();

          const thumbnail = images.find(
            (image) =>
              image.imageType === "THUMBNAIL"
          );

          if (thumbnail) {
            thumbnailData[event.eventId] =
              thumbnail.imageUrl;
          }

        } catch (error) {
          console.error(
            `Thumbnail error for event ${event.eventId}:`,
            error
          );
        }
      })
    );

    setThumbnailMap(thumbnailData);
  }

  async function loadMyRegistrations() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/my-registrations",
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        return;
      }

      const data = await response.json();

      const ids = new Set();

      data.forEach((registration) => {
        if (
          registration.registrationStatus ===
          "CONFIRMED"
        ) {
          ids.add(Number(registration.eventId));
        }
      });

      setRegisteredEventIds(ids);

    } catch (error) {
      console.error(
        "Load registration status error:",
        error
      );
    }
  }

  function getDepartment(event) {
    if (!event.departmentId) {
      return null;
    }

    return departments.find(
      (department) =>
        Number(department.departmentId) ===
        Number(event.departmentId)
    );
  }

  function getDepartmentName(event) {
    const department = getDepartment(event);

    if (!department) {
      return event.eventType === "GENERAL"
        ? "General Campus Event"
        : "Department Event";
    }

    return `${department.departmentCode} - ${department.departmentName}`;
  }

  function getEventDateTime(event) {
    return new Date(
      `${event.eventDate}T${event.startTime}`
    );
  }

  function getDeadline(event) {
    return new Date(
      event.registrationDeadline
    );
  }

  function getDaysUntilDeadline(event) {
    const now = new Date();
    const deadline = getDeadline(event);

    const difference =
      deadline.getTime() - now.getTime();

    return (
      difference /
      (1000 * 60 * 60 * 24)
    );
  }

  function getEventLabel(event) {
    const available = Number(
      event.availableSeats || 0
    );

    const total = Number(
      event.totalSeats || 0
    );

    if (
      registeredEventIds.has(
        Number(event.eventId)
      )
    ) {
      return {
        text: "Registered",
        className:
          "event-label-registered",
      };
    }

    if (available <= 0) {
      return {
        text: "Full",
        className: "event-label-full",
      };
    }

    const daysUntilDeadline =
      getDaysUntilDeadline(event);

    if (
      daysUntilDeadline >= 0 &&
      daysUntilDeadline <= 1
    ) {
      return {
        text: "Closing Today",
        className: "event-label-closing",
      };
    }

    if (
      daysUntilDeadline > 1 &&
      daysUntilDeadline <= 7
    ) {
      return {
        text: "Closing This Week",
        className:
          "event-label-closing-week",
      };
    }

    if (total > 0) {
      const occupancy =
        ((total - available) / total) * 100;

      if (occupancy >= 75) {
        return {
          text: "Filling Fast",
          className:
            "event-label-filling",
        };
      }
    }

    return {
      text: "Plenty of Seats",
      className:
        "event-label-plenty",
    };
  }

  function matchesAvailability(event) {
    const available = Number(
      event.availableSeats || 0
    );

    const total = Number(
      event.totalSeats || 0
    );

    if (availabilityFilter === "ALL") {
      return true;
    }

    if (
      availabilityFilter ===
      "AVAILABLE"
    ) {
      return available > 0;
    }

    if (
      availabilityFilter === "FILLING"
    ) {
      if (total <= 0) {
        return false;
      }

      const occupancy =
        ((total - available) / total) * 100;

      return (
        available > 0 &&
        occupancy >= 75
      );
    }

    if (
      availabilityFilter === "FULL"
    ) {
      return available <= 0;
    }

    if (
      availabilityFilter ===
      "REGISTERED"
    ) {
      return registeredEventIds.has(
        Number(event.eventId)
      );
    }

    return true;
  }

  const filteredEvents = useMemo(() => {
    const search = searchText
      .trim()
      .toLowerCase();

    const filtered = events.filter(
      (event) => {

        const department =
          departments.find(
            (item) =>
              Number(item.departmentId) ===
              Number(event.departmentId)
          );

        const departmentCode =
          department?.departmentCode
            ?.toLowerCase() || "";

        const departmentName =
          department?.departmentName
            ?.toLowerCase() || "";

        const departmentText =
          `${departmentCode} ${departmentName}`;

        /*
         * Search now checks:
         * title
         * description
         * venue
         * eligibility
         * event type
         * department code
         * department name
         */
        const searchableText = [
          event.title,
          event.description,
          event.venue,
          event.eligibility,
          event.eventType,
          departmentText,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        const matchesSearch =
          search === "" ||
          searchableText.includes(search);

        const matchesType =
          eventTypeFilter === "ALL" ||
          event.eventType ===
            eventTypeFilter;

        const matchesDepartment =
          departmentFilter === "ALL" ||
          Number(event.departmentId) ===
            Number(departmentFilter);

        return (
          matchesSearch &&
          matchesType &&
          matchesDepartment &&
          matchesAvailability(event)
        );
      }
    );

    filtered.sort((a, b) => {
      if (sortOption === "DATE") {
        return (
          getEventDateTime(a) -
          getEventDateTime(b)
        );
      }

      if (sortOption === "DEADLINE") {
        return (
          getDeadline(a) -
          getDeadline(b)
        );
      }

      if (sortOption === "SEATS") {
        return (
          Number(b.availableSeats || 0) -
          Number(a.availableSeats || 0)
        );
      }

      if (
        sortOption === "FEWEST_SEATS"
      ) {
        return (
          Number(a.availableSeats || 0) -
          Number(b.availableSeats || 0)
        );
      }

      return 0;
    });

    return filtered;

  }, [
    events,
    departments,
    searchText,
    eventTypeFilter,
    departmentFilter,
    availabilityFilter,
    sortOption,
    registeredEventIds,
  ]);

  function formatDate(dateString) {
    if (!dateString) {
      return "Not available";
    }

    const date = new Date(
      `${dateString}T00:00:00`
    );

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  }

  function formatTime(timeString) {
    if (!timeString) {
      return "";
    }

    const [hour, minute] =
      timeString.split(":");

    const date = new Date();

    date.setHours(
      Number(hour),
      Number(minute),
      0,
      0
    );

    return date.toLocaleTimeString(
      "en-IN",
      {
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  function openEvent(eventId) {
    navigate(`/events/${eventId}`);
  }

  function clearFilters() {
    setSearchText("");
    setEventTypeFilter("ALL");
    setDepartmentFilter("ALL");
    setAvailabilityFilter("ALL");
    setSortOption("DATE");
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Loading events...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        <div className="events-page-header">

          <div>
            <h1>Campus Events</h1>

            <p className="events-page-subtitle">
              Discover upcoming events,
              workshops and activities
              across CampusCue.
            </p>
          </div>

          <button
            className="back-button"
            onClick={() =>
              navigate("/student/dashboard")
            }
          >
            ← Dashboard
          </button>

        </div>

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}

        <section className="events-filter-panel">

          <div className="events-search-box">

            <label htmlFor="event-search">
              Search Events
            </label>

            <input
              id="event-search"
              type="text"
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
              placeholder="Search by title, department, venue or description..."
            />

          </div>

          <div className="events-filter-row">

            <div className="form-group">

              <label htmlFor="event-type-filter">
                Event Type
              </label>

              <select
                id="event-type-filter"
                value={eventTypeFilter}
                onChange={(event) =>
                  setEventTypeFilter(
                    event.target.value
                  )
                }
              >
                <option value="ALL">
                  All Events
                </option>

                <option value="GENERAL">
                  General Events
                </option>

                <option value="DEPARTMENT">
                  Department Events
                </option>
              </select>

            </div>

            <div className="form-group">

              <label htmlFor="department-filter">
                Department
              </label>

              <select
                id="department-filter"
                value={departmentFilter}
                onChange={(event) =>
                  setDepartmentFilter(
                    event.target.value
                  )
                }
              >
                <option value="ALL">
                  All Departments
                </option>

                {departments.map(
                  (department) => (
                    <option
                      key={
                        department.departmentId
                      }
                      value={
                        department.departmentId
                      }
                    >
                      {department.departmentCode}
                      {" - "}
                      {department.departmentName}
                    </option>
                  )
                )}

              </select>

            </div>

            <div className="form-group">

              <label htmlFor="availability-filter">
                Availability
              </label>

              <select
                id="availability-filter"
                value={availabilityFilter}
                onChange={(event) =>
                  setAvailabilityFilter(
                    event.target.value
                  )
                }
              >
                <option value="ALL">
                  All
                </option>

                <option value="AVAILABLE">
                  Available
                </option>

                <option value="FILLING">
                  Filling Fast
                </option>

                <option value="FULL">
                  Full
                </option>

                <option value="REGISTERED">
                  My Registered Events
                </option>

              </select>

            </div>

            <div className="form-group">

              <label htmlFor="event-sort">
                Sort By
              </label>

              <select
                id="event-sort"
                value={sortOption}
                onChange={(event) =>
                  setSortOption(
                    event.target.value
                  )
                }
              >
                <option value="DATE">
                  Event Date
                </option>

                <option value="DEADLINE">
                  Registration Deadline
                </option>

                <option value="SEATS">
                  Most Available Seats
                </option>

                <option value="FEWEST_SEATS">
                  Filling Soonest
                </option>

              </select>

            </div>

          </div>

          <div className="events-result-count">

            Showing{" "}
            <strong>
              {filteredEvents.length}
            </strong>{" "}
            of{" "}
            <strong>
              {events.length}
            </strong>{" "}
            events

          </div>

        </section>

        {filteredEvents.length === 0 ? (

          <section className="event-empty-state">

            <h2>
              No events found
            </h2>

            <p>
              Try changing your search
              or filter options.
            </p>

            <button
              className="register-button"
              onClick={clearFilters}
            >
              Clear Filters
            </button>

          </section>

        ) : (

          <div className="event-list-grid">

            {filteredEvents.map(
              (event) => {

                const label =
                  getEventLabel(event);

                const thumbnail =
                  thumbnailMap[
                    event.eventId
                  ];

                const department =
                  getDepartment(event);

                return (
                  <article
                    className="event-card"
                    key={event.eventId}
                  >

                    <div className="event-card-thumbnail">

                      {thumbnail ? (

                        <img
                          src={`http://localhost:8080${thumbnail}`}
                          alt={event.title}
                        />

                      ) : (

                        <div className="event-card-thumbnail-placeholder">
                          CAMPUSCUE
                        </div>

                      )}

                      <span
                        className={`event-card-label ${label.className}`}
                      >
                        {label.text}
                      </span>

                    </div>

                    <div className="event-card-body">

                      <div className="event-card-top-row">

                        <span className="event-type-badge">
                          {event.eventType}
                        </span>

                        {registeredEventIds.has(
                          Number(event.eventId)
                        ) && (
                          <span className="registered-badge">
                            ✓ Registered
                          </span>
                        )}

                      </div>

                      <h2>
                        {event.title}
                      </h2>

                      <p className="event-card-description">
                        {event.description ||
                          "No description provided."}
                      </p>

                      <div className="event-card-info">

                        <div>
                          <strong>
                            Department
                          </strong>

                          <span>
                            {department
                              ? department.departmentName
                              : "General Campus"}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Date
                          </strong>

                          <span>
                            {formatDate(
                              event.eventDate
                            )}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Time
                          </strong>

                          <span>
                            {formatTime(
                              event.startTime
                            )}
                            {" - "}
                            {formatTime(
                              event.endTime
                            )}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Venue
                          </strong>

                          <span>
                            {event.venue}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Seats
                          </strong>

                          <span>
                            {event.availableSeats}
                            {" / "}
                            {event.totalSeats}
                            {" available"}
                          </span>
                        </div>

                        <div>
                          <strong>
                            Registration closes
                          </strong>

                          <span>
                            {new Date(
                              event.registrationDeadline
                            ).toLocaleString(
                              "en-IN",
                              {
                                day: "2-digit",
                                month: "short",
                                hour: "2-digit",
                                minute: "2-digit",
                              }
                            )}
                          </span>
                        </div>

                      </div>

                      <button
                        className="register-button event-view-button"
                        onClick={() =>
                          openEvent(
                            event.eventId
                          )
                        }
                      >
                        View Event
                      </button>

                    </div>

                  </article>
                );
              }
            )}

          </div>

        )}

      </div>

    </main>
  );
}

export default EventsPage;