import React, {
  useEffect,
  useMemo,
  useState,
} from "react";
import { useNavigate, useParams } from "react-router-dom";

function FacultyEventDetailsPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [registrations, setRegistrations] = useState([]);
  const [coordinators, setCoordinators] = useState([]);
  const [statistics, setStatistics] = useState(null);

  const [loading, setLoading] = useState(true);
  const [registrationsLoading, setRegistrationsLoading] =
    useState(true);
  const [coordinatorsLoading, setCoordinatorsLoading] =
    useState(true);
  const [statisticsLoading, setStatisticsLoading] =
    useState(true);

  const [error, setError] = useState("");

  const [studentIdToAssign, setStudentIdToAssign] =
    useState("");
  const [assigningCoordinator, setAssigningCoordinator] =
    useState(false);
  const [coordinatorMessage, setCoordinatorMessage] =
    useState("");

  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const [expandedRegistrations, setExpandedRegistrations] =
    useState(new Set());

  useEffect(() => {
    loadEvent();
    loadRegistrations();
    loadCoordinators();
    loadStatistics();
  }, [eventId]);

  async function loadEvent() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        throw new Error("Could not load event.");
      }

      const data = await response.json();
      setEvent(data);
    } catch (error) {
      console.error("Load event error:", error);
      setError("Could not load the event details.");
    } finally {
      setLoading(false);
    }
  }

  async function loadRegistrations() {
    setRegistrationsLoading(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/event/${eventId}`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        throw new Error("Could not load registrations.");
      }

      const data = await response.json();

      setRegistrations(
        Array.isArray(data) ? data : []
      );
    } catch (error) {
      console.error(
        "Load registrations error:",
        error
      );
      setRegistrations([]);
    } finally {
      setRegistrationsLoading(false);
    }
  }

  async function loadStatistics() {
    setStatisticsLoading(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/event/${eventId}/statistics`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        throw new Error("Could not load statistics.");
      }

      const data = await response.json();
      setStatistics(data);
    } catch (error) {
      console.error(
        "Load statistics error:",
        error
      );
      setStatistics(null);
    } finally {
      setStatisticsLoading(false);
    }
  }

  async function loadCoordinators() {
    setCoordinatorsLoading(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/coordinators`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        throw new Error(
          "Could not load coordinators."
        );
      }

      const data = await response.json();

      setCoordinators(
        Array.isArray(data) ? data : []
      );
    } catch (error) {
      console.error(
        "Load coordinators error:",
        error
      );
      setCoordinators([]);
    } finally {
      setCoordinatorsLoading(false);
    }
  }

  async function handleAssignCoordinator() {
    setCoordinatorMessage("");

    if (!studentIdToAssign) {
      setCoordinatorMessage(
        "Please enter a student ID."
      );
      return;
    }

    setAssigningCoordinator(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/coordinators`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            studentId: Number(studentIdToAssign),
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setCoordinatorMessage(
          data.message ||
            "Could not assign coordinator."
        );
        return;
      }

      setCoordinatorMessage(
        "Student assigned as coordinator successfully."
      );

      setStudentIdToAssign("");

      await loadCoordinators();
    } catch (error) {
      console.error(
        "Assign coordinator error:",
        error
      );

      setCoordinatorMessage(
        "Could not connect to the CampusCue server."
      );
    } finally {
      setAssigningCoordinator(false);
    }
  }

  const filteredRegistrations = useMemo(() => {
    const search =
      searchText.trim().toLowerCase();

    return registrations.filter(
      (registration) => {
        if (
          statusFilter !== "ALL" &&
          String(
            registration.registrationStatus
          ).toUpperCase() !== statusFilter
        ) {
          return false;
        }

        if (!search) {
          return true;
        }

        if (
          String(
            registration.registrationId || ""
          )
            .toLowerCase()
            .includes(search)
        ) {
          return true;
        }

        const participants =
          Array.isArray(
            registration.participants
          )
            ? registration.participants
            : [];

        return participants.some(
          (participant) => {
            const studentId = String(
              participant.studentId || ""
            ).toLowerCase();

            const name = String(
              participant.name || ""
            ).toLowerCase();

            const email = String(
              participant.email || ""
            ).toLowerCase();

            return (
              studentId.includes(search) ||
              name.includes(search) ||
              email.includes(search)
            );
          }
        );
      }
    );
  }, [
    registrations,
    searchText,
    statusFilter,
  ]);

  function toggleParticipants(
    registrationId
  ) {
    setExpandedRegistrations((current) => {
      const updated = new Set(current);

      if (updated.has(registrationId)) {
        updated.delete(registrationId);
      } else {
        updated.add(registrationId);
      }

      return updated;
    });
  }

  function formatDate(dateString) {
    if (!dateString) {
      return "Not available";
    }

    const date = new Date(
      `${dateString}T00:00:00`
    );

    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  }

  function formatTime(timeString) {
    if (!timeString) {
      return "";
    }

    const [hour, minute] =
      timeString.split(":");

    const date = new Date();

    date.setHours(
      Number(hour),
      Number(minute),
      0,
      0
    );

    return date.toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function getOccupancyPercentage() {
    if (statistics) {
      return Math.round(
        Number(
          statistics.occupancyPercentage || 0
        )
      );
    }

    if (!event) {
      return 0;
    }

    const total =
      Number(event.totalSeats) || 0;

    const available =
      Number(event.availableSeats) || 0;

    if (total <= 0) {
      return 0;
    }

    return Math.round(
      ((total - available) / total) * 100
    );
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Loading event details...</p>
        </div>
      </main>
    );
  }

  if (error || !event) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">

          <button
            className="back-button"
            onClick={() =>
              navigate("/faculty/dashboard")
            }
          >
            ← Faculty Dashboard
          </button>

          <p className="event-message">
            {error || "Event not found."}
          </p>

        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-card">

        {/* =====================================================
            BACK AND SEAT SETTINGS
        ====================================================== */}

        <div
          style={{
            display: "flex",
            gap: "12px",
            flexWrap: "wrap",
            marginBottom: "20px",
          }}
        >

          <button
            className="back-button"
            onClick={() =>
              navigate("/faculty/dashboard")
            }
          >
            ← Faculty Dashboard
          </button>

          <button
            className="register-button"
            type="button"
            onClick={() =>
              navigate(
                `/faculty/events/${eventId}/seating`
              )
            }
          >
            Seat Settings
          </button>

        </div>


        {/* =====================================================
            EVENT HEADER
        ====================================================== */}

        <h1>{event.title}</h1>

        <p className="event-status">
          Status:{" "}
          <strong>{event.status}</strong>
        </p>


        {/* =====================================================
            EVENT DETAILS
        ====================================================== */}

        <section className="event-section">

          <h2>Event Details</h2>

          <div className="event-details-grid">

            <div>
              <strong>Description</strong>

              <p>
                {event.description ||
                  "No description provided."}
              </p>
            </div>

            <div>
              <strong>Event Type</strong>

              <p>
                {event.eventType}
              </p>
            </div>

            <div>
              <strong>Venue</strong>

              <p>
                {event.venue}
              </p>
            </div>

            <div>
              <strong>Date</strong>

              <p>
                {formatDate(
                  event.eventDate
                )}
              </p>
            </div>

            <div>
              <strong>Time</strong>

              <p>
                {formatTime(
                  event.startTime
                )}

                {" - "}

                {formatTime(
                  event.endTime
                )}
              </p>
            </div>

            <div>
              <strong>
                Registration Deadline
              </strong>

              <p>
                {event.registrationDeadline}
              </p>
            </div>

            <div>
              <strong>Total Seats</strong>

              <p>
                {event.totalSeats}
              </p>
            </div>

            <div>
              <strong>Available Seats</strong>

              <p>
                {event.availableSeats}
              </p>
            </div>

            <div>
              <strong>Eligibility</strong>

              <p>
                {event.eligibility ||
                  "No specific eligibility."}
              </p>
            </div>

            <div>
              <strong>Created By</strong>

              <p>
                {event.createdByFacultyId}
              </p>
            </div>

          </div>

        </section>


        {/* =====================================================
            REGISTRATION STATISTICS
        ====================================================== */}

        <section className="event-section">

          <h2>
            Registration Dashboard
          </h2>

          {statisticsLoading ? (
            <p>
              Loading statistics...
            </p>
          ) : (
            <div className="event-details-grid">

              <div>
                <strong>
                  Total Registrations
                </strong>

                <p>
                  {
                    statistics
                      ?.totalRegistrations ??
                    registrations.length
                  }
                </p>
              </div>

              <div>
                <strong>
                  Confirmed Registrations
                </strong>

                <p>
                  {
                    statistics
                      ?.confirmedRegistrations ??
                    registrations.filter(
                      (registration) =>
                        registration.registrationStatus ===
                        "CONFIRMED"
                    ).length
                  }
                </p>
              </div>

              <div>
                <strong>
                  Waitlisted
                </strong>

                <p>
                  {
                    statistics
                      ?.waitlistedRegistrations ??
                    registrations.filter(
                      (registration) =>
                        registration.registrationStatus ===
                        "WAITLISTED"
                    ).length
                  }
                </p>
              </div>

              <div>
                <strong>
                  Cancelled
                </strong>

                <p>
                  {
                    statistics
                      ?.cancelledRegistrations ??
                    registrations.filter(
                      (registration) =>
                        registration.registrationStatus ===
                        "CANCELLED"
                    ).length
                  }
                </p>
              </div>

              <div>
                <strong>
                  Confirmed Seats
                </strong>

                <p>
                  {
                    statistics
                      ?.confirmedSeats ??
                    registrations
                      .filter(
                        (registration) =>
                          registration.registrationStatus ===
                          "CONFIRMED"
                      )
                      .reduce(
                        (
                          total,
                          registration
                        ) =>
                          total +
                          Number(
                            registration.numberOfSeats ||
                              0
                          ),
                        0
                      )
                  }
                </p>
              </div>

              <div>
                <strong>
                  Waitlisted Seats
                </strong>

                <p>
                  {
                    statistics
                      ?.waitlistedSeats ??
                    registrations
                      .filter(
                        (registration) =>
                          registration.registrationStatus ===
                          "WAITLISTED"
                      )
                      .reduce(
                        (
                          total,
                          registration
                        ) =>
                          total +
                          Number(
                            registration.numberOfSeats ||
                              0
                          ),
                        0
                      )
                  }
                </p>
              </div>

              <div>
                <strong>
                  Available Seats
                </strong>

                <p>
                  {
                    statistics
                      ?.availableSeats ??
                    event.availableSeats
                  }
                </p>
              </div>

              <div>
                <strong>
                  Occupancy
                </strong>

                <p>
                  {getOccupancyPercentage()}%
                </p>
              </div>

            </div>
          )}

        </section>


        {/* =====================================================
            COORDINATORS
        ====================================================== */}

        <section className="event-section">

          <h2>
            Event Coordinators
          </h2>

          {coordinatorsLoading ? (
            <p>
              Loading coordinators...
            </p>
          ) : coordinators.length === 0 ? (
            <p>
              No student coordinators assigned yet.
            </p>
          ) : (
            <div className="coordinator-list">

              {coordinators.map(
                (coordinator) => (
                  <div
                    className="coordinator-card"
                    key={
                      coordinator.eventCoordinatorId ||
                      coordinator.studentId
                    }
                  >

                    <p>
                      <strong>
                        Student ID:
                      </strong>{" "}
                      {coordinator.studentId}
                    </p>

                    <p>
                      <strong>
                        Status:
                      </strong>{" "}
                      {coordinator.status}
                    </p>

                    <p>
                      <strong>
                        Assigned By:
                      </strong>{" "}
                      {
                        coordinator.assignedByFacultyId
                      }
                    </p>

                    <p>
                      <strong>
                        Assigned At:
                      </strong>{" "}
                      {coordinator.assignedAt}
                    </p>

                  </div>
                )
              )}

            </div>
          )}

          <div className="coordinator-assignment">

            <h3>
              Assign Student Coordinator
            </h3>

            <div className="coordinator-form">

              <input
                type="number"
                min="1"
                placeholder="Enter Student ID"
                value={
                  studentIdToAssign
                }
                onChange={(event) =>
                  setStudentIdToAssign(
                    event.target.value
                  )
                }
              />

              <button
                className="register-button"
                onClick={
                  handleAssignCoordinator
                }
                disabled={
                  assigningCoordinator
                }
              >
                {assigningCoordinator
                  ? "Assigning..."
                  : "Assign Coordinator"}
              </button>

            </div>

            {coordinatorMessage && (
              <p className="event-message">
                {coordinatorMessage}
              </p>
            )}

          </div>

        </section>


        {/* =====================================================
            REGISTRATION TABLE
        ====================================================== */}

        <section className="event-section">

          <h2>
            Registration Table
          </h2>


          {/* SEARCH AND FILTER */}

          <div
            style={{
              display: "flex",
              gap: "12px",
              flexWrap: "wrap",
              marginBottom: "20px",
            }}
          >

            <input
              type="text"
              placeholder="Search registration, student ID, name or email..."
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
              style={{
                flex: "1",
                minWidth: "280px",
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid #ccc",
              }}
            />

            <select
              value={statusFilter}
              onChange={(event) =>
                setStatusFilter(
                  event.target.value
                )
              }
              style={{
                minWidth: "170px",
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid #ccc",
              }}
            >

              <option value="ALL">
                All Statuses
              </option>

              <option value="CONFIRMED">
                Confirmed
              </option>

              <option value="WAITLISTED">
                Waitlisted
              </option>

              <option value="CANCELLED">
                Cancelled
              </option>

            </select>

            <button
              className="back-button"
              onClick={() => {
                setSearchText("");
                setStatusFilter("ALL");
              }}
            >
              Clear
            </button>

          </div>


          {/* RESULT COUNT */}

          <p>
            Showing{" "}
            <strong>
              {
                filteredRegistrations.length
              }
            </strong>{" "}
            of{" "}
            <strong>
              {registrations.length}
            </strong>{" "}
            registrations
          </p>


          {/* REGISTRATIONS */}

          {registrationsLoading ? (
            <p>
              Loading registrations...
            </p>
          ) : filteredRegistrations.length ===
            0 ? (
            <p>
              No registrations match your
              search/filter.
            </p>
          ) : (
            <div className="registration-table-container">

              <table className="registration-table">

                <thead>

                  <tr>

                    <th>
                      Registration ID
                    </th>

                    <th>
                      Participants
                    </th>

                    <th>
                      Seats
                    </th>

                    <th>
                      Status
                    </th>

                    <th>
                      Registered At
                    </th>

                    <th>
                      Details
                    </th>

                  </tr>

                </thead>

                <tbody>

                  {filteredRegistrations.map(
                    (registration) => {

                      const participants =
                        Array.isArray(
                          registration.participants
                        )
                          ? registration.participants
                          : [];

                      const expanded =
                        expandedRegistrations.has(
                          registration.registrationId
                        );

                      return (
                        <React.Fragment
                          key={
                            registration.registrationId
                          }
                        >

                          <tr>

                            <td>
                              <strong>
                                #
                                {
                                  registration.registrationId
                                }
                              </strong>
                            </td>

                            <td>
                              <strong>
                                {
                                  registration.participantCount ??
                                  participants.length
                                }
                              </strong>{" "}
                              students
                            </td>

                            <td>
                              {
                                registration.numberOfSeats
                              }
                            </td>

                            <td>
                              <span
                                style={{
                                  fontWeight:
                                    "700",
                                }}
                              >
                                {
                                  registration.registrationStatus
                                }
                              </span>
                            </td>

                            <td>
                              {
                                registration.registeredAt
                              }
                            </td>

                            <td>

                              <button
                                className="register-button"
                                onClick={() =>
                                  toggleParticipants(
                                    registration.registrationId
                                  )
                                }
                              >
                                {expanded
                                  ? "Hide Participants"
                                  : "View Participants"}
                              </button>

                            </td>

                          </tr>


                          {expanded && (
                            <tr>

                              <td colSpan="6">

                                <div
                                  style={{
                                    padding:
                                      "16px",
                                    background:
                                      "#f8fafc",
                                    borderRadius:
                                      "10px",
                                  }}
                                >

                                  <h3>
                                    Participants
                                  </h3>

                                  {participants.length ===
                                  0 ? (
                                    <p>
                                      No participant
                                      records found.
                                    </p>
                                  ) : (
                                    <div className="registration-table-container">

                                      <table className="registration-table">

                                        <thead>

                                          <tr>

                                            <th>
                                              Student ID
                                            </th>

                                            <th>
                                              Name
                                            </th>

                                            <th>
                                              College Email
                                            </th>

                                          </tr>

                                        </thead>

                                        <tbody>

                                          {participants.map(
                                            (
                                              participant,
                                              index
                                            ) => (
                                              <tr
                                                key={`${participant.studentId}-${index}`}
                                              >

                                                <td>
                                                  {
                                                    participant.studentId
                                                  }
                                                </td>

                                                <td>
                                                  {
                                                    participant.name
                                                  }
                                                </td>

                                                <td>
                                                  {
                                                    participant.email
                                                  }
                                                </td>

                                              </tr>
                                            )
                                          )}

                                        </tbody>

                                      </table>

                                    </div>
                                  )}

                                </div>

                              </td>

                            </tr>
                          )}

                        </React.Fragment>
                      );
                    }
                  )}

                </tbody>

              </table>

            </div>
          )}

        </section>

      </div>
    </main>
  );
}

export default FacultyEventDetailsPage;