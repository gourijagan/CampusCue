import { useState } from "react";
import { useNavigate } from "react-router-dom";

function CreateEventPage() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: "",
    description: "",
    eventType: "GENERAL",
    venue: "",
    eventDate: "",
    startTime: "",
    endTime: "",
    registrationDeadline: "",
    totalSeats: "",
    eligibility: "",
  });

  const [message, setMessage] = useState("");
  const [creating, setCreating] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;

    setForm((currentForm) => ({
      ...currentForm,
      [name]: value,
    }));
  }

  async function handleSubmit(event) {
    event.preventDefault();

    setMessage("");
    setCreating(true);

    try {
      const response = await fetch(
        "http://localhost:8080/api/events",
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            title: form.title,
            description: form.description,
            eventType: form.eventType,

            /*
             * DO NOT send departmentId.
             *
             * Backend automatically determines the department
             * from the logged-in faculty account.
             */
            venue: form.venue,
            eventDate: form.eventDate,
            startTime: form.startTime,
            endTime: form.endTime,
            registrationDeadline:
              form.registrationDeadline,
            totalSeats: Number(form.totalSeats),
            eligibility: form.eligibility,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setMessage(
          data.message || "Could not create the event."
        );
        return;
      }

      setMessage(
        `Event created successfully. Event ID: ${data.eventId}`
      );

      setTimeout(() => {
        navigate("/faculty/dashboard");
      }, 1000);

    } catch (error) {
      console.error("Create event error:", error);

      setMessage(
        "Could not connect to the CampusCue server."
      );
    } finally {
      setCreating(false);
    }
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-card">

        <button
          className="back-button"
          onClick={() =>
            navigate("/faculty/dashboard")
          }
        >
          ← Faculty Dashboard
        </button>

        <h1>Create Event</h1>

        <p className="events-page-subtitle">
          Create a new campus event and configure its
          registration details.
        </p>

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        <form
          className="event-form"
          onSubmit={handleSubmit}
        >

          <div className="form-group">
            <label htmlFor="title">
              Event Title
            </label>

            <input
              id="title"
              name="title"
              type="text"
              value={form.title}
              onChange={handleChange}
              required
              placeholder="Example: Campus Tech Fest 2026"
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">
              Description
            </label>

            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleChange}
              rows="4"
              placeholder="Describe the event..."
            />
          </div>

          <div className="form-group">
            <label htmlFor="eventType">
              Event Type
            </label>

            <select
              id="eventType"
              name="eventType"
              value={form.eventType}
              onChange={handleChange}
              required
            >
              <option value="GENERAL">
                General Event
              </option>

              <option value="DEPARTMENT">
                Department Event
              </option>
            </select>

            {form.eventType === "GENERAL" ? (
              <small>
                This event will be available as a general
                campus event.
              </small>
            ) : (
              <small>
                This event will automatically belong to the
                department of the faculty creating it.
              </small>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="venue">
              Venue
            </label>

            <input
              id="venue"
              name="venue"
              type="text"
              value={form.venue}
              onChange={handleChange}
              required
              placeholder="Example: Main Auditorium"
            />
          </div>

          <div className="form-group">
            <label htmlFor="eventDate">
              Event Date
            </label>

            <input
              id="eventDate"
              name="eventDate"
              type="date"
              value={form.eventDate}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="startTime">
              Start Time
            </label>

            <input
              id="startTime"
              name="startTime"
              type="time"
              value={form.startTime}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="endTime">
              End Time
            </label>

            <input
              id="endTime"
              name="endTime"
              type="time"
              value={form.endTime}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="registrationDeadline">
              Registration Deadline
            </label>

            <input
              id="registrationDeadline"
              name="registrationDeadline"
              type="datetime-local"
              value={form.registrationDeadline}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="totalSeats">
              Total Seats
            </label>

            <input
              id="totalSeats"
              name="totalSeats"
              type="number"
              min="1"
              value={form.totalSeats}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="eligibility">
              Eligibility
            </label>

            <textarea
              id="eligibility"
              name="eligibility"
              value={form.eligibility}
              onChange={handleChange}
              rows="3"
              placeholder="Example: All verified students"
            />
          </div>

          <button
            className="register-button"
            type="submit"
            disabled={creating}
          >
            {creating
              ? "Creating Event..."
              : "Create Event"}
          </button>

        </form>
      </div>
    </main>
  );
}

export default CreateEventPage;