import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function EventImageManagementPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [images, setImages] = useState([]);

  const [selectedFile, setSelectedFile] = useState(null);
  const [imageType, setImageType] = useState("POSTER");

  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [deletingImageId, setDeletingImageId] = useState(null);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadEvent();
    loadImages();
  }, [eventId]);

  async function loadEvent() {
    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not load event."
        );
      }

      setEvent(data);
    } catch (error) {
      console.error("Load event error:", error);

      setError(
        error.message || "Could not load event details."
      );
    }
  }

  async function loadImages() {
    setLoading(true);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/images`,
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not load event images."
        );
      }

      setImages(data);
    } catch (error) {
      console.error("Load images error:", error);

      setError(
        error.message || "Could not load event images."
      );
    } finally {
      setLoading(false);
    }
  }

  function handleFileChange(eventObject) {
    const file = eventObject.target.files[0];

    setSelectedFile(file || null);
    setMessage("");
    setError("");
  }

  async function handleUpload(eventObject) {
    eventObject.preventDefault();

    setMessage("");
    setError("");

    if (!selectedFile) {
      setError("Please select an image.");
      return;
    }

    setUploading(true);

    try {
      const formData = new FormData();

      formData.append("file", selectedFile);
      formData.append("imageType", imageType);

      const response = await fetch(
        `http://localhost:8080/api/events/${eventId}/images`,
        {
          method: "POST",
          credentials: "include",
          body: formData,
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not upload image."
        );
      }

      setMessage("Image uploaded successfully.");

      setSelectedFile(null);

      const fileInput =
        document.getElementById("event-image-file");

      if (fileInput) {
        fileInput.value = "";
      }

      await loadImages();

      setTimeout(() => {
        navigate(`/events/${eventId}`);
      }, 800);
    } catch (error) {
      console.error("Upload image error:", error);

      setError(
        error.message || "Could not upload image."
      );
    } finally {
      setUploading(false);
    }
  }

  async function handleDeleteImage(imageId) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this image?"
    );

    if (!confirmed) {
      return;
    }

    setMessage("");
    setError("");
    setDeletingImageId(imageId);

    try {
      const response = await fetch(
        `http://localhost:8080/api/events/images/${imageId}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not delete image."
        );
      }

      setMessage("Image deleted successfully.");

      await loadImages();
    } catch (error) {
      console.error("Delete image error:", error);

      setError(
        error.message || "Could not delete image."
      );
    } finally {
      setDeletingImageId(null);
    }
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Loading event images...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-card">

        <button
          className="back-button"
          onClick={() =>
            navigate(`/events/${eventId}`)
          }
        >
          ← Back to Event
        </button>

        <h1>Manage Event Images</h1>

        {event && (
          <p>
            Event:
            <strong> {event.title}</strong>
          </p>
        )}

        {/* Upload Section */}
        <section className="event-section">

          <h2>Upload Image</h2>

          <form
            className="event-form"
            onSubmit={handleUpload}
          >

            <div className="form-group">

              <label htmlFor="event-image-file">
                Select Image
              </label>

              <input
                id="event-image-file"
                type="file"
                accept=".jpg,.jpeg,.png,.webp"
                onChange={handleFileChange}
              />

              <small>
                JPG, JPEG, PNG or WEBP.
                Maximum size: 5 MB.
              </small>

            </div>

            <div className="form-group">

              <label htmlFor="image-type">
                Image Type
              </label>

              <select
                id="image-type"
                value={imageType}
                onChange={(eventObject) =>
                  setImageType(
                    eventObject.target.value
                  )
                }
              >
                <option value="THUMBNAIL">
                  Thumbnail
                </option>

                <option value="BACKGROUND">
                  Background
                </option>

                <option value="POSTER">
                  Poster
                </option>

                <option value="GALLERY">
                  Gallery Image
                </option>
              </select>

            </div>

            {selectedFile && (
              <p>
                Selected:
                <strong>
                  {" "}
                  {selectedFile.name}
                </strong>
              </p>
            )}

            {error && (
              <p className="event-message">
                {error}
              </p>
            )}

            {message && (
              <p className="event-message">
                {message}
              </p>
            )}

            <button
              className="register-button"
              type="submit"
              disabled={uploading}
            >
              {uploading
                ? "Uploading..."
                : "Upload Image"}
            </button>

          </form>

        </section>

        {/* Existing Images */}
        <section className="event-section">

          <h2>Existing Images</h2>

          {images.length === 0 ? (
            <p>
              No images have been uploaded
              for this event yet.
            </p>
          ) : (
            <div className="event-image-grid">

              {images.map((image) => (

                <div
                  className="event-image-card"
                  key={image.eventImageId}
                >

                  <img
                    src={`http://localhost:8080${image.imageUrl}`}
                    alt={`${event?.title || "Event"} ${image.imageType.toLowerCase()}`}
                  />

                  <p>
                    <strong>
                      {image.imageType}
                    </strong>
                  </p>

                  <button
                    type="button"
                    className="back-button"
                    onClick={() =>
                      handleDeleteImage(
                        image.eventImageId
                      )
                    }
                    disabled={
                      deletingImageId ===
                      image.eventImageId
                    }
                  >
                    {deletingImageId ===
                    image.eventImageId
                      ? "Deleting..."
                      : "Delete Image"}
                  </button>

                </div>

              ))}

            </div>
          )}

        </section>

      </div>
    </main>
  );
}

export default EventImageManagementPage;