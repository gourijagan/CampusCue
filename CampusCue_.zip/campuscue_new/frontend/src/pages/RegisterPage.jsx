import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function RegisterPage() {
  const navigate = useNavigate();

  const [departments, setDepartments] = useState([]);
  const [tutors, setTutors] = useState([]);

  const [loadingDepartments, setLoadingDepartments] = useState(true);
  const [loadingTutors, setLoadingTutors] = useState(false);
  const [registering, setRegistering] = useState(false);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const [form, setForm] = useState({
    regNo: "",
    name: "",
    batchStartYear: "",
    batchEndYear: "",
    departmentId: "",
    tutorFacultyId: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  useEffect(() => {
    async function loadDepartments() {
      try {
        const response = await fetch(
          "http://localhost:8080/api/departments"
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data.message || "Could not load departments."
          );
        }

        setDepartments(data);
      } catch (error) {
        console.error("Department loading error:", error);

        setError(
          "Could not load departments. Please try again."
        );
      } finally {
        setLoadingDepartments(false);
      }
    }

    loadDepartments();
  }, []);

  async function loadTutors(departmentId) {
    if (!departmentId) {
      setTutors([]);
      return;
    }

    setLoadingTutors(true);
    setError("");

    try {
      const response = await fetch(
        `http://localhost:8080/api/faculty/department/${departmentId}`
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Could not load tutors."
        );
      }

      setTutors(data);
    } catch (error) {
      console.error("Tutor loading error:", error);

      setTutors([]);

      setError(
        "Could not load faculty for this department."
      );
    } finally {
      setLoadingTutors(false);
    }
  }

  function handleChange(event) {
    const { name, value } = event.target;

    setForm((currentForm) => ({
      ...currentForm,
      [name]: value,
    }));

    setMessage("");
    setError("");

    if (name === "departmentId") {
      setForm((currentForm) => ({
        ...currentForm,
        departmentId: value,
        tutorFacultyId: "",
      }));

      loadTutors(value);
    }
  }

  async function handleSubmit(event) {
    event.preventDefault();

    setMessage("");
    setError("");

    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (form.password.length < 6) {
      setError(
        "Password must contain at least 6 characters."
      );
      return;
    }

    if (!form.tutorFacultyId) {
      setError("Please select your tutor faculty.");
      return;
    }

    setRegistering(true);

    try {
      const response = await fetch(
        "http://localhost:8080/api/student-registration",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            regNo: form.regNo,
            name: form.name,
            batchStartYear: Number(
              form.batchStartYear
            ),
            batchEndYear: Number(
              form.batchEndYear
            ),
            departmentId: Number(
              form.departmentId
            ),
            tutorFacultyId:
              form.tutorFacultyId,
            email: form.email,
            password: form.password,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(
          data.message ||
            "Could not submit registration request."
        );
        return;
      }

      setMessage(
        data.message ||
          "Registration request submitted successfully."
      );

      setSubmitted(true);

      setForm({
        regNo: "",
        name: "",
        batchStartYear: "",
        batchEndYear: "",
        departmentId: "",
        tutorFacultyId: "",
        email: "",
        password: "",
        confirmPassword: "",
      });

      setTutors([]);

    } catch (error) {
      console.error(
        "Student registration error:",
        error
      );

      setError(
        "Could not connect to the CampusCue server."
      );
    } finally {
      setRegistering(false);
    }
  }

  if (submitted) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">

          <h1>Registration Submitted</h1>

          <div className="event-message">
            <p>
              <strong>
                Your CampusCue registration request has
                been submitted successfully.
              </strong>
            </p>

            <p>
              Your request has been sent to your selected
              tutor faculty for approval.
            </p>

            <p>
              <strong>Status:</strong> Pending Approval
            </p>

            <p>
              You will be able to log in after your tutor
              approves your registration.
            </p>
          </div>

          <button
            className="register-button"
            onClick={() => navigate("/login")}
          >
            Go to Login
          </button>

        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">
      <div className="dashboard-card">

        <button
          className="back-button"
          onClick={() => navigate("/login")}
        >
          ← Back to Login
        </button>

        <h1>Student Registration</h1>

        <p>
          Create a CampusCue account request using
          your college details.
        </p>

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        {error && (
          <p className="event-message">
            {error}
          </p>
        )}

        <form
          className="event-form"
          onSubmit={handleSubmit}
        >

          <div className="form-group">
            <label htmlFor="regNo">
              Registration Number
            </label>

            <input
              id="regNo"
              name="regNo"
              type="text"
              value={form.regNo}
              onChange={handleChange}
              placeholder="Example: JEC25CS000"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="name">
              Full Name
            </label>

            <input
              id="name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="batchStartYear">
              Batch Start Year
            </label>

            <input
              id="batchStartYear"
              name="batchStartYear"
              type="number"
              min="2022"
              max="2100"
              value={form.batchStartYear}
              onChange={handleChange}
              placeholder="Example: 2025"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="batchEndYear">
              Batch End Year
            </label>

            <input
              id="batchEndYear"
              name="batchEndYear"
              type="number"
              min="2020"
              max="2100"
              value={form.batchEndYear}
              onChange={handleChange}
              placeholder="Example: 2029"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="departmentId">
              Department
            </label>

            <select
              id="departmentId"
              name="departmentId"
              value={form.departmentId}
              onChange={handleChange}
              required
              disabled={loadingDepartments}
            >
              <option value="">
                {loadingDepartments
                  ? "Loading departments..."
                  : "Select your department"}
              </option>

              {departments.map((department) => (
                <option
                  key={department.departmentId}
                  value={department.departmentId}
                >
                  {department.departmentName}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="tutorFacultyId">
              Tutor Faculty
            </label>

            <select
              id="tutorFacultyId"
              name="tutorFacultyId"
              value={form.tutorFacultyId}
              onChange={handleChange}
              required
              disabled={
                !form.departmentId ||
                loadingTutors
              }
            >
              <option value="">
                {!form.departmentId
                  ? "Select department first"
                  : loadingTutors
                  ? "Loading faculty..."
                  : tutors.length === 0
                  ? "No faculty available"
                  : "Select your tutor"}
              </option>

              {tutors.map((tutor) => (
                <option
                  key={tutor.facultyId}
                  value={tutor.facultyId}
                >
                  {tutor.name} — {tutor.facultyId}
                </option>
              ))}
            </select>

            <small>
              Select the faculty member assigned
              as your tutor.
            </small>
          </div>

          <div className="form-group">
            <label htmlFor="email">
              College Email
            </label>

            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="name.dep25@jecc.ac.in"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">
              Password
            </label>

            <input
              id="password"
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">
              Confirm Password
            </label>

            <input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              value={form.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>

          <button
            className="register-button"
            type="submit"
            disabled={registering}
          >
            {registering
              ? "Submitting Request..."
              : "Submit Registration Request"}
          </button>

        </form>
      </div>
    </main>
  );
}

export default RegisterPage;