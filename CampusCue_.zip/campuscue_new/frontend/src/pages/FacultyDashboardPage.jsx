import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function FacultyDashboardPage() {
  const navigate = useNavigate();

  const [faculty, setFaculty] = useState(null);

  const [allEvents, setAllEvents] = useState([]);
  const [myEvents, setMyEvents] = useState([]);

  const [departments, setDepartments] = useState([]);
  const [thumbnailMap, setThumbnailMap] = useState({});

  const [requestCount, setRequestCount] = useState(0);

  const [loading, setLoading] = useState(true);
  const [eventsLoading, setEventsLoading] =
    useState(true);
  const [myEventsLoading, setMyEventsLoading] =
    useState(true);

  const [message, setMessage] = useState("");

  useEffect(() => {
    loadFaculty();
    loadAllEvents();
    loadMyEvents();
    loadDepartments();
    loadRequestCount();
  }, []);

  async function loadFaculty() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/auth/me",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (
        !response.ok ||
        data.userType !== "FACULTY"
      ) {
        navigate("/login", {
          replace: true,
        });
        return;
      }

      setFaculty(data);

    } catch (error) {
      console.error(
        "Faculty dashboard error:",
        error
      );

      setMessage(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setLoading(false);
    }
  }

  async function loadAllEvents() {
    try {
      setEventsLoading(true);

      const response = await fetch(
        "http://localhost:8080/api/events",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setMessage(
          data.message ||
            "Could not load campus events."
        );
        return;
      }

      setAllEvents(
        Array.isArray(data) ? data : []
      );

      await loadThumbnails(data);

    } catch (error) {
      console.error(
        "Campus events error:",
        error
      );

      setMessage(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setEventsLoading(false);
    }
  }

  async function loadMyEvents() {
    try {
      setMyEventsLoading(true);

      const response = await fetch(
        "http://localhost:8080/api/events/faculty/my-events",
        {
          method: "GET",
          credentials: "include",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setMessage(
          data.message ||
            "Could not load your events."
        );
        return;
      }

      setMyEvents(
        Array.isArray(data) ? data : []
      );

      await loadThumbnails(data);

    } catch (error) {
      console.error(
        "Faculty events error:",
        error
      );

      setMessage(
        "Could not connect to the CampusCue server."
      );

    } finally {
      setMyEventsLoading(false);
    }
  }

  async function loadDepartments() {
    try {
      const response = await fetch(
        "http://localhost:8080/api/departments",
        {
          method: "GET",
          credentials: "include",
        }
      );

      if (!response.ok) {
        return;
      }

      const data = await response.json();

      setDepartments(data);

    } catch (error) {
      console.error(
        "Department loading error:",
        error
      );
    }
  }

 const loadRequestCount = async () => {
    try {
        const response = await fetch(
            "http://localhost:8080/api/student-registration/pending/count",
            {
                credentials: "include",
            }
        );

        if (!response.ok) {
            throw new Error("Failed to load request count.");
        }

        const data = await response.json();

        setRequestCount(
            typeof data.count === "number"
                ? data.count
                : 0
        );
    } catch (error) {
        console.error(error);
        setRequestCount(0);
    }
};

  async function loadThumbnails(eventList) {
    if (!Array.isArray(eventList)) {
      return;
    }

    const thumbnailData = {};

    await Promise.all(
      eventList.map(async (event) => {
        try {
          const response = await fetch(
            `http://localhost:8080/api/events/${event.eventId}/images`,
            {
              method: "GET",
              credentials: "include",
            }
          );

          if (!response.ok) {
            return;
          }

          const images =
            await response.json();

          const thumbnail =
            images.find(
              (image) =>
                image.imageType ===
                "THUMBNAIL"
            );

          if (thumbnail) {
            thumbnailData[
              event.eventId
            ] = thumbnail.imageUrl;
          }

        } catch (error) {
          console.error(
            `Thumbnail error for event ${event.eventId}:`,
            error
          );
        }
      })
    );

    setThumbnailMap(
      (previous) => ({
        ...previous,
        ...thumbnailData,
      })
    );
  }

  function getDepartmentName(event) {
    if (!event.departmentId) {
      return "General Campus";
    }

    const department =
      departments.find(
        (item) =>
          Number(
            item.departmentId
          ) ===
          Number(event.departmentId)
      );

    return department
      ? department.departmentName
      : "Department Event";
  }

  function formatDate(dateString) {
    if (!dateString) {
      return "Not available";
    }

    const date = new Date(
      `${dateString}T00:00:00`
    );

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  }

  function formatTime(timeString) {
    if (!timeString) {
      return "";
    }

    const [
      hour,
      minute,
    ] = timeString.split(":");

    const date = new Date();

    date.setHours(
      Number(hour),
      Number(minute),
      0,
      0
    );

    return date.toLocaleTimeString(
      "en-IN",
      {
        hour: "2-digit",
        minute: "2-digit",
      }
    );
  }

  function getOccupancy(event) {
    const total =
      Number(event.totalSeats) || 0;

    const available =
      Number(event.availableSeats) || 0;

    if (total <= 0) {
      return 0;
    }

    return Math.round(
      ((total - available) / total) *
        100
    );
  }

  async function handleLogout() {
    try {
      await fetch(
        "http://localhost:8080/api/auth/logout",
        {
          method: "POST",
          credentials: "include",
        }
      );
    } catch (error) {
      console.error(
        "Logout error:",
        error
      );
    }

    navigate("/login", {
      replace: true,
    });
  }

  function renderEventCard(event) {
    const thumbnail =
      thumbnailMap[event.eventId];

    const occupancy =
      getOccupancy(event);

    return (
      <article
        className="event-card"
        key={event.eventId}
      >

        <div className="event-card-thumbnail">

          {thumbnail ? (

            <img
              src={`http://localhost:8080${thumbnail}`}
              alt={event.title}
            />

          ) : (

            <div className="event-card-thumbnail-placeholder">
              CAMPUSCUE
            </div>

          )}

          <span className="event-card-label event-label-plenty">
            {event.status}
          </span>

        </div>

        <div className="event-card-body">

          <div className="event-card-top-row">

            <span className="event-type-badge">
              {event.eventType}
            </span>

            <span className="registered-badge">
              {occupancy}% Filled
            </span>

          </div>

          
          <h3 style={{ fontWeight: "800" }}>{event.title}</h3>
          

          <p className="event-card-description">
            {event.description ||
              "No description provided."}
          </p>

          <div className="event-card-info">

            <div>
              <strong>
                Department
              </strong>

              <span>
                {getDepartmentName(event)}
              </span>
            </div>

            <div>
              <strong>
                Date
              </strong>

              <span>
                {formatDate(
                  event.eventDate
                )}
              </span>
            </div>

            <div>
              <strong>
                Time
              </strong>

              <span>
                {formatTime(
                  event.startTime
                )}
                {" - "}
                {formatTime(
                  event.endTime
                )}
              </span>
            </div>

            <div>
              <strong>
                Venue
              </strong>

              <span>
                {event.venue}
              </span>
            </div>

            <div>
              <strong>
                Seats
              </strong>

              <span>
                {event.availableSeats}
                {" / "}
                {event.totalSeats}
                {" available"}
              </span>
            </div>

            <div>
              <strong>
                Registration closes
              </strong>

              <span>
                {event.registrationDeadline
                  ? new Date(
                      event.registrationDeadline
                    ).toLocaleString(
                      "en-IN",
                      {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      }
                    )
                  : "Not available"}
              </span>
            </div>

          </div>

          <div className="faculty-event-actions">

            <button
              className="register-button"
              onClick={() =>
                navigate(
                  `/faculty/events/${event.eventId}`
                )
              }
            >
              View Event
            </button>

            <button
              className="register-button"
              onClick={() =>
                navigate(
                  `/events/${event.eventId}/coordinator/images`
                )
              }
            >
              Manage Images
            </button>

          </div>

        </div>

      </article>
    );
  }

  if (loading) {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>
            Loading faculty dashboard...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="dashboard-page">

      <div className="dashboard-card">

        {/* =====================================================
            HEADER
        ===================================================== */}

        <div className="events-page-header">

          <div>
            <h1>
              Faculty Dashboard
            </h1>

            <p className="events-page-subtitle">
              Manage your campus events,
              registrations and event
              content.
            </p>
          </div>

          <div
            style={{
              display: "flex",
              gap: "10px",
              alignItems: "center",
            }}
          >

            <button
              className="back-button"
              onClick={() =>
                navigate("/faculty/requests")
              }
            >
              Requests
              {requestCount > 0
                ? ` (${requestCount})`
                : ""}
            </button>

            <button
              className="back-button"
              onClick={handleLogout}
            >
              Logout
            </button>

          </div>

        </div>

        {message && (
          <p className="event-message">
            {message}
          </p>
        )}

        {/* =====================================================
            FACULTY PROFILE
        ===================================================== */}

        {faculty && (
          <section className="faculty-profile-card">

            <div>
              <span className="faculty-profile-label">
                Faculty
              </span>

              <h2>
                {faculty.name}
              </h2>

              <p>
                {faculty.email}
              </p>
            </div>

            <div className="faculty-profile-details">

              <div>
                <strong>
                  Designation
                </strong>

                <span>
                  {faculty.designation}
                </span>
              </div>

              <div>
  <strong>
    Faculty ID
  </strong>

  <span>
    {faculty.userId}
  </span>
</div>

              <div>
                <strong>
                  Department
                </strong>

                <span>
                  {faculty.departmentId
                    ? departments.find(
                        (department) =>
                          Number(
                            department.departmentId
                          ) ===
                          Number(
                            faculty.departmentId
                          )
                      )?.departmentName ||
                      "Assigned Department"
                    : "Not assigned"}
                </span>
              </div>

            </div>

          </section>
        )}

        {/* =====================================================
            DASHBOARD ACTIONS
        ===================================================== */}

        <section className="faculty-dashboard-actions">

          <button
            className="register-button"
            onClick={() =>
              navigate(
                "/faculty/create-event"
              )
            }
          >
            + Create Event
          </button>

          <button
            className="register-button"
            onClick={() =>
              navigate(
                "/faculty/events"
              )
            }
          >
            Manage My Events
          </button>

        </section>

        {/* =====================================================
            CAMPUS EVENTS
        ===================================================== */}

        <section className="faculty-event-section">

          <div className="events-page-header">

            <div>
              <h2>
                Campus Events
              </h2>

              <p className="events-page-subtitle">
                Upcoming active events across
                CampusCue.
              </p>
            </div>

            <strong>
              {allEvents.length} event
              {allEvents.length === 1
                ? ""
                : "s"}
            </strong>

          </div>

          {eventsLoading ? (

            <p>
              Loading campus events...
            </p>

          ) : allEvents.length === 0 ? (

            <section className="event-empty-state">

              <h2>
                No Active Events
              </h2>

              <p>
                There are currently no active
                campus events.
              </p>

            </section>

          ) : (

            <div className="event-list-grid">

              {allEvents.map(
                renderEventCard
              )}

            </div>
          )}

        </section>

        {/* =====================================================
            MY EVENTS
        ===================================================== */}

        <section className="faculty-event-section">

          <div className="events-page-header">

            <div>
              <h2>
                My Events
              </h2>

              <p className="events-page-subtitle">
                Events created by your
                faculty account.
              </p>
            </div>

            <strong>
              {myEvents.length} event
              {myEvents.length === 1
                ? ""
                : "s"}
            </strong>

          </div>

          {myEventsLoading ? (

            <p>
              Loading your events...
            </p>

          ) : myEvents.length === 0 ? (

            <section className="event-empty-state">

              <h2>
                No Events Created Yet
              </h2>

              <p>
                You have not created any
                CampusCue events yet.
              </p>

              <button
                className="register-button"
                onClick={() =>
                  navigate(
                    "/faculty/create-event"
                  )
                }
              >
                Create Event
              </button>

            </section>

          ) : (

            <div className="event-list-grid">

              {myEvents.map(
                renderEventCard
              )}

            </div>
          )}

        </section>

      </div>

    </main>
  );
}

export default FacultyDashboardPage;