import { useEffect, useMemo, useState } from "react";

function SeatMap({
  eventId,
  requiredSeats,
  onHoldCreated,
  disabled = false,
}) {
  const [seating, setSeating] =
    useState(null);

  const [selectedSeats, setSelectedSeats] =
    useState([]);

  const [holdToken, setHoldToken] =
    useState("");

  const [expiresAt, setExpiresAt] =
    useState(null);

  const [message, setMessage] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [holding, setHolding] =
    useState(false);

  const [secondsRemaining, setSecondsRemaining] =
    useState(0);

  async function loadSeating() {
    setLoading(true);

    try {
      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}/seating`,
          {
            credentials: "include",
          }
        );

      if (!response.ok) {
        throw new Error(
          "Could not load seating."
        );
      }

      const data =
        await response.json();

      setSeating(data);
    } catch (error) {
      console.error(error);
      setMessage(
        "Seating has not been configured for this event yet."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadSeating();
  }, [eventId]);

  useEffect(() => {
    if (!expiresAt) {
      return;
    }

    const timer =
      setInterval(() => {

        const remaining =
          Math.max(
            0,
            Math.floor(
              (
                new Date(
                  expiresAt
                ).getTime() -
                Date.now()
              ) / 1000
            )
          );

        setSecondsRemaining(
          remaining
        );

        if (remaining === 0) {
          setHoldToken("");
          setExpiresAt(null);
          setSelectedSeats([]);
          setMessage(
            "Your seat hold expired. Please select your seats again."
          );

          loadSeating();
        }

      }, 1000);

    return () =>
      clearInterval(timer);
  }, [expiresAt]);

  const seats =
    seating?.seats || [];

  const config =
    seating?.config;

  const rows =
    config?.rowsCount || 1;

  const columns =
    config?.columnsCount || 1;

  const selectedSet =
    useMemo(
      () =>
        new Set(
          selectedSeats
        ),
      [selectedSeats]
    );

  function toggleSeat(seat) {

    if (disabled) {
      return;
    }

    if (
      seat.seatState ===
        "BOOKED" ||
      seat.seatState ===
        "LOCKED" ||
      seat.seatState ===
        "TEMPORARILY_HELD"
    ) {
      return;
    }

    if (
      selectedSet.has(
        seat.seatId
      )
    ) {

      setSelectedSeats(
        selectedSeats.filter(
          (id) =>
            id !== seat.seatId
        )
      );

      return;
    }

    if (
      selectedSeats.length >=
      requiredSeats
    ) {

      setMessage(
        `Select only ${requiredSeats} seat(s).`
      );

      return;
    }

    setSelectedSeats([
      ...selectedSeats,
      seat.seatId,
    ]);

    setMessage("");
  }

  async function holdSelectedSeats() {

    if (
      selectedSeats.length !==
      requiredSeats
    ) {

      setMessage(
        `Please select exactly ${requiredSeats} seat(s).`
      );

      return;
    }

    setHolding(true);
    setMessage("");

    try {

      const response =
        await fetch(
          `http://localhost:8080/api/events/${eventId}/seating/hold`,
          {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type":
                "application/json",
            },
            body: JSON.stringify({
              seatIds:
                selectedSeats,
            }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {

        setMessage(
          data.message ||
            "Could not hold the selected seats."
        );

        await loadSeating();

        return;
      }

      setHoldToken(
        data.holdToken
      );

      setExpiresAt(
        data.expiresAt
      );

      setSecondsRemaining(
        300
      );

      setMessage(
        "Seats held for 5 minutes."
      );

      onHoldCreated?.({
        seatIds:
          selectedSeats,
        holdToken:
          data.holdToken,
        expiresAt:
          data.expiresAt,
      });

    } catch (error) {

      console.error(error);

      setMessage(
        "Could not connect to the server."
      );

    } finally {
      setHolding(false);
    }
  }

  if (loading) {
    return (
      <section className="seat-map-section">
        <p>
          Loading seat map...
        </p>
      </section>
    );
  }

  if (!config) {
    return null;
  }

  return (
    <section className="seat-map-section">

      <div className="seat-map-header">

        <div>
          <h3>
            Select Seats
          </h3>

          <p>
            Select {requiredSeats} seat(s)
            together where possible.
          </p>
        </div>

        <div>
          {holdToken && (
            <strong>
              Hold:
              {" "}
              {Math.floor(
                secondsRemaining / 60
              )}
              :
              {String(
                secondsRemaining % 60
              ).padStart(2, "0")}
            </strong>
          )}
        </div>

      </div>

      <div className="seat-map-legend">

        <span>
          <i className="seat available" />
          Available
        </span>

        <span>
          <i className="seat selected" />
          Selected
        </span>

        <span>
          <i className="seat held" />
          Temporarily Held
        </span>

        <span>
          <i className="seat booked" />
          Booked
        </span>

        <span>
          <i className="seat locked" />
          Locked
        </span>

      </div>

      <div
        className={`seat-map layout-${config.layoutType.toLowerCase()}`}
        style={{
          gridTemplateColumns:
            `repeat(${columns}, minmax(48px, 1fr))`,
        }}
      >

        {seats.map(
          (seat) => {

            const selected =
              selectedSet.has(
                seat.seatId
              );

            const state =
              selected
                ? "SELECTED"
                : seat.seatState;

            return (
              <button
                key={
                  seat.seatId
                }
                type="button"
                className={`seat ${state.toLowerCase()}`}
                title={
                  seat.seatLabel
                }
                onClick={() =>
                  toggleSeat(seat)
                }
                disabled={
                  disabled ||
                  seat.seatState ===
                    "BOOKED" ||
                  seat.seatState ===
                    "LOCKED" ||
                  seat.seatState ===
                    "TEMPORARILY_HELD"
                }
              >
                {seat.seatLabel}
              </button>
            );
          }
        )}

      </div>

      <div className="seat-map-stage">
        STAGE / FRONT
      </div>

      <div className="seat-selection-summary">

        <strong>
          Selected:
          {" "}
          {selectedSeats.length}
          {" / "}
          {requiredSeats}
        </strong>

        <button
          type="button"
          className="register-button"
          disabled={
            holding ||
            selectedSeats.length !==
              requiredSeats
          }
          onClick={
            holdSelectedSeats
          }
        >
          {holding
            ? "Holding..."
            : "Hold Selected Seats"}
        </button>

      </div>

      {message && (
        <p className="event-message">
          {message}
        </p>
      )}

    </section>
  );
}

export default SeatMap;