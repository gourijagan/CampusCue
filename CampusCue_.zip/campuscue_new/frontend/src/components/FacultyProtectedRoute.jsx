import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";

function FacultyProtectedRoute({ children }) {
  const [status, setStatus] = useState("checking");

  useEffect(() => {
    async function checkFacultySession() {
      try {
        const response = await fetch(
          "http://localhost:8080/api/auth/me",
          {
            method: "GET",
            credentials: "include",
          }
        );

        if (!response.ok) {
          setStatus("unauthenticated");
          return;
        }

        const data = await response.json();

        if (data.userType !== "FACULTY") {
          setStatus("unauthenticated");
          return;
        }

        setStatus("authenticated");

      } catch (error) {
        console.error(
          "Faculty session check failed:",
          error
        );

        setStatus("unauthenticated");
      }
    }

    checkFacultySession();
  }, []);

  if (status === "checking") {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Checking your faculty session...</p>
        </div>
      </main>
    );
  }

  if (status === "unauthenticated") {
    return <Navigate to="/login" replace />;
  }

  return children;
}

export default FacultyProtectedRoute;