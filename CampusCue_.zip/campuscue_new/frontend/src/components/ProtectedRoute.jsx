import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";

function ProtectedRoute({ children }) {
  const [status, setStatus] = useState("checking");

  useEffect(() => {
    async function checkSession() {
      try {
        const response = await fetch(
          "http://localhost:8080/api/auth/me",
          {
            method: "GET",
            credentials: "include",
          }
        );

        if (!response.ok) {
          setStatus("unauthenticated");
          return;
        }

        const data = await response.json();

        if (data.userType !== "STUDENT") {
          setStatus("unauthenticated");
          return;
        }

        setStatus("authenticated");
      } catch (error) {
        console.error("Session check failed:", error);
        setStatus("unauthenticated");
      }
    }

    checkSession();
  }, []);

  if (status === "checking") {
    return (
      <main className="dashboard-page">
        <div className="dashboard-card">
          <p>Checking your session...</p>
        </div>
      </main>
    );
  }

  if (status === "unauthenticated") {
    return <Navigate to="/login" replace />;
  }

  return children;
}

export default ProtectedRoute;